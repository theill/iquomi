/*////////////////////////////////////////////////////////////////////
This file is part of the Hailstorm Essentials Book.

Copyright (C) 2001 Jim Culbert All rights reserved.

This source code is intended only as a supplement to O'Reilly's Hailstorm
Essentials Book and/or on-line documentation.  See these other
materials for detailed information regarding O'Reilly code samples.

THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
*////////////////////////////////////////////////////////////////////

using System;
using System.Xml;
using System.IO;
using System.Net;
using System.Text;

namespace MyServicesEssentials
{

	public class HSRequest
	{
		private String hsrBodyContent;
		private String hsrResponseString;
		private HSResponse hsrResponse;
		private Uri hsrUri;
		private String hsrMethod;
		private String hsrDocument;
		private String hsrService;
		private String hsrOwnerPuid;
		private String hsrRequestorPuid;
		private String hsrOverrideHeader;
		
		public HSRequest()
		{
		}

		public String OverrideHeader
		{
			get
			{
				return hsrOverrideHeader;
			}
			set
			{
				hsrOverrideHeader = value;
			}
		}

			public String XMIContent
		{
			get
			{
				return hsrBodyContent;
			}
			set
			{
				hsrBodyContent = value;
			}
		}

		public String Method
		{
			get
			{
				return hsrMethod;
			}
			set
			{
				hsrMethod = value;
			}
		}

		public String Service
		{
			get
			{
				return hsrService;
			}
			set
			{
				hsrService = value;
			}
		}

		public String Document
		{
			get
			{
				return hsrDocument;
			}
			set
			{
				hsrDocument = value;
			}
		}

		public Uri Uri
		{
			get
			{
				return hsrUri;
			}
			set
			{
				hsrUri = value;
			}
		}

		public String Response
		{
			get
			{
				return hsrResponseString;
			}
		}

		public String OwnerPuid
		{
			get
			{
				return hsrOwnerPuid;
			}
			set
			{
				hsrOwnerPuid = value;
			}
		}
		public String RequestorPuid
		{
			get
			{
				return hsrRequestorPuid;
			}
			set
			{
				hsrRequestorPuid = value;
			}
		}
		protected bool ValidateRequestParams()
		{
			return( hsrBodyContent.Length > 0 &&
				hsrOwnerPuid.Length > 0 &&
				hsrRequestorPuid.Length > 0 &&
				hsrUri.Scheme.Length > 0 &&
				hsrUri.Host.Length > 0 &&
				hsrDocument.Length > 0 &&
				hsrMethod.Length > 0 &&
				hsrService.Length > 0);
		}

		protected String AssembleRequest()
		{
			if(!ValidateRequestParams())
				return null;			

			StringBuilder sb = new StringBuilder("<?xml version='1.0'?>");
			sb.Append(QueryTemplates.EnvelopeOpenTemplate);	
			
			// Add header info. If there is an overriding header supplied, use
			// that. Otherwise synthesize it from params. This is icky and needs
			// fixing...
			if((hsrOverrideHeader != null) && (hsrOverrideHeader.Length > 0))
				sb.Append(hsrOverrideHeader);
			else
			{
				//Write the host
				StringBuilder theServer = new StringBuilder();
				theServer.Append(hsrUri.Scheme);
				theServer.Append("://");
				theServer.Append(hsrUri.Host);
				String hsrQuery = QueryTemplates.HeaderTemplate.Replace("%%HOST%%", theServer.ToString());

				//Write the message id
				Guid myId = Guid.NewGuid();
				hsrQuery = hsrQuery.Replace("%%GUID%%", myId.ToString());

				//Write the security info
				hsrQuery = hsrQuery.Replace("%%KERBEROS%%", hsrRequestorPuid);
				hsrQuery = hsrQuery.Replace("%%PUID%%", hsrOwnerPuid);
			
				//Write the service access info
				hsrQuery = hsrQuery.Replace("%%SERVICE%%", hsrService);
				hsrQuery = hsrQuery.Replace("%%DOCUMENT%%", hsrDocument);
				hsrQuery = hsrQuery.Replace("%%METHOD%%", hsrMethod);

				sb.Append(hsrQuery);
			}

			//Add the body and close the envelope
			sb.Append("<s:Body>");
			sb.Append(hsrBodyContent);
			sb.Append("</s:Body></s:Envelope>");

			return sb.ToString();
		}


		public bool SendRequest()
		{
			if(hsrUri == null)
				return false;
			
			String theRequestString = AssembleRequest();

			if(theRequestString.Length == 0)
				return false;
			
			hsrResponseString = null;
			try
			{
				WebRequest hsRequest = WebRequest.Create(hsrUri);
				hsRequest.ContentType = "text/xml";
				hsRequest.ContentLength = theRequestString.Length;
				hsRequest.Method = "POST";
				Stream reqStream = hsRequest.GetRequestStream();
				StreamWriter reqStreamWriter = new StreamWriter(reqStream);
				reqStreamWriter.Write(theRequestString);
				reqStreamWriter.Close();
		
				WebResponse theResponse = hsRequest.GetResponse();
				Stream ReceiveStream = theResponse.GetResponseStream();
				hsrResponse = new HSResponse(ReceiveStream);
				hsrResponseString = hsrResponse.ToString();

			}
			catch(Exception e)
			{return false;}
			
			return true;
		}

	}
	public class HSResponse
	{
		private XmlDocument hsrResponseXML;
        
		public HSResponse(String responseString)
		{
			hsrResponseXML = new XmlDocument();
			hsrResponseXML.PreserveWhitespace = true;
			hsrResponseXML.Load(responseString);
		}

		public HSResponse(Stream resposneStream)
		{
			hsrResponseXML = new XmlDocument();
			hsrResponseXML.PreserveWhitespace = true;
			hsrResponseXML.Load(resposneStream);
		}

		public HSResponse(XmlDocument responseXML)
		{
			hsrResponseXML = responseXML;
		}

		public XmlDocument ResponseXML
		{
			get
			{
				return hsrResponseXML;
			}

		}

		public override String ToString()
		{
			return hsrResponseXML.InnerXml;
		}
	}
}