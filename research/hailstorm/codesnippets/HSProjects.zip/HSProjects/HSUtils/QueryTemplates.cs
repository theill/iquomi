/*////////////////////////////////////////////////////////////////////
This file is part of the Hailstorm Essentials Book.

Copyright (C) 2001 Jim Culbert All rights reserved.

This source code is intended only as a supplement to O'Reilly's Hailstorm
Essentials Book and/or on-line documentation.  See these other
materials for detailed information regarding O'Reilly code samples.

THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
*////////////////////////////////////////////////////////////////////

using System;

namespace MyServicesEssentials
{
	public struct QueryTemplates
	{
		// Note: The left justification of the templates is done
		// so that when displayed in a dialog the fragments look
		// reasonable. 
		// Also, these templates are not the most efficient way to 
		// do this but they're easy to read and understand what's
		// going on...

		/*********** ENVELOPE OPEN FRAGMENT *********/
		public const String EnvelopeOpenTemplate = 
@"<s:Envelope xmlns:s=""http://schemas.xmlsoap.org/soap/envelope/""
	xmlns:x=""http://schemas.xmlsoap.org/rp/""
	xmlns:h=""http://schemas.microsoft.com/hs/2001/10/core/""
	xmlns:ss=""http://schemas.xmlsoap.org/soap/security/2000-12/"" >";
	

		/*********** HEADER FRAGMENT ***************/
		public const String HeaderTemplate = 
@"<s:Header>
	<x:path>
		<x:action>http://schemas.microsoft.com/hs/2001/10/core#request</x:action>
		<x:rev><x:via /></x:rev>
		<x:to>%%HOST%%</x:to>
		<x:id>%%GUID%%</x:id>
	</x:path>
	<ss:licenses>
		<h:identity mustUnderstand=""1"">
			<h:kerberos>%%KERBEROS%%</h:kerberos>
		</h:identity>
	</ss:licenses>
	<h:request mustUnderstand=""1""
		service=""%%SERVICE%%""
		document=""%%DOCUMENT%%""
		method=""%%METHOD%%""
		genResponse=""always"">
		<h:key instance=""0"" cluster=""0"" puid=""%%PUID%%"" />
	</h:request>
</s:Header>";
	}
}