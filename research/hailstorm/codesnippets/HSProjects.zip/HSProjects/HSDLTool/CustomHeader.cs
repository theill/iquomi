/*////////////////////////////////////////////////////////////////////
This file is part of the Hailstorm Essentials Book.

Copyright (C) 2001 Jim Culbert All rights reserved.

This source code is intended only as a supplement to O'Reilly's Hailstorm
Essentials Book and/or on-line documentation.  See these other
materials for detailed information regarding O'Reilly code samples.

THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
*////////////////////////////////////////////////////////////////////

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace HSDLTool
{
	/// <summary>
	/// Summary description for CustomHeader.
	/// </summary>
	public class CustomHeader : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TextBox customHeaderBox;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public CustomHeader()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		public String CustomHeaderText
		{
			set
			{
				customHeaderBox.Text = value;
			}
			get
			{
				return customHeaderBox.Text;
			}
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(CustomHeader));
			this.customHeaderBox = new System.Windows.Forms.TextBox();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// customHeaderBox
			// 
			this.customHeaderBox.Location = new System.Drawing.Point(32, 16);
			this.customHeaderBox.Multiline = true;
			this.customHeaderBox.Name = "customHeaderBox";
			this.customHeaderBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.customHeaderBox.Size = new System.Drawing.Size(640, 328);
			this.customHeaderBox.TabIndex = 0;
			this.customHeaderBox.Text = "";
			this.customHeaderBox.WordWrap = false;
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(232, 352);
			this.button1.Name = "button1";
			this.button1.TabIndex = 1;
			this.button1.Text = "Done";
			this.button1.Click += new System.EventHandler(this.button1_Click_1);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(416, 353);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(80, 23);
			this.button2.TabIndex = 2;
			this.button2.Text = "New ID";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// CustomHeader
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(702, 387);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.button2,
																		  this.button1,
																		  this.customHeaderBox});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "CustomHeader";
			this.Text = "Custom Header";
			this.ResumeLayout(false);

		}
		#endregion

		private void button1_Click(object sender, System.EventArgs e)
		{

		}

		private void button1_Click_1(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			System.Text.StringBuilder sb = new System.Text.StringBuilder("<x:id>");

			String newGuid = Guid.NewGuid().ToString();

			sb.Append(newGuid);
			sb.Append("</x:id>");

			Clipboard.SetDataObject(sb.ToString());
			MessageBox.Show(sb.ToString(), "Copied to Clipboard");
		}
	}
}
