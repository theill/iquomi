/*////////////////////////////////////////////////////////////////////
This file is part of the Hailstorm Essentials Book.

Copyright (C) 2001 Jim Culbert All rights reserved.

This source code is intended only as a supplement to O'Reilly's Hailstorm
Essentials Book and/or on-line documentation.  See these other
materials for detailed information regarding O'Reilly code samples.

THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
*////////////////////////////////////////////////////////////////////

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace HSDLTool
{
	/// <summary>
	/// Summary description for FragPicker.
	/// </summary>
	public class FragPicker : System.Windows.Forms.Form
	{
		private String FRAG_DIR = "frags";

		private System.Windows.Forms.Button fragButton;
		private System.Windows.Forms.ListBox fragListBox;
		private System.Windows.Forms.Button fragCancelButton;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public FragPicker()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			this.fragListBox.DoubleClick += new System.EventHandler(this.fragListBox_DoubleClick);

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(FragPicker));
			this.fragCancelButton = new System.Windows.Forms.Button();
			this.fragButton = new System.Windows.Forms.Button();
			this.fragListBox = new System.Windows.Forms.ListBox();
			this.SuspendLayout();
			// 
			// fragCancelButton
			// 
			this.fragCancelButton.Location = new System.Drawing.Point(104, 136);
			this.fragCancelButton.Name = "fragCancelButton";
			this.fragCancelButton.TabIndex = 3;
			this.fragCancelButton.Text = "Cancel";
			this.fragCancelButton.Click += new System.EventHandler(this.fragCancelButton_Click);
			// 
			// fragButton
			// 
			this.fragButton.Location = new System.Drawing.Point(16, 136);
			this.fragButton.Name = "fragButton";
			this.fragButton.Size = new System.Drawing.Size(72, 23);
			this.fragButton.TabIndex = 1;
			this.fragButton.Text = "Ok";
			this.fragButton.Click += new System.EventHandler(this.fragButton_Click);
			// 
			// fragListBox
			// 
			this.fragListBox.Location = new System.Drawing.Point(16, 16);
			this.fragListBox.Name = "fragListBox";
			this.fragListBox.Size = new System.Drawing.Size(160, 95);
			this.fragListBox.TabIndex = 2;
			// 
			// FragPicker
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(198, 187);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.fragCancelButton,
																		  this.fragListBox,
																		  this.fragButton});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "FragPicker";
			this.Text = "Pick a Template";
			this.Load += new System.EventHandler(this.FragPicker_Load);
			this.ResumeLayout(false);

		}
		#endregion

		public String FragFileName
		{
			get
			{
				//Get the application path
				String appPath = System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName;
				System.IO.FileInfo rootFI = new System.IO.FileInfo(appPath);
				appPath = rootFI.Directory.ToString();

				//Build the path to the subdir for the xml frags
				System.Text.StringBuilder sb = new System.Text.StringBuilder(appPath);
				sb.Append("\\");
				sb.Append(FRAG_DIR);
				sb.Append("\\");
				sb.Append(this.fragListBox.SelectedItem.ToString());
				sb.Append(".xml");
				return sb.ToString();
			}
		}				

		private void FragPicker_Load(object sender, System.EventArgs e)
		{
			try
			{
				//Get the application path
				String appPath = System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName;
				System.IO.FileInfo rootFI = new System.IO.FileInfo(appPath);
				appPath = rootFI.Directory.ToString();

				//Build the path to the subdir for the xml frags
				System.Text.StringBuilder sb = new System.Text.StringBuilder(appPath);
				sb.Append("/");
				sb.Append(FRAG_DIR);
				string[] fragFiles = System.IO.Directory.GetFiles(sb.ToString(), "*.xml");

				for(int i = 0; i< fragFiles.Length;i++)
				{
					System.IO.FileInfo fi = new System.IO.FileInfo(fragFiles[i]);
					this.fragListBox.Items.Add(fi.Name.Replace(fi.Extension,""));
				}
			}
			catch(System.Exception ex){}

		}

		private void fragButton_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.OK;
			this.Close();
		}

		private void fragCancelButton_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
			this.Close();
		}

		private void fragListBox_DoubleClick(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.OK;
			this.Close();
		}
	}
}
