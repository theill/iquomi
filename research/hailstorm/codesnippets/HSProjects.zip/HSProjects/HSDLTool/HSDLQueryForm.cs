/*////////////////////////////////////////////////////////////////////
This file is part of the Hailstorm Essentials Book.

Copyright (C) 2001 Jim Culbert All rights reserved.

This source code is intended only as a supplement to O'Reilly's Hailstorm
Essentials Book and/or on-line documentation.  See these other
materials for detailed information regarding O'Reilly code samples.

THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
*////////////////////////////////////////////////////////////////////

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using MyServicesEssentials;

namespace HSDLTool

{
	/// <summary>
	/// Summary description for HSDLQueryForm.
	/// </summary>
	public class HSDLQueryForm : System.Windows.Forms.Form
	{
		private String FRAG_DIR = "frags";

		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.MenuItem menuItem4;
		private System.Windows.Forms.MenuItem menuItem5;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.SaveFileDialog saveFileDialog1;
		private System.Windows.Forms.TextBox xmiBox;
		private System.Windows.Forms.MainMenu FileMenu;
		private System.Windows.Forms.ComboBox MethodBox;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.ComboBox ServiceBox;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.ComboBox DocumentBox;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.TextBox HostBox;
		private System.Windows.Forms.RadioButton CustomHeader;
		private System.Windows.Forms.RadioButton HeaderOptions;
		private System.Windows.Forms.Button EditHeader;
		private System.Windows.Forms.GroupBox HeaderOptionsGroup;
		private System.Windows.Forms.GroupBox CustomHeaderGroup;
		private CustomHeader CustomHeaderDialog = new CustomHeader();
		private System.Windows.Forms.MenuItem menuItem6;
		private System.Windows.Forms.MenuItem HelpAbout;
		private System.Windows.Forms.Button SendHSDLButton;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox ReqPUIDBox;
		private System.Windows.Forms.TextBox OwnerPUIDBox;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.PictureBox fragPickerImage;
		private System.Windows.Forms.ToolTip HSDLQFormTips;
		private System.ComponentModel.IContainer components;

		public HSDLQueryForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			MethodBox.SelectedIndex = 0;
			ServiceBox.SelectedIndex = 0;
			DocumentBox.SelectedIndex = 0;
			CustomHeaderDialog.CustomHeaderText = @"<s:Header>
	<x:path>
		<x:action>http://schemas.microsoft.com/hailstorm/request</x:action> 
		<x:rev>
			<x:via />
		</x:rev>
		<x:to>http://localhost</x:to> 
		<x:id>46008cd2-b415-4a8b-99ba-5fbaf64889f8</x:id> 
	</x:path>
	<ss:licenses>
		<h:identity mustUnderstand=""1"">
			<h:kerberos>12566</h:kerberos> 
		</h:identity>
	</ss:licenses>
	<h:request mustUnderstand=""1"" service=""myProfile"" document=""content"" method=""query"" genResponse=""always"">
		<h:key instance=""0"" cluster=""0"" puid=""12566"" /> 
	</h:request>
</s:Header>";
			CustomHeaderDialog.CustomHeaderText = QueryTemplates.HeaderTemplate;

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(HSDLQueryForm));
			this.label3 = new System.Windows.Forms.Label();
			this.EditHeader = new System.Windows.Forms.Button();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.menuItem5 = new System.Windows.Forms.MenuItem();
			this.menuItem4 = new System.Windows.Forms.MenuItem();
			this.fragPickerImage = new System.Windows.Forms.PictureBox();
			this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.menuItem6 = new System.Windows.Forms.MenuItem();
			this.HelpAbout = new System.Windows.Forms.MenuItem();
			this.ServiceBox = new System.Windows.Forms.ComboBox();
			this.DocumentBox = new System.Windows.Forms.ComboBox();
			this.FileMenu = new System.Windows.Forms.MainMenu();
			this.HeaderOptions = new System.Windows.Forms.RadioButton();
			this.SendHSDLButton = new System.Windows.Forms.Button();
			this.CustomHeaderGroup = new System.Windows.Forms.GroupBox();
			this.xmiBox = new System.Windows.Forms.TextBox();
			this.CustomHeader = new System.Windows.Forms.RadioButton();
			this.HSDLQFormTips = new System.Windows.Forms.ToolTip(this.components);
			this.OwnerPUIDBox = new System.Windows.Forms.TextBox();
			this.MethodBox = new System.Windows.Forms.ComboBox();
			this.ReqPUIDBox = new System.Windows.Forms.TextBox();
			this.label8 = new System.Windows.Forms.Label();
			this.HeaderOptionsGroup = new System.Windows.Forms.GroupBox();
			this.label4 = new System.Windows.Forms.Label();
			this.HostBox = new System.Windows.Forms.TextBox();
			this.label7 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.CustomHeaderGroup.SuspendLayout();
			this.HeaderOptionsGroup.SuspendLayout();
			this.SuspendLayout();
			// 
			// label3
			// 
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label3.Location = new System.Drawing.Point(8, 136);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(64, 16);
			this.label3.TabIndex = 9;
			this.label3.Text = "Document";
			// 
			// EditHeader
			// 
			this.EditHeader.Location = new System.Drawing.Point(104, 19);
			this.EditHeader.Name = "EditHeader";
			this.EditHeader.TabIndex = 0;
			this.EditHeader.Text = "Edit Header";
			this.EditHeader.Click += new System.EventHandler(this.EditHeader_Click);
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem2,
																					  this.menuItem3,
																					  this.menuItem5,
																					  this.menuItem4});
			this.menuItem1.Text = "File";
			// 
			// menuItem2
			// 
			this.menuItem2.Index = 0;
			this.menuItem2.Text = "Load XMI";
			this.menuItem2.Click += new System.EventHandler(this.menuItem2_Click);
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 1;
			this.menuItem3.Text = "Save XMI";
			this.menuItem3.Click += new System.EventHandler(this.menuItem3_Click);
			// 
			// menuItem5
			// 
			this.menuItem5.Index = 2;
			this.menuItem5.Text = "-";
			// 
			// menuItem4
			// 
			this.menuItem4.Index = 3;
			this.menuItem4.Text = "Exit";
			this.menuItem4.Click += new System.EventHandler(this.menuItem4_Click);
			// 
			// fragPickerImage
			// 
			this.fragPickerImage.Cursor = System.Windows.Forms.Cursors.Hand;
			this.fragPickerImage.Image = ((System.Drawing.Bitmap)(resources.GetObject("fragPickerImage.Image")));
			this.fragPickerImage.Location = new System.Drawing.Point(400, 296);
			this.fragPickerImage.Name = "fragPickerImage";
			this.fragPickerImage.Size = new System.Drawing.Size(21, 21);
			this.fragPickerImage.TabIndex = 20;
			this.fragPickerImage.TabStop = false;
			this.HSDLQFormTips.SetToolTip(this.fragPickerImage, "Click to pick a query template.");
			this.fragPickerImage.Click += new System.EventHandler(this.fragPickerImage_Click);
			// 
			// saveFileDialog1
			// 
			this.saveFileDialog1.FileName = "doc1";
			// 
			// menuItem6
			// 
			this.menuItem6.Index = 1;
			this.menuItem6.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.HelpAbout});
			this.menuItem6.Text = "Help";
			// 
			// HelpAbout
			// 
			this.HelpAbout.Index = 0;
			this.HelpAbout.Text = "About";
			this.HelpAbout.Click += new System.EventHandler(this.menuItem7_Click);
			// 
			// ServiceBox
			// 
			this.ServiceBox.DropDownWidth = 121;
			this.ServiceBox.Items.AddRange(new object[] {
															"myProfile",
															"myCalendar",
															"myCategories",
															"myLists",
															"myDocuments",
															"myWallet",
															"myServices",
															"myFavoriteWebSites",
															"myContacts",
															"myServices",
															"myInbox",
															"myLocation",
															"myAlerts"});
			this.ServiceBox.Location = new System.Drawing.Point(112, 48);
			this.ServiceBox.Name = "ServiceBox";
			this.ServiceBox.Size = new System.Drawing.Size(121, 21);
			this.ServiceBox.TabIndex = 2;
			// 
			// DocumentBox
			// 
			this.DocumentBox.DropDownWidth = 121;
			this.DocumentBox.Items.AddRange(new object[] {
															 "content",
															 "roleList",
															 "system"});
			this.DocumentBox.Location = new System.Drawing.Point(112, 136);
			this.DocumentBox.Name = "DocumentBox";
			this.DocumentBox.Size = new System.Drawing.Size(121, 21);
			this.DocumentBox.TabIndex = 5;
			// 
			// FileMenu
			// 
			this.FileMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					 this.menuItem1,
																					 this.menuItem6});
			// 
			// HeaderOptions
			// 
			this.HeaderOptions.Checked = true;
			this.HeaderOptions.Location = new System.Drawing.Point(460, 19);
			this.HeaderOptions.Name = "HeaderOptions";
			this.HeaderOptions.Size = new System.Drawing.Size(108, 24);
			this.HeaderOptions.TabIndex = 7;
			this.HeaderOptions.TabStop = true;
			this.HeaderOptions.Text = "Header Options";
			this.HeaderOptions.CheckedChanged += new System.EventHandler(this.HeaderOptions_CheckedChanged);
			// 
			// SendHSDLButton
			// 
			this.SendHSDLButton.Location = new System.Drawing.Point(16, 296);
			this.SendHSDLButton.Name = "SendHSDLButton";
			this.SendHSDLButton.Size = new System.Drawing.Size(112, 23);
			this.SendHSDLButton.TabIndex = 2;
			this.SendHSDLButton.Text = "Send HSDL";
			this.SendHSDLButton.Click += new System.EventHandler(this.SendHSDLButton_Click);
			// 
			// CustomHeaderGroup
			// 
			this.CustomHeaderGroup.Controls.AddRange(new System.Windows.Forms.Control[] {
																							this.EditHeader});
			this.CustomHeaderGroup.Enabled = false;
			this.CustomHeaderGroup.Location = new System.Drawing.Point(448, 232);
			this.CustomHeaderGroup.Name = "CustomHeaderGroup";
			this.CustomHeaderGroup.Size = new System.Drawing.Size(272, 48);
			this.CustomHeaderGroup.TabIndex = 17;
			this.CustomHeaderGroup.TabStop = false;
			// 
			// xmiBox
			// 
			this.xmiBox.AcceptsTab = true;
			this.xmiBox.Location = new System.Drawing.Point(16, 31);
			this.xmiBox.Multiline = true;
			this.xmiBox.Name = "xmiBox";
			this.xmiBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.xmiBox.Size = new System.Drawing.Size(408, 256);
			this.xmiBox.TabIndex = 0;
			this.xmiBox.TabStop = false;
			this.xmiBox.Text = "";
			// 
			// CustomHeader
			// 
			this.CustomHeader.Location = new System.Drawing.Point(456, 224);
			this.CustomHeader.Name = "CustomHeader";
			this.CustomHeader.Size = new System.Drawing.Size(104, 21);
			this.CustomHeader.TabIndex = 16;
			this.CustomHeader.Text = "Custom Header";
			this.CustomHeader.CheckedChanged += new System.EventHandler(this.CustomHeader_CheckedChanged);
			// 
			// OwnerPUIDBox
			// 
			this.OwnerPUIDBox.Location = new System.Drawing.Point(112, 160);
			this.OwnerPUIDBox.Name = "OwnerPUIDBox";
			this.OwnerPUIDBox.Size = new System.Drawing.Size(56, 20);
			this.OwnerPUIDBox.TabIndex = 6;
			this.OwnerPUIDBox.Text = "12566";
			// 
			// MethodBox
			// 
			this.MethodBox.DropDownWidth = 121;
			this.MethodBox.Items.AddRange(new object[] {
														   "query",
														   "insert",
														   "update",
														   "delete",
														   "replace"});
			this.MethodBox.Location = new System.Drawing.Point(112, 23);
			this.MethodBox.Name = "MethodBox";
			this.MethodBox.Size = new System.Drawing.Size(121, 21);
			this.MethodBox.TabIndex = 1;
			// 
			// ReqPUIDBox
			// 
			this.ReqPUIDBox.Location = new System.Drawing.Point(112, 96);
			this.ReqPUIDBox.Name = "ReqPUIDBox";
			this.ReqPUIDBox.TabIndex = 4;
			this.ReqPUIDBox.Text = "12566";
			// 
			// label8
			// 
			this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label8.Location = new System.Drawing.Point(8, 72);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(32, 16);
			this.label8.TabIndex = 11;
			this.label8.Text = "Host";
			// 
			// HeaderOptionsGroup
			// 
			this.HeaderOptionsGroup.Controls.AddRange(new System.Windows.Forms.Control[] {
																							 this.ReqPUIDBox,
																							 this.label4,
																							 this.HostBox,
																							 this.label8,
																							 this.OwnerPUIDBox,
																							 this.label7,
																							 this.DocumentBox,
																							 this.label3,
																							 this.ServiceBox,
																							 this.label2,
																							 this.MethodBox,
																							 this.label1});
			this.HeaderOptionsGroup.Location = new System.Drawing.Point(448, 24);
			this.HeaderOptionsGroup.Name = "HeaderOptionsGroup";
			this.HeaderOptionsGroup.Size = new System.Drawing.Size(272, 192);
			this.HeaderOptionsGroup.TabIndex = 14;
			this.HeaderOptionsGroup.TabStop = false;
			// 
			// label4
			// 
			this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label4.Location = new System.Drawing.Point(8, 96);
			this.label4.Name = "label4";
			this.label4.TabIndex = 12;
			this.label4.Text = "Requestor PUID";
			// 
			// HostBox
			// 
			this.HostBox.Location = new System.Drawing.Point(112, 72);
			this.HostBox.Name = "HostBox";
			this.HostBox.TabIndex = 3;
			this.HostBox.Text = "localhost";
			// 
			// label7
			// 
			this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label7.Location = new System.Drawing.Point(8, 160);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(72, 16);
			this.label7.TabIndex = 10;
			this.label7.Text = "Owner PUID";
			// 
			// label2
			// 
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label2.Location = new System.Drawing.Point(8, 48);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(48, 16);
			this.label2.TabIndex = 8;
			this.label2.Text = "Service";
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label1.Location = new System.Drawing.Point(9, 24);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(48, 16);
			this.label1.TabIndex = 7;
			this.label1.Text = "Method";
			// 
			// label5
			// 
			this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label5.Location = new System.Drawing.Point(328, 302);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(72, 16);
			this.label5.TabIndex = 19;
			this.label5.Text = "Query Picker";
			// 
			// HSDLQueryForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(736, 337);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.fragPickerImage,
																		  this.label5,
																		  this.HeaderOptions,
																		  this.SendHSDLButton,
																		  this.xmiBox,
																		  this.HeaderOptionsGroup,
																		  this.CustomHeader,
																		  this.CustomHeaderGroup});
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Menu = this.FileMenu;
			this.Name = "HSDLQueryForm";
			this.Text = "HSDL Query Tool";
			this.CustomHeaderGroup.ResumeLayout(false);
			this.HeaderOptionsGroup.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new HSDLQueryForm());
		}

		private void SendHSDLButton_Click(object sender, System.EventArgs e)
		{

			if(	DocumentBox.SelectedIndex < 0 ||
				MethodBox.SelectedIndex < 0 ||
				ServiceBox.SelectedIndex < 0 ||
				xmiBox.Text.Length == 0 ||
				HostBox.Text.Length == 0 ||
				OwnerPUIDBox.Text.Length == 0)
			{
				MessageBox.Show("Invalid arguments: Try again!");
				return;
			}

			if(ReqPUIDBox.Text.Length == 0)
				ReqPUIDBox.Text = OwnerPUIDBox.Text;

			HSRequest myRequest = new HSRequest();
			myRequest.Document = DocumentBox.SelectedItem.ToString();
			myRequest.Method = MethodBox.SelectedItem.ToString();
			myRequest.OwnerPuid = OwnerPUIDBox.Text;
			myRequest.RequestorPuid = ReqPUIDBox.Text;
			myRequest.Service = ServiceBox.SelectedItem.ToString();
			myRequest.XMIContent = xmiBox.Text;

			UriBuilder ub = new UriBuilder();
			ub.Scheme = "http";
			ub.Host = HostBox.Text;
			ub.Path = "/" + ServiceBox.Text;
			myRequest.Uri = ub.Uri;

			if(CustomHeader.Checked)
				myRequest.OverrideHeader = CustomHeaderDialog.CustomHeaderText;
			else
				myRequest.OverrideHeader = null;

			if(myRequest.SendRequest())
			{
				ResultsDialog rd = new ResultsDialog();
				rd.DialogText = myRequest.Response.ToString();
				rd.ShowDialog();
			}
			else
				MessageBox.Show("XMI Request Failed");

		}

		private void menuItem2_Click(object sender, System.EventArgs e)
		{
			System.IO.Stream xmiFileStream;
			if(openFileDialog1.ShowDialog() == DialogResult.OK)
			{
				try
				{
					xmiFileStream = openFileDialog1.OpenFile();
					System.IO.StreamReader sr = new System.IO.StreamReader(xmiFileStream);
                    xmiBox.Text = sr.ReadToEnd();
					sr.Close();
				}
				catch(Exception ex)
				{
					MessageBox.Show("Error opening file.");
				}
			}
		}

		private void menuItem3_Click(object sender, System.EventArgs e)
		{
			System.IO.Stream xmiFileStream;
			if(saveFileDialog1.ShowDialog() == DialogResult.OK)
			{
				try
				{
					xmiFileStream = saveFileDialog1.OpenFile();
					System.IO.StreamWriter sw = new System.IO.StreamWriter(xmiFileStream);
					sw.Write(xmiBox.Text);
					sw.Close();
				}
				catch(Exception ex)
				{
					MessageBox.Show("File save operation failed.");
				}
			}

		}

		private void menuItem4_Click(object sender, System.EventArgs e)
		{
			Application.Exit();
		}

		private void HeaderOptions_CheckedChanged(object sender, System.EventArgs e)
		{
			HeaderOptionsGroup.Enabled = HeaderOptions.Checked;
		}

		private void CustomHeader_CheckedChanged(object sender, System.EventArgs e)
		{
			CustomHeaderGroup.Enabled = CustomHeader.Checked;
		}

		private void EditHeader_Click(object sender, System.EventArgs e)
		{
			CustomHeaderDialog.ShowDialog();
		}

		private void menuItem7_Click(object sender, System.EventArgs e)
		{
			About aboutMessage = new About();
			aboutMessage.ShowDialog();
		}

		private void fragPickerImage_Click(object sender, System.EventArgs e)
		{
			FragPicker fp = new FragPicker();
			if (fp.ShowDialog(this) == System.Windows.Forms.DialogResult.OK)
			{	
				try
				{
					System.IO.FileInfo xmiFile = new System.IO.FileInfo(fp.FragFileName);
					System.IO.FileStream xmiFileStream = xmiFile.OpenRead();
					System.IO.StreamReader sr = new System.IO.StreamReader(xmiFileStream);
					xmiBox.Text = sr.ReadToEnd();
					sr.Close();
				}
				catch(Exception ex)
				{
					MessageBox.Show("Error opening file.");
				}

			}
		}

	}
}
