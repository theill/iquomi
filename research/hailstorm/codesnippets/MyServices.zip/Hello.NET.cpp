// This is the main project file for VC++ application project 
// generated using an Application Wizard.

#include "stdafx.h"

#using <mscorlib.dll>

#include <tchar.h>
#include "WebService.h"

using namespace System;
using namespace System::Web::Services;
using namespace System::Web::Services ::Protocols;
using namespace System::Xml;
using namespace System::Windows::Forms;

using namespace Microsoft::Hs;
using namespace Microsoft::Hs::ServiceLocator;

// This is the entry point for this application
int _tmain(void)
{
    
	Microsoft::Hs::ServiceLocator::ServiceLocator* serviceLocator = new Microsoft::Hs::ServiceLocator::ServiceLocator("http://localhost/myServices", "c:\\logfile.txt", true);
    try
      {
            
        //
        // Use the service locator to find and initialize the myFavoriteWebSites service / proxy
        //
        // TODO: if you are querying for a different user, specify the username instead of calling User.GetCurrentUser()
        // NOTE: User.GetCurrentUser will not work inside an ASP.NET applicaiton
        //
        
		myFavoriteWebSites* myFav = dynamic_cast<myFavoriteWebSites*> (serviceLocator->GetService(System::Type::GetType("myFavoriteWebSites"), User::GetCurrentUser()));
		
        //
        // create a new favoriteWebSite
        //
        favoriteWebSiteType* newWebsite = new favoriteWebSiteType();
        localizableString* title = new localizableString();
        title->lang = S"en";
        title->Value = S"Hello.NET";
        newWebsite->title = new localizableString*[1];
		newWebsite->title[0] =title;
        newWebsite->url = S"http://www.microsoft.com";
        catType* cat = new catType();
        cat->ref = S"system";
        newWebsite->cat = new catType*[1];
		newWebsite->cat[0] = cat;

        //
        // create an insertRequest and call insert
        //
        insertRequestType* insertRequest = new insertRequestType();
        insertRequest->select=S"/"; //we're going to insert into the root of the service
        insertRequest->Items = new Object*[1];
		insertRequest->Items[0] = newWebsite;

		insertRequest->ItemsElementName =  new ItemsChoiceType[1];
		insertRequest->ItemsElementName[0] = ItemsChoiceType::favoriteWebSite;

        insertResponseType* response = myFav->insert(insertRequest);

        //
        // check to make sure the operation was successful
        //
		if(response->selectedNodeCount != 1 || response->status != responseStatus::success)
        {
            throw new Exception(S"Error inserting the new favoriteWebSite into myFavoriteWebSites");
        }

        //
        // now that we've inserted the new favoriteWebSite, let's query for it
        //
        queryRequestType* queryRequest = new queryRequestType();
        xpQueryType* xpQuery = new xpQueryType();
        //NOTE: the m: prefix is declared automatically in the SoapExtension for the current service
        xpQuery->select=S"/m:myFavoriteWebSites/m:favoriteWebSite[./m:title='Hello.NET' and ./m:url='http://www.microsoft.com']";
        //add the xpQuery to the xpQuery array
        queryRequest->xpQuery = new xpQueryType*[1];
		queryRequest->xpQuery[0] = xpQuery;
        queryResponseType* queryResponse = myFav->query(queryRequest);

        //
        // get the returned favoriteWebSite out of the response
        //
        favoriteWebSiteType* returnedWebSite = dynamic_cast<favoriteWebSiteType*> (queryResponse->xpQueryResponse[0]->Items[0]);
        
        //
        // check to make sure the operation was successful
        //				
		if(String::Compare (returnedWebSite->title[0]->Value, S"Hello.NET") != 0 || String::Compare (queryResponse->xpQueryResponse[0]->status , S"success")!= 0)
        {
            throw new Exception(S"Error retrieving the new favoriteWebSite from myFavoriteWebSites");
        }        
        //
        // display the webSite in a messageBox
        //
		MessageBox::Show(String::Concat (S"The following favoriteWebSite was returned from myFavoriteWebSites: ",returnedWebSite->title[0]->Value));
        
        //
        // replace the cat/@ref attribute value
        //
        topLevelAttributeType* redAttribute = new topLevelAttributeType();
        redAttribute->name = S"ref";
        redAttribute->value = S"newvalue";

              //
        // delete the website
        //
        deleteRequestType* deleteRequest = new deleteRequestType();
        deleteRequest->select = S"/m:myFavoriteWebSites/m:favoriteWebSite[./m:title='Hello.NET' and ./m:url='http://www.microsoft.com']";
		deleteResponseType* delResponse = myFav->__identifier(delete)(deleteRequest);

	    
        //
        // check to make sure we operated on at least one element and that the response indicates the operation was successful
        //
		if(delResponse->selectedNodeCount == 0 || delResponse->status != responseStatus::success)
        {
            throw new Exception(S"Error deleting the new favoriteWebSite from myFavoriteWebSites");
        }

		MessageBox::Show(S"Successfully deleted the favoriteWebSite from myFavoriteWebSites");
        
        
    }
    catch(SoapException* se)
    {
        //
        // write the SoapException to the console
        //
		Console::Write(S"A SoapException was thrown\n\nException:\n");
		Console::WriteLine(se->ToString());
		Console::Write(S"\n\nExtended SoapFault information returned from .NET My Services:\n");
		Console::Write(se->Detail->InnerXml);
    }
    catch(Exception* ex)
    {
        //
        // write the exception to the console
        //
		Console::WriteLine(ex->ToString());
    }
	Console::WriteLine(S"Press return to exit." );
	Console::ReadLine();
    
    return 0;
}

