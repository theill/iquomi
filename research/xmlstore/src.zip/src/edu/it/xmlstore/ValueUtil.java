package edu.it.xmlstore;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.math.BigInteger;

import edu.it.xmlstore.ValueReference;
import edu.it.xmlstore.chord.ChordIdImpl;
import edu.it.xmlstore.chord.ChordId;
import edu.it.xmlstore.xml.Node;

/**
 * Utility methods for creating and decoding value references.
 */
public class ValueUtil {
   /**
    * Calculates the ValueReference (or ChordId depending on your point of view)
    * based on an input value in the form of an array of bytes.
    *
    * @param data the value
    * @return the ValueReference referring to the value
    */
   public static ValueReference getValueReference(byte[] data) {
      try {
         MessageDigest md = MessageDigest.getInstance("SHA-1");
         md.update(data);
         return new ChordIdImpl(new BigInteger(md.digest()));
      } catch(NoSuchAlgorithmException e) {
         throw new RuntimeException("Could not generate value ref " +
                                    "based on SHA-1: " + e);
      }
   }

   /**
    * Decodes a ValueReference (or ChordId depending on your point of view)
    * based on an input value in the form of a string. Depends on the radix
    * defined in ChordId
    *
    * @param s the string-representation of the Value Reference
    * @return the ValueReference
    */
   public static ValueReference decode(String s) {
      return new ChordIdImpl( new BigInteger(s, ChordId.CHORD_RADIX) );
   }

   public static ValueReference decode(byte[] b) {
      return new ChordIdImpl( new BigInteger(b));
   }

   /**
    * Returns a value reference with the numerical value of the input
    *  -- good for testing
    * @param i number to be converted into a ValueReference
    * @return the ValueReference
    */
   public static ValueReference getTestValueReference(long i) {
      return new ChordIdImpl( new BigInteger(Long.toString(i)) );
   }
}
