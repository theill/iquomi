package edu.it.xmlstore.rpc;

import edu.it.xmlstore.XmlStoreHome;
import edu.it.xmlstore.directory.*;

import java.net.InetSocketAddress;
import java.net.InetAddress;

public abstract class AbstractProxy {
   // The address of the subject we act as a proxy for
   protected InetSocketAddress subjectAddress;

   public InetSocketAddress getAddress() {
      return subjectAddress;
   }

   // Communication
   protected Transmitter transmitter;
   protected static final int HEADER_LENGTH_NO_ARGUMENTS  =  2;
   protected static final int HEADER_LENGTH_ONE_ARGUMENT  =  6;
   protected static final int HEADER_LENGTH_TWO_ARGUMENT  = 10;
   protected static final int HEADER_LENGTH_THREE_ARGUMENT  = 14;
   
   // Lazy initialization of transmitter
   protected Transmitter getTransmitter() {
      if (transmitter == null)
	 transmitter = XmlStoreHome.getMessageFactory().getTransmitter();
      return transmitter;
   }


   /**
    * Creates an outgoing message with no arguments to a method on the remote 
    * server. This is the protocol:
    * 1) Method   (byte)
    * 2) Number of arguments (byte)
    */
   protected OutgoingMessage createMessageWithNoArguments(byte method) {
      OutgoingMessage message = 
	 XmlStoreHome.getMessageFactory().createOutgoingMessage(HEADER_LENGTH_NO_ARGUMENTS);
      message.putByte(method);
      message.putByte((byte)0);
      return message;
   }


   /**
    * Creates an outgoing message with one argument to a method on the remote 
    * server. This is the protocol:
    * 1) Method   (byte)
    * 2) Number of arguments (byte)
    * 3) Length of argument1 (int)
    * 4) Argument1 (byte[])
    */
   protected OutgoingMessage createMessageWithOneArgument(byte method, 
							byte[] arg1) {
      OutgoingMessage message = 
	 XmlStoreHome.getMessageFactory().createOutgoingMessage(HEADER_LENGTH_ONE_ARGUMENT +
								arg1.length);
      message.putByte(method);
      message.putByte((byte)1);
      message.putInt(arg1.length);
      message.putByteArray(arg1);
      return message;
   }


   /**
    * Creates an outgoing message with two arguments to a method on the remote 
    * server. This is the protocol:
    * 1) Method   (byte)
    * 2) Number of arguments (byte)
    * 3) Length of argument1 (int)
    * 4) Length of argument2 (int)
    * 5) Argument1 (byte[])
    * 6) Argument2 (byte[])
    */
   protected OutgoingMessage createMessageWithTwoArguments(byte method, 
							 byte[] arg1, 
							 byte[] arg2) {
      OutgoingMessage message = 
	 XmlStoreHome.getMessageFactory().createOutgoingMessage(HEADER_LENGTH_TWO_ARGUMENT +
								arg1.length + arg2.length);
      message.putByte(method);
      message.putByte((byte)2);
      message.putInt(arg1.length);
      message.putInt(arg2.length);
      message.putByteArray(arg1);
      message.putByteArray(arg2);
      return message;
   }

   /**
    * Creates an outgoing message with two arguments to a method on the remote 
    * server. This is the protocol:
    * 1) Method   (byte)
    * 2) Number of arguments (byte)
    * 3) Length of argument1 (int)
    * 4) Length of argument2 (int)
    * 5) Length of argument3 (int)
    * 6) Argument1 (byte[])
    * 7) Argument2 (byte[])
    * 8) Argument3 (byte[])
    */
   protected OutgoingMessage createMessageWithThreeArguments(byte method, 
							     byte[] arg1, 
							     byte[] arg2, 
							     byte[] arg3) {
      OutgoingMessage message = 
	 XmlStoreHome.getMessageFactory().createOutgoingMessage(HEADER_LENGTH_THREE_ARGUMENT +
								arg1.length + arg2.length + arg3.length);
      message.putByte(method);
      message.putByte((byte)3);
      message.putInt(arg1.length);
      message.putInt(arg2.length);
      message.putInt(arg3.length);
      message.putByteArray(arg1);
      message.putByteArray(arg2);
      message.putByteArray(arg3);
      return message;
   }


   /**
    * Checks status of an incoming message and throws an remote exception if 
    * status is REMOTE_EXN.
    */
   protected void checkRemoteException(IncomingMessage message) throws RemoteException {
      byte status = message.getByte();
      checkRemoteException(status);
   }

   protected void checkRemoteException(byte status) throws RemoteException {
      if (status != NetworkUtil.ALL_OK) {
	 switch(status)  {	    
	 case NetworkUtil.REMOTE_EXN_SAVE_TO_DISK:
	    throw new RemoteException("Remote Exception: SAVE_TO_DISK");
	 case NetworkUtil.REMOTE_EXN_SAVE_VALUE:
	    throw new RemoteException("Remote Exception: SAVE_VALUE");
	 case NetworkUtil.REMOTE_EXN_SET_SUCESSOR:
	    throw new RemoteException("Remote Exception: SET_SUCESSOR");
	 case NetworkUtil.REMOTE_EXN_SET_PREDECESSOR:
	    throw new RemoteException("Remote Exception: SET_PREDECESSOR");
	 case NetworkUtil.REMOTE_EXN_NOTIFY:
	    throw new RemoteException("Remote Exception: NOTIFY");
	 case NetworkUtil.REMOTE_EXN_UPDATE_FINGER_TABLE:
	    throw new RemoteException("Remote Exception: UPDATE_FINGER_TABLE");
	 case NetworkUtil.REMOTE_EXN_REMOVE_FROM_FINGER_TABLE:
	    throw new RemoteException("Remote Exception: REMOVE_FROM_FINGER_TABLE");
	 case NetworkUtil.REMOTE_EXN_MOVE_KEYS:
	    throw new RemoteException("Remote Exception: MOVE_KEYS");
	 case NetworkUtil.REMOTE_EXN_MOVE_ALL_KEYS:
	    throw new RemoteException("Remote Exception: MOVE_ALL_KEYS");
	 case NetworkUtil.REMOTE_EXN_SUCCESOR:
	    throw new RemoteException("Remote Exception: SUCCESOR");
	 case NetworkUtil.REMOTE_EXN_PREDECESSOR:
	    throw new RemoteException("Remote Exception: PREDECESSOR");
	 case NetworkUtil.REMOTE_EXN_CLOSEST_PRECEDING_FINGER:
	    throw new RemoteException("Remote Exception: CLOSEST_PRECEDING_FINGER");
	 case NetworkUtil.REMOTE_EXN_FIND_PREDECESSOR:
	    throw new RemoteException("Remote Exception: FIND_PREDECESSOR");
	 case NetworkUtil.REMOTE_EXN_FIND_SUCCESSOR:
	    throw new RemoteException("Remote Exception: FIND_SUCCESSOR");
	 case NetworkUtil.REMOTE_EXN_LOAD_VALUE:
	    throw new RemoteException("Remote Exception: LOAD_VALUE");
	 case NetworkUtil.REMOTE_EXN_UNKNOWN_METHOD:
	    throw new RemoteException("Remote Exception: UNKNOWN METHOD");    
	 default:
	    throw new RemoteException("Remote Exception: UNKNOWN METHOD");    
	 }
      }
   }


   protected void checkNameAllreadyBoundException(byte status, String name) throws NameAllreadyBoundException {
      if(status == NetworkUtil.NAME_ALLREADY_BOUND_EXN) {
	 throw new NameAllreadyBoundException(name);
      }
   } 

   protected void checkNoSuchElementException(byte status, String name) throws NoSuchElementException {
      if(status == NetworkUtil.NO_SUCH_ELEMENT_EXN) {
	 throw new NoSuchElementException(name);
      }
   }

   protected void checkConcurrentAccessException(byte status, String name) throws ConcurrentAccessException {
      if(status == NetworkUtil.CONCURRENT_ACCESS_EXN) {
	 throw new ConcurrentAccessException(name);
      }
   }
   
   /**
    * Retrieves the return value of an incoming message. This is the protocol:
    * 1) Status   (byte)
    * 2) Length of return value (int)
    * 3) Return value (byte[])
    */
   protected byte[] getReturnValue(IncomingMessage reply) {      
      int length = reply.getInt();
      return reply.getByteArray(length);
   }
}
