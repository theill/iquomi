package edu.it.xmlstore.rpc.udp;

import edu.it.xmlstore.rpc.IncomingMessage;
import java.util.Iterator;


public class IncomingUdpMessage extends AbstractUdpMessage implements IncomingMessage {
   private boolean isException;
   private String errorMessage;

   public IncomingUdpMessage(int id) {
      fragments = new FragmentList(id);
      isException = false;
   }   
   
   public void addFragment(MessageFragment fragment) {
      fragments.add(fragment);
   }
   
   // Checks that this message contains all fragments.
   public boolean isComplete() {
      // If we have been marked as an exception we are complete
      if (isException) 
	 return true;

      // Otherwise check fragments
      boolean result = false;
      if (fragments.size() > 0) {
	 // Read expected values from first fragment
	 MessageFragment first = fragments.iterator().next();
	 int expectedId = first.getId();
	 int expectedTotal = first.getTotal();
	 
	 // Check completeness
	 int correctFragments = 0;
	 int number = 1;
	 FragmentList.Iterator i = fragments.iterator();
	 while (i.hasNext()) {
	    MessageFragment frag = (MessageFragment)i.next();
	    if (frag.getNumber() == number++) correctFragments++;  
	 }
	 result = correctFragments == expectedTotal;
      }
      return result;
   }
   
   public void setException(String errorMessage) {
      // Note that we are an exception and reset fragments
      isException = true;
      this.errorMessage = errorMessage;
   }

   public boolean isException() {
      return isException;
   }
   
   public String getErrorMessage() {
      return errorMessage;
   }
   
   
   public byte getByte() {
      return fragments.getByte();
   }


   public byte[] getByteArray(int length) {
      return fragments.getByteArray(length);
   }

   public int getInt() {
      return fragments.getInt();
   }
}
