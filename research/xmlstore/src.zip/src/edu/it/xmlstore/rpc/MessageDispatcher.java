package edu.it.xmlstore.rpc;

import edu.it.xmlstore.rpc.RemoteException;

/**
 * Determines the type of a method and invokes the corresponding method on the
 * actual (remote) object.
 */
public interface MessageDispatcher {
   public OutgoingMessage receive(IncomingMessage inMessage);
}
