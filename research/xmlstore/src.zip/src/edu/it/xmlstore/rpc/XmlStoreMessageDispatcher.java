package edu.it.xmlstore.rpc;

import edu.it.xmlstore.rpc.NetworkUtil;
import edu.it.xmlstore.XmlStoreServer;
import edu.it.xmlstore.rpc.XmlStoreServerProxy;
import edu.it.xmlstore.ValueReference;
import edu.it.xmlstore.ValueUtil;
import edu.it.xmlstore.rpc.XmlStoreServerProxy;
import edu.it.xmlstore.XmlStoreHome;
import edu.it.xmlstore.XmlStoreServerImpl;
import edu.it.xmlstore.rpc.IncomingMessage;
import edu.it.xmlstore.chord.*;
import java.io.DataOutputStream;
import java.io.BufferedOutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.*;
import java.io.IOException;
import java.math.BigInteger;
import java.net.InetSocketAddress;
import java.net.DatagramSocket;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * Determines the type of method and invokes the corresponding method on the
 * actual XmlStoreServerImpl. 
 * Returns an outgoing message.
 * Called by MessageTransmitter.
 */
public class XmlStoreMessageDispatcher implements MessageDispatcher {
   private XmlStoreServer xmlStoreServer;
   private Transmitter transmitter;
   

   public XmlStoreMessageDispatcher(XmlStoreServer xmlStoreServer) {
      if (xmlStoreServer instanceof XmlStoreServerImpl)
	 this.xmlStoreServer = xmlStoreServer;
      else
	 throw new RuntimeException("Incompatible XmlStoreServer, expected XmlStoreServerImpl.");
   }
   
   // Useful for testing
   public void setTransmitter(Transmitter t) {
      transmitter = t;
   }


   public OutgoingMessage receive(IncomingMessage inMessage) {
      // make sure transmitter is initialized
      if (transmitter == null)
	 transmitter = XmlStoreHome.getMessageFactory().getTransmitter();
      
      // Wrap message in protocol
      XmlStoreMessageProtocol message = new XmlStoreMessageProtocol(inMessage, transmitter);

      switch(message.getMethod())  {
	 // Methods that only return status:
      case NetworkUtil.SAVE_TO_DISK:
	 return handleSaveToDisk(message);
      case NetworkUtil.SAVE_VALUE:
	 return handleSaveValue(message);
      case NetworkUtil.SET_SUCCESSOR:
	 return handleSetSuccessor(message);
      case NetworkUtil.SET_PREDECESSOR:
	 return handleSetPredecessor(message);
      case NetworkUtil.NOTIFY:
	 return handleNotify(message);
      case NetworkUtil.UPDATE_FINGER_TABLE:
	 return handleUpdateFingerTable(message);
      case NetworkUtil.REMOVE_FROM_FINGER_TABLE:
	 return handleRemoveFromFingerTable(message);
      case NetworkUtil.MOVE_KEYS:
	 return handleMoveKeys(message);
      case NetworkUtil.MOVE_ALL_KEYS:
	 return handleMoveAllKeys(message);
	 // Methods that return an XmlstoreServer.	 
      case NetworkUtil.SUCCESSOR:
	 return handleSuccessor(message);
      case NetworkUtil.PREDECESSOR:
	 return handlePredecessor(message);
      case NetworkUtil.CLOSEST_PRECEDING_FINGER:
	 return handleClosestPrecedingFinger(message);
      case NetworkUtil.FIND_PREDECESSOR:
	 return handleFindPredecessor(message);
      case NetworkUtil.FIND_SUCCESSOR:
	 return handleFindSuccessor(message);
	 // Method that returns a value.
      case NetworkUtil.LOAD_VALUE:
	 return handleLoadValue(message);
      default:
	 return createOutgoingMessageStatus(NetworkUtil.REMOTE_EXN_UNKNOWN_METHOD, inMessage);
      }
   }  

   // ----------------- Method handlers --------------------

   // Methods handlers for methods that only return a status.

   private OutgoingMessage handleSaveToDisk(XmlStoreMessageProtocol message) {
      byte status = NetworkUtil.ALL_OK;
      byte[] val = message.nextArg();
      ValueReference ref = message.nextArgValueReference();
      try {
         xmlStoreServer.saveToDisk(val, ref);
      }
      catch (RemoteException e) {
         System.out.println("Exception in handleSaveToDisk: " + e);
         status = NetworkUtil.REMOTE_EXN_SAVE_TO_DISK;
      }
      return createOutgoingMessageStatus(status, message.getIncomingMessage());
   }


   private OutgoingMessage handleSaveValue(XmlStoreMessageProtocol message) {
      byte status = NetworkUtil.ALL_OK;
      byte[] val = message.nextArg();
      ValueReference ref = message.nextArgValueReference();
      try {
         xmlStoreServer.saveValue(val, ref);
      }
      catch (RemoteException e) {
         System.out.println("Exception in handleSaveValue: " + e);
         status = NetworkUtil.REMOTE_EXN_SAVE_VALUE;
      }
      return createOutgoingMessageStatus(status, message.getIncomingMessage());
   }


   private OutgoingMessage handleSetSuccessor(XmlStoreMessageProtocol message) {
      byte status = NetworkUtil.ALL_OK;
      XmlStoreServer n = null;
      try {
         n = message.nextArgXmlStoreServer(); 
         xmlStoreServer.setSuccessor(n);
      }
      catch (RemoteException e) {
         System.out.println("Exception in handleSetSuccessor: " + e);
         status = NetworkUtil.REMOTE_EXN_SET_SUCESSOR;
      }
      return createOutgoingMessageStatus(status, message.getIncomingMessage());
   }
   

   private OutgoingMessage handleSetPredecessor(XmlStoreMessageProtocol message) {
      byte status = NetworkUtil.ALL_OK;
      XmlStoreServer n = null;
      try {
         n = message.nextArgXmlStoreServer();
         xmlStoreServer.setPredecessor(n);
      }
      catch (RemoteException e) {
         System.out.println("Exception in handleSetPredecessor: " + e);
         status = NetworkUtil.REMOTE_EXN_SET_PREDECESSOR;
      }
      return createOutgoingMessageStatus(status, message.getIncomingMessage());
   }

   
   private OutgoingMessage handleNotify(XmlStoreMessageProtocol message) {
      byte status = NetworkUtil.ALL_OK;
      XmlStoreServer n = null;
      try {
         n = message.nextArgXmlStoreServer();
         xmlStoreServer.notify(n);
      }
      catch (RemoteException e) {
         System.out.println("Exception in handleNotify: " + e);
         status = NetworkUtil.REMOTE_EXN_NOTIFY;
      }
      return createOutgoingMessageStatus(status, message.getIncomingMessage());
   }


   private OutgoingMessage handleUpdateFingerTable(XmlStoreMessageProtocol message) {
      byte status = NetworkUtil.ALL_OK;
      XmlStoreServer n = null;
      int i = 0;
      try {
         n = message.nextArgXmlStoreServer();
         i = message.nextArgInt();
         xmlStoreServer.updateFingerTable(n, i);
      }
      catch (RemoteException e) {
         System.out.println("Exception in handleUpdateFingerTable: " + e);
         status = NetworkUtil.REMOTE_EXN_UPDATE_FINGER_TABLE;
      }
      return createOutgoingMessageStatus(status, message.getIncomingMessage());
   }


   private OutgoingMessage handleRemoveFromFingerTable(XmlStoreMessageProtocol message) {
      byte status = NetworkUtil.ALL_OK;
      XmlStoreServer n = null;
      int i;
      try {
         n = message.nextArgXmlStoreServer();
         i = message.nextArgInt();
         xmlStoreServer.removeFromFingerTable(n, i);
      }
      catch (RemoteException e) {
         System.out.println("Exception in handleRemoveFromFingerTable: " + e);
         status = NetworkUtil.REMOTE_EXN_REMOVE_FROM_FINGER_TABLE;
      }
      return createOutgoingMessageStatus(status, message.getIncomingMessage());
   }


   private OutgoingMessage handleMoveKeys(XmlStoreMessageProtocol message) {
      byte status = NetworkUtil.ALL_OK;
      XmlStoreServer n = null;
      try {
         n = message.nextArgXmlStoreServer();
         xmlStoreServer.moveKeys(n);
      }
      catch (RemoteException e) {
         System.out.println("Exception in handleMoveKeys: " + e);
         status = NetworkUtil.REMOTE_EXN_MOVE_KEYS;
      }
      return createOutgoingMessageStatus(status, message.getIncomingMessage());
   }


   private OutgoingMessage handleMoveAllKeys(XmlStoreMessageProtocol message) {
      byte status = NetworkUtil.ALL_OK;
      XmlStoreServer n = null;
      try {
         n = message.nextArgXmlStoreServer();
         xmlStoreServer.moveAllKeys(n);
      }
      catch (RemoteException e) {
         System.out.println("Exception in handleMoveAllKeys: " + e);
         status = NetworkUtil.REMOTE_EXN_MOVE_ALL_KEYS;
      }
      return createOutgoingMessageStatus(status, message.getIncomingMessage());
   }

   // Methods handlers for methods that returns an XmlStoreServer.

   private OutgoingMessage handleSuccessor(XmlStoreMessageProtocol message) {
      XmlStoreServer n = null;
      OutgoingMessage reply = null;
      try {
         n = (XmlStoreServer)xmlStoreServer.successor();
      }
      catch (RemoteException e) {
         System.out.println("Exception in handleSuccessor: " + e);
	 return createOutgoingMessageStatus(NetworkUtil.REMOTE_EXN_SUCCESOR, 
					    message.getIncomingMessage());
      }
      return createOutgoingMessageValue(n, message.getIncomingMessage());
   }


   private OutgoingMessage handlePredecessor(XmlStoreMessageProtocol message) {
      XmlStoreServer n = null;
      try {
         n = (XmlStoreServer)xmlStoreServer.predecessor();
      }
      catch (RemoteException e) {
         System.out.println("Exception in handlePredecessor: " + e);
	 return createOutgoingMessageStatus(NetworkUtil.REMOTE_EXN_PREDECESSOR, 
					    message.getIncomingMessage());
      }
      return createOutgoingMessageValue(n, message.getIncomingMessage());
   }


   private OutgoingMessage handleClosestPrecedingFinger(XmlStoreMessageProtocol message) {
      ChordId chordId = message.nextArgChordId();
      XmlStoreServer n = null;
      try {
         n = (XmlStoreServer) xmlStoreServer.closestPrecedingFinger(chordId);
      }
      catch (RemoteException e) {
	 System.out.println("Exception in handleClosestPrecedingFinger: " + e);
	 return createOutgoingMessageStatus(NetworkUtil.REMOTE_EXN_CLOSEST_PRECEDING_FINGER, 
					    message.getIncomingMessage());
      }
      return createOutgoingMessageValue(n, message.getIncomingMessage());
   }


   private OutgoingMessage handleFindPredecessor(XmlStoreMessageProtocol message) {
      ChordId chordId = message.nextArgChordId();
      XmlStoreServer n = null;
      try {
         n = (XmlStoreServer)xmlStoreServer.findPredecessor(chordId);
      }
      catch (RemoteException e) {
	 System.out.println("Exception in handleFindPredecessor: " + e);
	 return createOutgoingMessageStatus(NetworkUtil.REMOTE_EXN_FIND_PREDECESSOR, 
					    message.getIncomingMessage());
      }
      return createOutgoingMessageValue(n, message.getIncomingMessage());
   }


   private OutgoingMessage handleFindSuccessor(XmlStoreMessageProtocol message) {
      ChordId chordId = message.nextArgChordId();
      XmlStoreServer n = null;
      try {
	 n = (XmlStoreServer)xmlStoreServer.findSuccessor(chordId);
      }
      catch (RemoteException e) {
         System.out.println("Exception in handleFindSuccessor: " + e);
	 return createOutgoingMessageStatus(NetworkUtil.REMOTE_EXN_FIND_SUCCESSOR, 
					    message.getIncomingMessage());
      }
      return createOutgoingMessageValue(n, message.getIncomingMessage());
   }

   // Method handler for method that returns a value.

   private OutgoingMessage handleLoadValue(XmlStoreMessageProtocol message) {
      byte status = NetworkUtil.ALL_OK;
      ValueReference id = message.nextArgValueReference();
      byte[] result = null;
      try {
         result = xmlStoreServer.loadValue(id);
      }
      catch (RemoteException e) {
         System.out.println("Exception in handleLoadValue: " + e);
         return createOutgoingMessageStatus(NetworkUtil.REMOTE_EXN_LOAD_VALUE, 
					    message.getIncomingMessage());
      }
      OutgoingMessage reply = 
	 XmlStoreHome.getMessageFactory().createOutgoingMessage(message.getIncomingMessage(),
								NetworkUtil.STATUS_LENGTH + 
								NetworkUtil.INT_LENGTH +
								result.length);
      reply.putByte(NetworkUtil.ALL_OK);
      reply.putInt(result.length);
      reply.putByteArray(result);
      return reply;
   }


   // ********** Helper methods **********


   // Returns an outgoing message that only contains status.
   private OutgoingMessage createOutgoingMessageStatus(byte status, IncomingMessage message) {
      OutgoingMessage reply =
	 XmlStoreHome.getMessageFactory().createOutgoingMessage(message,
								NetworkUtil.STATUS_LENGTH);
      reply.putByte(status);
      return reply;
   }


   /**
    * Returns an outgoing message that contains status = ALL_OK and an 
    * XmlstoreServer as return value. This is the protocol:
    * 1) Status   (byte)
    * 2) Length of return value (int)
    * 3) Return value (byte[])
    */
   private OutgoingMessage createOutgoingMessageValue(XmlStoreServer n, IncomingMessage message) {
      byte[] xmlStoreAsBytes = NetworkUtil.encodeXmlStoreServer(n);
      OutgoingMessage reply = XmlStoreHome.getMessageFactory().createOutgoingMessage(message,
										     NetworkUtil.STATUS_LENGTH +
										     NetworkUtil.INT_LENGTH +
										     xmlStoreAsBytes.length);
      reply.putByte(NetworkUtil.ALL_OK);
      reply.putInt(xmlStoreAsBytes.length);
      reply.putByteArray(xmlStoreAsBytes);
      return reply;
   }



   // *************************************************'
   
   /**
    * Inner class that represents a RMI-call from a proxy to an XmlStoreServer. 
    * It extracts the arguments from an incoming message.
    * This is the protocol:
    * 1) Method   (byte)
    * 2) Number of arguments (byte) (0, 1 or 2)
    * 3) Length of argument1 (int)  (only for methods with one and two arguments)
    * 4) Length of argument2 (int)  (only for methods with two arguments)
    * 5) Argument1 (byte[])         (only for methods with one and two arguments)
    * 6) Argument2 (byte[])         (only for methods with two arguments)
    */
   private static class XmlStoreMessageProtocol {
      private IncomingMessage message;
      private byte method;
      private byte numberOfArguments;
      public int[] argLengths;
      private int argsRead = 0;
      private ByteBuffer readBuffer;
      private byte[] byteArray;
      private Transmitter transmitter;
      
      public XmlStoreMessageProtocol(IncomingMessage m, Transmitter transmitter) {
	 try {
	    message = m;
	    this.transmitter = transmitter;
	    // Extract protocol information from incoming message.
	    method = message.getByte();
	    numberOfArguments = message.getByte();
	    argLengths = new int[numberOfArguments];
	    for (int i = 0; i < numberOfArguments; i++)
	       argLengths[i] = message.getInt();
	 }
	 catch (IndexOutOfBoundsException e) {
	    e.printStackTrace(System.out);
	    System.out.println("Exception in XmlStoreMessageProtocol: " + m);
	 }
      }


      public byte getMethod() {
	 return method;
      }
      

      public IncomingMessage getIncomingMessage() {
	 return message;
      }


      public ValueReference nextArgValueReference() {
	 return ValueUtil.decode(nextArg());
      }

	 
      public XmlStoreServer nextArgXmlStoreServer() throws RemoteException {
	 return NetworkUtil.decodeXmlStoreServer(nextArg(), transmitter);
      }

      
      public int nextArgInt() {
	 return message.getInt();
      }
      
      
      public ChordId nextArgChordId() {
	 return (ChordId)ValueUtil.decode(nextArg());
      }


      public byte[] nextArg() { 
	 assert argsRead < numberOfArguments : "Error in Message. No more arguments!";
	 return message.getByteArray(argLengths[argsRead++]);
      }
   }
}
