package edu.it.xmlstore.rpc.udp;

import edu.it.xmlstore.rpc.Transmitter;
import edu.it.xmlstore.rpc.NetworkUtil;
import edu.it.xmlstore.rpc.RemoteException;
import edu.it.xmlstore.rpc.IncomingMessage;
import edu.it.xmlstore.rpc.OutgoingMessage;
import edu.it.xmlstore.rpc.MessageDispatcher;
import java.net.*;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.LinkedList;
import java.util.HashMap;
import java.util.Map;
import java.util.Collections;
import java.util.Iterator;

public class UdpTransmitter implements Transmitter {

   // Class that dispatches the incoming messages 
   MessageDispatcher dispatcher;

   // Socket, port, incoming and outgoing packets and slave threads 
   private DatagramSocket socket;
   private int port;
   private DatagramQueue inbox, outbox;
   private TransmitterThread transmitter;
   private ReceiverThread receiver;
  
   // Pending outgoing messages are handled by message manager.
   private MessageManager messageManager;
   private Map pendingOutgoingMessages;

   // Pending incoming messages are handled by the 
   // pending incoming message manager.
   private Map pendingIncomingMessages;
   PendingIncomingMessageManager pendingIncomingMessageManager;
      
   // We need to sort incoming requests according to their type.
   private static final int NO_OF_INBOX_MANAGERS = 5;
   private InboxManager[] inboxManagers = new InboxManager[NO_OF_INBOX_MANAGERS];

   // Constants for configuring the udp layer
   private static final int MAX_RETRY_ATTEMPTS = 5;
   private static final int TIME_BETWEEN_ACTION = 5000;

   // Constructor
   public UdpTransmitter(int port, MessageDispatcher dispatcher) throws RemoteException {
      this.dispatcher = dispatcher;
      try {
	 // Configure socket
	 this.port = port;
	 socket = new DatagramSocket(port);
	 socket.setTrafficClass(0x04); // Maximize reliability according to RFC 1349
	 socket.setReceiveBufferSize(MessageFragment.MAX_DATAGRAM_SIZE);


	 // Synchronized queues of datagrams
	 outbox = new DatagramQueue();
	 inbox = new DatagramQueue();
	 
	 // List of pending incoming and outgoing messages.
	 pendingOutgoingMessages = Collections.synchronizedMap(new HashMap(37));
	 pendingIncomingMessages = Collections.synchronizedMap(new HashMap(37));
	 
	 // Threads
	 transmitter = new TransmitterThread();
	 transmitter.start();
	 receiver = new ReceiverThread();
	 receiver.start();
	 messageManager = new MessageManager();
	 messageManager.start();

	 for (int i = 0; i < NO_OF_INBOX_MANAGERS; i++) {
	    inboxManagers[i] = new InboxManager();
	    inboxManagers[i].start();
	 }

	 pendingIncomingMessageManager = new PendingIncomingMessageManager();
	 pendingIncomingMessageManager.start();
      }
      catch (Throwable e) {
	 throw new RemoteException("Error initializing UdpTransmitter@" + port + ": " + e);
      }
   }

   public void close() {
      socket.close();
      transmitter.interrupt();
      receiver.interrupt();
      messageManager.interrupt();
      for (int i = 0; i < NO_OF_INBOX_MANAGERS; i++) 
	 inboxManagers[i].interrupt();

      pendingIncomingMessageManager.interrupt();      
   }


   public IncomingMessage send(OutgoingMessage message, SocketAddress receiver) throws RemoteException {      
      if (message instanceof OutgoingUdpMessage) {
	 // create blocking message/command, put in queue
	 PendingOutgoingMessage pendingMessage = messageManager.sendMessage((OutgoingUdpMessage)message, receiver, true);

	 // wait for return value/exception
	 IncomingUdpMessage reply = pendingMessage.getReply();
	 if (reply.isException())
	    throw new RemoteException(reply.getErrorMessage());
	 else
	    return reply;
      }
      else 
	 throw new RuntimeException("Incompatible message, expected OutgoingUdpMessage");
   }


   // Send a message without blocking for the reply.
   public void sendAsynchronous(OutgoingMessage message, SocketAddress receiver) {      
      if (message instanceof OutgoingUdpMessage) {
	 // create non-blocking message/command, put in queue.
	 messageManager.sendMessage((OutgoingUdpMessage)message, receiver, false);
      }
      else 
	 throw new RuntimeException("Incompatible message, expected OutgoingUdpMessage");
   }


   // Send outgoing message possibly consisting of several fragments.   
   private void sendFragments(OutgoingUdpMessage message, SocketAddress receiver) {
      FragmentList.Iterator ite = message.iterator();
      while (ite.hasNext())
	 outbox.put(ite.next(), receiver);
   }


   // Retransmit fragment "fragmentNumber" of message to receiver.
   private void retransmit(int fragmentNumber, AbstractUdpMessage message, 
			   SocketAddress receiver) {
      FragmentList.Iterator fragments = message.iterator();
      MessageFragment fragment = null;
      while (fragments.hasNext()) 
	 if ((fragment = fragments.next()).getNumber() == fragmentNumber)
	    break;
      outbox.put(fragment, receiver);
   }

   
   // Request retransmission of "fragmentNumber" of message (id) to receiver.
   // The type is: TYPE_RETRANSMIT_REPLY or TYPE_RETRANSMIT_REQUEST.
   private void requestRetransmit(int fragmentNumber, byte type, int id, 
				  SocketAddress receiver) {
      MessageFragment fragment = new MessageFragment(id,
						    (int)NetworkUtil.INT_LENGTH, // One int arg 
						    type,         // Just the missing packets
						    (short)1,     // The number of the packet
						    (short)1);    // Total packages in reply
      fragment.putInt(0, fragmentNumber);
      outbox.put(fragment, receiver);
   }
   

   // Sends the status of a request.
   private void sendStatus(byte status, int id, SocketAddress receiver) {
      MessageFragment fragment = new MessageFragment(id,
						     1, 
						     MessageFragment.TYPE_STATUS,       
						     (short)1,     
						     (short)1);    
      fragment.putByte(0, status);
      outbox.put(fragment, receiver);
   }


   // Sends STATUS_COMPLETE and the total number of fragments of the reply.
   private void sendStatusComplete(byte status, int id, int total, 
				   SocketAddress receiver) {
      MessageFragment fragment = new MessageFragment(id,
						     1 + (int)NetworkUtil.INT_LENGTH, 
						     MessageFragment.TYPE_STATUS,       
						     (short)1,     
						     (short)1);    
      fragment.putByte(0, status);
      fragment.putInt(1, total);  
      outbox.put(fragment, receiver);
   }
   

   // ************ Inner classes **************



   /** 
    *  A synchronized queue of UDP datagrams
    */
   private static class DatagramQueue {
      
      private static class Entry {
	 public MessageFragment fragment;
	 public SocketAddress address;

	 public Entry(MessageFragment fragment, SocketAddress address) {
	    this.fragment = fragment;
	    this.address  = address;
	 }
      }      

      private LinkedList list = new LinkedList();
      
      public synchronized void put(MessageFragment fragment, SocketAddress address) {
	 list.addFirst(new Entry(fragment, address));
	 notifyAll();
      }

      public synchronized Entry get() {
	 try {
	    while ( list.isEmpty() ) {wait();}
	 }
	 catch (InterruptedException e) {
	    // okay, we are terminating the thread
	 }
	 return (Entry) list.removeLast();
     }
   } // End inner class



   /** 
    *  Class representing a message that is not yet finished,
    *  ie. has not yet received reply.
    *  This class acts as a monitor.
    */
   private class PendingOutgoingMessage {
      // An RPC is comprised of a message to a receiver and a reply
      public OutgoingUdpMessage message;
      public SocketAddress receiver;
      public IncomingUdpMessage reply;
      private boolean blocking;

      // State variables keeping track of transmission progress.
      // We need to keep track of when the last action was tried.
      private long progress;
      private int retries;

      public PendingOutgoingMessage(OutgoingUdpMessage message, SocketAddress receiver, boolean blocking) {
	 // set messages
	 this.message = message;
	 this.receiver = receiver;
	 this.reply = new IncomingUdpMessage(message.getId());
	 this.blocking = blocking;

	 // reset error handling state
	 this.progress = System.currentTimeMillis();
	 this.retries = 0;
      }


      // This method decides what to do with a received fragment
      // that is associated with this message
      public synchronized void processIncomingFragment(MessageFragment fragment) {
	 // We have received something, so note progress and reset retries
	 progress();
	 retries = 0;
	 
	 // Act according to what type of fragment we have received
	 //switch( fragment.getType() ) {
	 switch( fragment.getType() ) {
	    // Retransmission of part of outgoing message is required
	 case MessageFragment.TYPE_RETRANSMIT_REQUEST:	    
	    // Read which fragment is missing and retransmit it 
	    int missing = fragment.getInt(0);
	    retransmit(missing, message, receiver);
	    break;
	    // Part of the reply has been received
	 case MessageFragment.TYPE_REPLY:
	    reply.addFragment(fragment);	       
	    break;
	    // Status message has been received
	 case MessageFragment.TYPE_STATUS:
	    // Check whether we are running or an exception has been thrown  
	    byte status = fragment.getByte(0);
	    if (status == MessageFragment.STATUS_RUNNING) {
	       // OK, receiver needs more time -- we allready noted progress
	    }
	    else if (status == MessageFragment.STATUS_UNKNOWN)
	       // The receiver does not know the request. Therefore we send 
	       // the request again.
	       sendFragments(message, receiver);
	    else if (status == MessageFragment.STATUS_COMPLETE) {
	       // The request is complete, but we have not yet received the reply.
	       // Therefore the receiver should retransmit all the fragments of the reply.
	       int total = fragment.getInt(1);
	       for (int i=1; i <= total; i++)
		  requestRetransmit(i, MessageFragment.TYPE_RETRANSMIT_REPLY, fragment.getId(), 
				    receiver);
	    }
	    else
	       System.out.println("Unknown status (" + status + ") received from " + receiver);

	    break;
	 default:
	    throw new RuntimeException( "Unknown type in OutgoingPendingMessage: " + fragment.getType() );
	 }

	 // If we are finished and the call is blocking: notify waiting threads.
	 if(reply.isComplete() && blocking)
	    notifyAll();
      }


      public synchronized IncomingUdpMessage getReply() {
	 try {
	    while (!reply.isComplete())
	       wait();
	    pendingOutgoingMessages.remove(new Integer(message.getId()));
	    return reply;
	 }
	 catch(InterruptedException e) {
	    throw new RuntimeException("UdpTransmitter interrupted: " + e);	       
	 }
      } 


      // Process.
      public synchronized void process() { 
	 // Check whether message is complete before doing anything!
	 if ( !reply.isComplete() ) {
	    // Check if message has timed out
	    if ( isTimeForAction() )
	       nextAction();
	 }
	 // Remove the complete non-blocking call from the list of pending outgoing messages.
	 else if (! blocking) {
	    pendingOutgoingMessages.remove(new Integer(message.getId()));
	 }
      }


      // Determines whether it has been too long since any progress was made,
      // and if it is time to take action, eg. request status or retransmission
      private boolean isTimeForAction() {
	 long now = System.currentTimeMillis();
	 return (now - progress) > TIME_BETWEEN_ACTION;	 
      }

      // Notes the last time there was progress, eg. we either received 
      // something or did something
      private void progress() {
	 progress = System.currentTimeMillis();
      }

      // Perform some action to continue pending message.
      private void nextAction() {
	 progress();
	 
	 // Retry a given number of times or throw exception
	 if (retries < MAX_RETRY_ATTEMPTS)
	    retry();
	 else {
	     reply.setException("Time Out. Destination cannot be reached: " + receiver);
	     notifyAll();	 
	 }	
      }
      
      // Request retransmission of reply fragments not yet received
      private void retry() {
    	 // Remember that we have retried once again
         retries++;

	 // Find out what we have received so far
	 FragmentList.Iterator receivedFrags = reply.iterator();

	 // If we have received at least one reply fragment then request the missing packets
	 if (receivedFrags.hasNext()) {
	    boolean[] received = null;
	    do {	       
	       MessageFragment f = receivedFrags.next();
	       // Initialize received if necessary
	       if (received == null) {		  
		  received = new boolean[f.getTotal() + 1]; // Remember that total counts from [1..n]
	       }
	       received[f.getNumber()] = true;

	    } while (receivedFrags.hasNext());
	    
	    // Run through received and request retransmission of packets not received
	    for (int i = 1; i < received.length; i++)
	       if ( !received[i] )
		  requestRetransmit(i, MessageFragment.TYPE_RETRANSMIT_REPLY, 
				    message.getId(), receiver);  
	 }
	 else {
	    // If we have not received anything, request status
	    requestStatus();
	 }	    
      }


      // Request status update on message (id) from receiver. 
      private void requestStatus() {
	 MessageFragment fragment = new MessageFragment(message.getId(),
							0,           // No arg
							MessageFragment.TYPE_STATUS_REQUEST,
							(short)1,    // The number of the packet
							(short)1);   // Total packages in reply
	 outbox.put(fragment, receiver);
      }
   } // End inner class
   
   
   /** 
    *  Class that handles retransmission in case of missing replies etc.
    */
   private class MessageManager extends Thread {
      
      public PendingOutgoingMessage sendMessage(OutgoingUdpMessage message, SocketAddress receiver, boolean blocking) {

	 // Note that we are initiating an RPC
	 // so we can later check replies and status
	 PendingOutgoingMessage pm = new PendingOutgoingMessage(message, receiver, blocking);
	 pendingOutgoingMessages.put(new Integer(pm.message.getId()), pm);

	 // Send message possibly consisting of several fragments.
	 sendFragments(message, receiver);

	 return pm;
      }
      

      // Checks all pending messages and responds accordingly
      private static final int WAITING_TIME = 40;
      public void run() {
	 while( !isInterrupted() ) {
	    // Run through pending messages, checking if they
	    // have timed out, need retransmission, etc.
	    PendingOutgoingMessage[] current = 
	       (PendingOutgoingMessage[]) pendingOutgoingMessages.values().toArray(new PendingOutgoingMessage[0]);
	    for (int i = 0; i < current.length; i++)
	       current[i].process();

	    // wait a bit before going again (to avoid busy waiting)	    
	    try {
	       Thread.sleep(WAITING_TIME);
	    }
	    catch(InterruptedException e) {
	       // OK, we have been interrupted
	    }
	 }
      }
   }


   /** 
    *  Looks at incoming packages, determining
    *  whether they are incoming RPC requests or replies to earlier
    *  outgoing messages.
    */
   private class InboxManager extends Thread {

      public void run() {
	 while ( !isInterrupted() ) {
	    // find type of message and find id.
	    DatagramQueue.Entry entry = inbox.get();
	    IncomingUdpMessageId messageId = 
	       new IncomingUdpMessageId(entry.fragment.getId(), entry.address);

	    switch( entry.fragment.getType() ) {
	       // Message has something to do with a pending incoming message.

	    case MessageFragment.TYPE_REQUEST:
	       // Another XmlStore sends a request to this XmlStore.
	       if (pendingIncomingMessages.containsKey(messageId)) {
		  // The request is already in pending incoming messages, so add fragment.
		  PendingIncomingMessage pm = (PendingIncomingMessage) pendingIncomingMessages.get(messageId);
		  pm.addFragment(entry.fragment);
	       }
	       else {
		  // Insert new message in pending incoming messages and add fragment.
		  PendingIncomingMessage pm = new PendingIncomingMessage(entry.fragment.getId(), entry.address);
		  pendingIncomingMessages.put(messageId, pm); 
		  pm.addFragment(entry.fragment);
	       }
	       break;
	    case MessageFragment.TYPE_RETRANSMIT_REPLY:
	       // Another XmlStore has sent a request to this XmlStore. It has received some of the 
	       // reply but it is missing some fragments. It therefore wants this XmlStore to retransmit
	       // the missing fragments of the reply.
	       if (pendingIncomingMessages.containsKey(messageId)) {
		  int missing = entry.fragment.getInt(0);
		  PendingIncomingMessage pm = (PendingIncomingMessage) pendingIncomingMessages.get(messageId);
		  retransmit(missing, pm.reply, pm.receiver);
	       }
	       else
		  System.out.println("Retransmit reply: Could not find id in pendingIncomingMessages: " + messageId);
	       break;
	    case MessageFragment.TYPE_STATUS_REQUEST:	     
	       // Another XmlStore wants to know the status of a request it has sent earlier.
	       if (pendingIncomingMessages.containsKey(messageId)) {
		  PendingIncomingMessage pm = (PendingIncomingMessage) pendingIncomingMessages.get(messageId);
		  if (pm.getStatus() == MessageFragment.STATUS_COMPLETE)
		     sendStatusComplete(MessageFragment.STATUS_COMPLETE, entry.fragment.getId(),
					(int)entry.fragment.getTotal(), pm.receiver);
		  else
		     sendStatus(pm.getStatus(), entry.fragment.getId(), pm.receiver);
	       }
	       else
		  // The request is not in the list of pending messages.
		  sendStatus(MessageFragment.STATUS_UNKNOWN, entry.fragment.getId(), 
			     entry.address);
	       break;


	       // Message has something to do with a pending outgoing message
	    case MessageFragment.TYPE_RETRANSMIT_REQUEST:
	    case MessageFragment.TYPE_REPLY:
	    case MessageFragment.TYPE_STATUS:
	       Integer id = new Integer(entry.fragment.getId());
	       if (pendingOutgoingMessages.containsKey(id)) {
		  PendingOutgoingMessage pendingMessage = 
		     (PendingOutgoingMessage) pendingOutgoingMessages.get(id);
		  pendingMessage.processIncomingFragment(entry.fragment);
	       }
	       else // Log that we could not find message
		  System.out.println("Could not find id in pendingOutgoingMessages: " + entry.fragment);
	       break;
	    default:
       	       System.out.println("Type: Unknown type: " + entry.fragment.getType());	       
	    }
	 }
      }
   } // End inner class


   // Used as an id of an incoming request in the list of pending messages.
   private class IncomingUdpMessageId {
      public int id;
      public InetSocketAddress receiver;


      public IncomingUdpMessageId(int id, SocketAddress receiver) {
	 this.id = id;
	 this. receiver = (InetSocketAddress)receiver;
      }
      
      
      public boolean equals(Object other) {
	 if (other instanceof IncomingUdpMessageId) {
	    IncomingUdpMessageId that = (IncomingUdpMessageId) other;
	    return ((id == that.id) && receiver.equals(that.receiver));
	 } 
	 else
	    return false;
      }

  
      public int hashCode() {
	 return (id + receiver.hashCode());
      }


      public String toString() {
	 return "id: " + id + " from: " + receiver.toString();
      }
   }



   /** 
    *  Simple thread transmitting datagrams in the outbox, if any.
    */
   private class TransmitterThread extends Thread {
      // See if there are messages in the outbox to be sent...
      // If there are, do so!
      public void run() {
	 while (! isInterrupted() ) {
	    try {
	       DatagramQueue.Entry entry = outbox.get();
	       DatagramPacket packet = new DatagramPacket(entry.fragment.asArray(), 
							  entry.fragment.asArray().length, 
							  entry.address);
	       socket.send(packet);
	       //System.out.println("UDPT@" + port + ": Sent packet to " + entry.address + " type: " + entry.fragment.getType());
	    }
	    catch(Throwable e) {
	       System.out.println("Error in TransmitterThread: " + e);	       
	    }
	 }
      }
   } // End inner class


   /** 
    *  Simple thread receiving incoming datagrams and placing them in the inbox.
    */
   private class ReceiverThread extends Thread {
      private byte[] mem = new byte[MessageFragment.MAX_DATAGRAM_SIZE];
      private ByteBuffer buffer = ByteBuffer.wrap(mem);
      private DatagramPacket packet = new DatagramPacket(mem, MessageFragment.MAX_DATAGRAM_SIZE);  

      public void run() {
	 int length = 0;
	 while ( !isInterrupted() ) {
	    try { 
	       socket.receive(packet);  
	       //System.out.println("UDPT@" + port + ": Received packet from " + packet.getSocketAddress());
	       // Read length of incoming packet and create corresponding byte array.
	       length = buffer.getInt(0);
	       assert length <= MessageFragment.MAX_DATAGRAM_SIZE : "Received illegal packet from " + packet.getSocketAddress();
	       byte[] b = new byte[length];
	       buffer.position(0);
	       buffer.get(b);
	       inbox.put(new MessageFragment(b), packet.getSocketAddress());
	    }
	    catch(Throwable e) {
	       System.out.println("Error in ReceiverThread: " + e);
	       System.out.println("Length: " + length);
	    }
	 }
      }
   } // End inner class

   
   /** 
    *  Class representing an incoming request that is not yet finished,
    *  ie. one or more fragments has not yet been received.
    */
   private class PendingIncomingMessage {
      public IncomingUdpMessage request;
      public OutgoingUdpMessage reply;
      private byte status;
      // The address that receives the return value of the request.
      public SocketAddress receiver; 
      // State variables keeping track of transmission progress.
      // We need to keep track of when the last action was tried.
      private long progress;
      private int retries;
      
      // Specifies how long a complete incoming message should remain in the list of
      // pending incoming messages before it is removed. It cannot be removed when the reply
      // is sent, since the receiver will request a retransmission if it does receive the reply.
      private static final int TIME_COMPLETE_MESSAGE = 60000;

      // Set when the message is complete: when the reply has been sent to the receiver.
      private long timeCompleted;

      public PendingIncomingMessage(int id, SocketAddress receiver) {
	 request = new IncomingUdpMessage(id);
	 this.receiver = receiver;

	 // Reset error handling state.
	 this.progress = System.currentTimeMillis();
	 this.retries = 0;

	 // The request has not yet been executed.
	 status = MessageFragment.STATUS_RUNNING;
      }

	 
      public synchronized void addFragment(MessageFragment fragment) {
	 request.addFragment(fragment);
	 // We have received something, so note progress and reset retries.
	 progress();
	 retries = 0;

	 if (request.isComplete() ) {
	    // Use dispatcher to execute request on XmlStore.
	    reply = (OutgoingUdpMessage) dispatcher.receive(request);
	    status = MessageFragment.STATUS_COMPLETE;
	    timeCompleted = System.currentTimeMillis();	
           
	    // Send reply of request possibly consisting of several fragments.
	    sendFragments(reply, receiver);
	 }
      }   


      public byte getStatus() {
	 return status;
      }


      public synchronized void process() { 
	 // Check whether message is complete before doing anything.
	 if ( !request.isComplete() ) {
	    // Check if message has timed out
	    if ( isTimeForAction() )
	       nextAction();
	 }
	 else
	    // The request is complete and has been executed. Remove it, if it has 
	    // been in the list for too long. 
	    if ((System.currentTimeMillis() - timeCompleted) > TIME_COMPLETE_MESSAGE)
	       pendingIncomingMessages.remove(new IncomingUdpMessageId(request.getId(), 
								       receiver));
      }


      // Determines whether it has been too long since any progress was made,
      // and if it is time to take action, eg. request retransmission.
      private boolean isTimeForAction() {
	 long now = System.currentTimeMillis();
	 return (now - progress) > TIME_BETWEEN_ACTION;	 
      }


      // Notes the last time there was progress, eg. we either received 
      // something or did something.
      private void progress() {
	 progress = System.currentTimeMillis();
      }

      
      // Perform some action to continue incoming pending message.
      private void nextAction() {
	 progress();
	 
	 // Retry a given number of times or remove from the list.
	 if (retries < MAX_RETRY_ATTEMPTS)
	    retry();
	 else
	    // We have only received part of the request but the XmlStore that sent the
	    // request does not respond. We therefore remove the request from the list of
	    // pending incoming messages.
	    pendingIncomingMessages.remove(new IncomingUdpMessageId(request.getId(), 
								    receiver));
      }

      
      // Request retransmission of request fragments not yet received.
      private void retry() {   
	 retries++;

	 FragmentList.Iterator receivedFrags = request.iterator();
	 assert receivedFrags.hasNext() : "A request must contain fragments"; 
	 boolean[] received = null;
	 do {	       
	    MessageFragment f = receivedFrags.next();
	    // Initialize received if necessary
	    if (received == null)		  
	       received = new boolean[f.getTotal() + 1]; // Remember that total counts from [1..n]
	    received[f.getNumber()] = true;

	 } while (receivedFrags.hasNext());
	    
	 // Run through received and request retransmission of packets not received.
	 for (int i = 1; i < received.length; i++)
	    if ( !received[i] )
	       requestRetransmit(i, MessageFragment.TYPE_RETRANSMIT_REQUEST, 
				 request.getId(), receiver);
      }
   
   }  // End inner class.

   
   /** 
    * Class that handles retransmission in case that we have not received all
    * fragments of a request from another XmlStore.
    */
   private class PendingIncomingMessageManager extends Thread {
     
      // Checks all pending messages and responds accordingly
      private static final int WAITING_TIME = 20;


      public void run() {
	 while( !isInterrupted() ) {
	    // Run through pending messages, checking if they
	    // have timed out, need retransmission, etc.
	    PendingIncomingMessage[] current = 
	       (PendingIncomingMessage[]) pendingIncomingMessages.values().toArray(new PendingIncomingMessage[0]);
	    for (int i = 0; i < current.length; i++)
	       current[i].process();

	    // wait a bit before going again (to avoid busy waiting)	    
	    try {
	       Thread.sleep(WAITING_TIME);
	    }
	    catch(InterruptedException e) {
	       // OK, we have been interrupted
	    }
	 }
      }
   }    
}
