package edu.it.xmlstore.rpc;

import edu.it.xmlstore.directory.*;
import edu.it.xmlstore.*;
import edu.it.xmlstore.chord.ChordId;

import java.net.InetSocketAddress;
import java.net.InetAddress;


/**
 * RMI Proxy for the Directory class. Handles network communication with the
 * actual and remote directory. It uses sockets and blocks until the return
 * value is received.
 * Called by XmlStoreServerImpl.
 */
public class DirectoryProxy extends AbstractProxy implements Directory {


   private Transmitter transmitter;
   private static final int HEADER_LENGTH_NO_ARGUMENTS = 2;
   private static final int HEADER_LENGTH_ONE_ARGUMENT  = 6;
   private static final int HEADER_LENGTH_TWO_ARGUMENT  = 10;
   private static final int HEADER_LENGTH_THREE_ARGUMENT  = 14;

   public DirectoryProxy(InetAddress address, int port) {
      subjectAddress = new InetSocketAddress(address, port);
   }

   public synchronized void bind(String name, ValueReference ref)
                          throws NameAllreadyBoundException, RemoteException {
      OutgoingMessage message = createMessageWithTwoArguments(NetworkUtil.BIND,
							      name.getBytes(), ((ChordId) ref).toBytes());
      IncomingMessage reply = getTransmitter().send(message, subjectAddress);
      byte status = reply.getByte();
      checkNameAllreadyBoundException(status, name);
   }

   public synchronized ValueReference unbind(String name)
                              throws NoSuchElementException, RemoteException {

      OutgoingMessage message = createMessageWithOneArgument(NetworkUtil.UNBIND,
							     name.getBytes());
      IncomingMessage reply = getTransmitter().send(message, subjectAddress);
      byte status = reply.getByte();
      checkNoSuchElementException(status, name);

      return ValueUtil.decode(getReturnValue(reply));
   }


   public synchronized ValueReference lookup(String name)
                              throws NoSuchElementException, RemoteException {

      OutgoingMessage message = createMessageWithOneArgument(NetworkUtil.LOOKUP,
							     name.getBytes());
      IncomingMessage reply = getTransmitter().send(message, subjectAddress);
      byte status = reply.getByte();
      checkNoSuchElementException(status, name);

      return ValueUtil.decode(getReturnValue(reply));
   }


   public synchronized void update(String name, ValueReference newRef,
                                   ValueReference expectedRef)
                                                    throws ConcurrentAccessException, 
                                                           NoSuchElementException,
							   RemoteException {

      OutgoingMessage message = createMessageWithThreeArguments(NetworkUtil.UPDATE,
							        name.getBytes(), newRef.toBytes(), expectedRef.toBytes());

      IncomingMessage reply = getTransmitter().send(message, subjectAddress);
      byte status = reply.getByte();
      checkNoSuchElementException(status, name);
      checkConcurrentAccessException(status, name);
   }
}
