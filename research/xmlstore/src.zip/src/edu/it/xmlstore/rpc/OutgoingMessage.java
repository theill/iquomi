package edu.it.xmlstore.rpc;

public interface OutgoingMessage {
   public void putByte(byte b);
   public void putByteArray(byte[] b);
   public void putInt(int i);
}
