package edu.it.xmlstore.rpc;

import edu.it.xmlstore.*;
import edu.it.xmlstore.chord.*;
import edu.it.xmlstore.xml.*;

import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.util.StringTokenizer;
import java.util.LinkedList;


/**
 * RMI Proxy for the XmlStoreServerImpl class.
 * Called by XmlStoreServerImpl.
 */
public class XmlStoreServerProxy extends AbstractProxy implements XmlStoreServer {
   public ValueReference serverId;
   
   // Explicitly set transmitter -- useful for testing
   public XmlStoreServerProxy(ValueReference serverId,
                              InetSocketAddress subjectAddress,
			      Transmitter transmitter) {
      this.serverId = serverId;
      this.subjectAddress = subjectAddress; 
      this.transmitter = transmitter; 
   } 
 
 
   // Transmitter is initialized first time it is required (according to system settings) 
   public XmlStoreServerProxy(ValueReference serverId, 
                              InetSocketAddress subjectAddress) { 
      this.serverId = serverId; 
      this.subjectAddress = subjectAddress; 
      this.transmitter = null;  
   } 
 
 
   public ChordId serverId() { 
      return (ChordId)serverId; 
   } 
 
   // **** Remote method calls with two arguments **** 
 
   public void saveToDisk(byte[] value, ValueReference ref)  
      throws RemoteException { 
      OutgoingMessage message = createMessageWithTwoArguments(NetworkUtil.SAVE_TO_DISK, 
							      value, ((ChordId) ref).toBytes()); 
      IncomingMessage reply = getTransmitter().send(message, subjectAddress);
      checkRemoteException(reply); 
   } 
 
 
   public void saveValue(byte[] value, ValueReference key) 
      throws RemoteException { 
      OutgoingMessage message = createMessageWithTwoArguments(NetworkUtil.SAVE_VALUE, value, 
							      ((ChordId) key).toBytes()); 
      IncomingMessage reply = getTransmitter().send(message, subjectAddress);
      checkRemoteException(reply); 
   } 
 
 
   public void updateFingerTable(ChordNode n, int i) throws RemoteException { 
      // Convert i to a byte array. 
      ByteBuffer buf = ByteBuffer.allocate(NetworkUtil.INT_LENGTH); 
      byte[] arg2 = buf.putInt(i).array(); 
      OutgoingMessage message = createMessageWithTwoArguments(NetworkUtil.UPDATE_FINGER_TABLE, 
					 NetworkUtil.encodeXmlStoreServer((XmlStoreServer) n), 
							      arg2); 
      getTransmitter().sendAsynchronous(message, subjectAddress); 
   } 
 
 
   public void removeFromFingerTable(ChordNode n, int i) 
      throws RemoteException { 
      ByteBuffer buf = ByteBuffer.allocate(NetworkUtil.INT_LENGTH); 
      byte[] arg2 = buf.putInt(i).array(); 
      OutgoingMessage message = createMessageWithTwoArguments(NetworkUtil.REMOVE_FROM_FINGER_TABLE, 
					      NetworkUtil.encodeXmlStoreServer((XmlStoreServer) n), 
							      arg2); 
      getTransmitter().sendAsynchronous(message, subjectAddress); 
   } 
 
    
   // **** Remote method calls with one argument **** 
 
   public ChordNode closestPrecedingFinger(ChordId id) throws RemoteException { 
      OutgoingMessage message = createMessageWithOneArgument(NetworkUtil.CLOSEST_PRECEDING_FINGER, 
							     id.toBytes()); 
      IncomingMessage reply = getTransmitter().send(message, subjectAddress); 
      checkRemoteException(reply); 
      return NetworkUtil.decodeXmlStoreServer(getReturnValue(reply), getTransmitter()); 
   } 
 
 
   public ChordNode findPredecessor(ChordId id) throws RemoteException { 
      OutgoingMessage message = createMessageWithOneArgument(NetworkUtil.FIND_PREDECESSOR,  
							     id.toBytes()); 
      IncomingMessage reply = getTransmitter().send(message, subjectAddress); 
      checkRemoteException(reply); 
      return NetworkUtil.decodeXmlStoreServer(getReturnValue(reply), getTransmitter()); 
   } 
 
 
   public ChordNode findSuccessor(ChordId id) throws RemoteException { 
      OutgoingMessage message = createMessageWithOneArgument(NetworkUtil.FIND_SUCCESSOR,  
							     id.toBytes()); 
      IncomingMessage reply = getTransmitter().send(message, subjectAddress); 
      checkRemoteException(reply); 
      return NetworkUtil.decodeXmlStoreServer(getReturnValue(reply), getTransmitter()); 
   } 
 
    
   public void setPredecessor(ChordNode n) throws RemoteException { 
      OutgoingMessage message = createMessageWithOneArgument(NetworkUtil.SET_PREDECESSOR, 
				   NetworkUtil.encodeXmlStoreServer((XmlStoreServer) n)); 
      checkRemoteException(getTransmitter().send(message, subjectAddress)); 
   } 
 
 
   public void setSuccessor(ChordNode n) throws RemoteException { 
      OutgoingMessage message = createMessageWithOneArgument(NetworkUtil.SET_SUCCESSOR, 
				 NetworkUtil.encodeXmlStoreServer((XmlStoreServer) n)); 
      checkRemoteException(getTransmitter().send(message, subjectAddress)); 
   } 
 
 
   public void notify(ChordNode n) throws RemoteException { 
      OutgoingMessage message = createMessageWithOneArgument(NetworkUtil.NOTIFY, 
				NetworkUtil.encodeXmlStoreServer((XmlStoreServer) n)); 
      checkRemoteException(getTransmitter().send(message, subjectAddress)); 
   } 
 
 
   public byte[] loadValue(ValueReference key) throws RemoteException { 
      OutgoingMessage message = createMessageWithOneArgument(NetworkUtil.LOAD_VALUE,  
							     key.toBytes()); 
      IncomingMessage reply = getTransmitter().send(message, subjectAddress); 
      checkRemoteException(reply); 
      return getReturnValue(reply); 
   } 
 
 
   public void moveKeys(XmlStoreServer n) throws RemoteException { 
      OutgoingMessage message = createMessageWithOneArgument(NetworkUtil.MOVE_KEYS, 
					      NetworkUtil.encodeXmlStoreServer(n)); 
      checkRemoteException(getTransmitter().send(message, subjectAddress)); 
   } 
 
 
   public void moveAllKeys(XmlStoreServer n) throws RemoteException { 
      OutgoingMessage message = createMessageWithOneArgument(NetworkUtil.MOVE_ALL_KEYS, 
							     NetworkUtil.encodeXmlStoreServer(n)); 
      checkRemoteException(getTransmitter().send(message, subjectAddress)); 
   } 
 
 
   // **** Remote method calls with no arguments **** 
 
   public ChordNode successor() throws RemoteException { 
      OutgoingMessage message = createMessageWithNoArguments(NetworkUtil.SUCCESSOR);       
      IncomingMessage reply = getTransmitter().send(message, subjectAddress); 
      checkRemoteException(reply); 
      return NetworkUtil.decodeXmlStoreServer(getReturnValue(reply), getTransmitter()); 
   } 
 
 
   public ChordNode predecessor() throws RemoteException { 
      OutgoingMessage message = createMessageWithNoArguments(NetworkUtil.PREDECESSOR);       
      IncomingMessage reply = getTransmitter().send(message, subjectAddress); 
      checkRemoteException(reply); 
      return NetworkUtil.decodeXmlStoreServer(getReturnValue(reply), getTransmitter()); 
   } 
 
 
   //----------------------------------------------------------- 
   // Not remote methods... 
   public ValueReference save(Element element) {
      throw new RuntimeException("Save() should never be called on a proxy"); 
   } 

   public Node load(ValueReference ref) { 
      throw new RuntimeException("Load() should never be called on a proxy"); 
   }

   public ChordNode lookup(ChordId key) { 
      throw new RuntimeException("Lookup() should never be called on a proxy"); 
   } 
 
   public void removeFromOthers() { 
      throw new RuntimeException("RemoveFromOthers() should never be called" + 
                                 " on a proxy"); 
   } 
 
   public void stabilize() { 
      throw new RuntimeException("Stabilize() should never be called" + 
                                 " on a proxy"); 
   } 
 
   public void join(ChordNode n) { 
      throw new RuntimeException("Join() should never be called on a proxy"); 
   } 
 
   public void join(XmlStoreServer n) { 
      throw new RuntimeException("Join() should never be called on a proxy"); 
   } 
 
   public byte[] loadFromDisk(ValueReference key) { 
     throw new RuntimeException("LoadFromDisk() should never be called" + 
                                 " on a proxy"); 
   } 
 
   public void leave() { 
      throw new RuntimeException("Leave() should never be called on a proxy"); 
   } 
 
   public void updateOthers(ChordNode n) { 
     throw new RuntimeException("UpdateOthers() should never be called" + 
                                 " on a proxy"); 
   } 
} 
