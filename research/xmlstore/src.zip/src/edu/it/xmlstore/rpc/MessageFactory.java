package edu.it.xmlstore.rpc;

import edu.it.xmlstore.XmlStoreServer;

/**
 * Abstract factory -- implemented by UdpMessageFactory
 * and TcpMessageFactory
 */
public interface MessageFactory {
   public OutgoingMessage createOutgoingMessage(int length);
   public OutgoingMessage createOutgoingMessage(IncomingMessage message, 
						int length);
   
   public Transmitter getTransmitter();
   public void initializeTransmitter(int port, MessageDispatcher dispatcher) throws RemoteException;
}
