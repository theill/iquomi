package edu.it.xmlstore.rpc.udp;

import edu.it.xmlstore.rpc.MessageFactory;
import edu.it.xmlstore.rpc.IncomingMessage;
import edu.it.xmlstore.rpc.OutgoingMessage;
import edu.it.xmlstore.rpc.Transmitter;
import edu.it.xmlstore.rpc.RemoteException;
import edu.it.xmlstore.rpc.XmlStoreMessageDispatcher;
import edu.it.xmlstore.rpc.MessageDispatcher;
import edu.it.xmlstore.XmlStoreServer;


public class UdpMessageFactory implements MessageFactory {   

   // "Unique" id of messages
   private static int nextId = 0;

   private static synchronized int nextId() {
      return nextId++;
   }


   // Make singleton UdpTransmitter available
   private static UdpTransmitter udptransmitter = null;

   public synchronized void initializeTransmitter(int port, MessageDispatcher dispatcher) throws RemoteException {
      if (udptransmitter == null)
	 udptransmitter = new UdpTransmitter(port, dispatcher);
      else 
	 throw new RuntimeException("UdpTransmitter initialized twice.");
   }

   public synchronized Transmitter getTransmitter() {
      if (udptransmitter != null)
	 return udptransmitter;
      else
	 throw new RuntimeException("UdpTransmitter not initialized."); 
   }
      
   
   // Creation of messages
   public OutgoingMessage createOutgoingMessage(int length) {
      return new OutgoingUdpMessage(nextId(), length, MessageFragment.TYPE_REQUEST);
   }

   public OutgoingMessage createOutgoingMessage(int id, int length) {
      return new OutgoingUdpMessage(id, length, MessageFragment.TYPE_REPLY);
   }

   public OutgoingMessage createOutgoingMessage(IncomingMessage message, int length) {
      if (message instanceof IncomingUdpMessage)
	 return new OutgoingUdpMessage(((IncomingUdpMessage)message).getId(), length, MessageFragment.TYPE_REPLY);
      else
	 throw new RuntimeException("Incompatible message, expected IncomingUdpMessage");
   }

   public IncomingMessage createIncomingMessage(int id) {
      return new IncomingUdpMessage(id);
   }
  

   // Make factory available as singleton pattern
   private UdpMessageFactory() {}

   private static UdpMessageFactory instance = null;
   
   public static synchronized UdpMessageFactory instance() {
      if (instance == null)
	 instance = new UdpMessageFactory();
      return instance;
   }
}
