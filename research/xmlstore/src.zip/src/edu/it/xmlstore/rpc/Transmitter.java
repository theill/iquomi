package edu.it.xmlstore.rpc;

import java.net.SocketAddress;

public interface Transmitter {
   public IncomingMessage send(OutgoingMessage message, SocketAddress receiver) throws RemoteException; 
   public void sendAsynchronous(OutgoingMessage message, SocketAddress receiver);
   public void close();
}
