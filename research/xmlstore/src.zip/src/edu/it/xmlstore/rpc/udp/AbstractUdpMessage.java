package edu.it.xmlstore.rpc.udp;

/**
 * Provides a skeletal implementation of an UDP message.
 * Implemented by OutgoingUdpMessage and IncomingUdpMessage.
 *
 */
public abstract class AbstractUdpMessage {

   protected FragmentList fragments;
   
   public int getId() {
      assert fragments != null : "Error in AbstractUdpMessage, fragments is null";
      return fragments.getId();
   }

   public FragmentList.Iterator iterator() {
      return fragments.iterator();
   }
   
   public String toString() {
      FragmentList.Iterator it = iterator();
      StringBuffer result = new StringBuffer("Message:\n");
      while (it.hasNext())
	 result.append(it.next()).append("\n");
      return result.toString();
   }
}

