package edu.it.xmlstore.rpc.udp;

import java.nio.ByteBuffer;

public class MessageFragment {      
   // Header:
   public static final short HEADER_SIZE = 13; // in bytes
   private static final short LENGTH_POSITION = 0;
   private static final short ID_POSITION = 4;
   private static final short TYPE_POSITION = 8;
   private static final short NUMBER_POSITION = 9;
   private static final short TOTAL_POSITION = 11;

   // Size
   public static final int MAX_DATAGRAM_SIZE = 65535 - 20 - 8; // 20 = IP header, 8 = UDP header
   public static final int MAX_MESSAGE_SIZE = MAX_DATAGRAM_SIZE - HEADER_SIZE;

   // Fragment types.
   public static final byte TYPE_REQUEST = 1;
   public static final byte TYPE_RETRANSMIT_REQUEST = 2;

   public static final byte TYPE_REPLY = 3;
   public static final byte TYPE_RETRANSMIT_REPLY = 4;

   public static final byte TYPE_STATUS_REQUEST = 5;
   public static final byte TYPE_STATUS = 6;

   // Status types.
   public static final byte STATUS_RUNNING = 1;
   public static final byte STATUS_COMPLETE = 2;
   public static final byte STATUS_UNKNOWN = 3;
   
  
   // The actual content of the fragment.
   ByteBuffer content;

   public MessageFragment(int id, int length, byte type, short number, short total) {
      // Allocate buffer
      assert length <= MAX_MESSAGE_SIZE : "Size of fragment too large";
      content = ByteBuffer.allocate(HEADER_SIZE + length);

      
      // Make sure type is set correctly
      assert type != 0 : "Type not correct";

      // Store data in buffer
      content.putInt(  LENGTH_POSITION, HEADER_SIZE + length);
      content.putInt(  ID_POSITION,     id);
      content.put(     TYPE_POSITION,   type);
      content.putShort(NUMBER_POSITION, number);
      content.putShort(TOTAL_POSITION,  total);
   }

   public MessageFragment(byte[] buffer) {
      content = ByteBuffer.wrap(buffer);

      // Make sure message has correct size
      assert length() <= MAX_DATAGRAM_SIZE : "Size of fragment too large";
      // Make sure type is set correctly
      assert getType() != 0 : "Type not correct";
   }

   /**
    * Accessor methods for header information
    */ 
   public int length() {
      return content.getInt(LENGTH_POSITION);
   }

   public int getId() {
      return content.getInt(ID_POSITION);
   }

   public byte getType() {
      return content.get(TYPE_POSITION);
   }
   
   public short getNumber() {
      return content.getShort(NUMBER_POSITION);
   }

   public short getTotal() {
      return content.getShort(TOTAL_POSITION);
   }

   /**
    * Accessor and mutator methods for content of fragment
    */ 
   public byte[] asArray() {
      return content.array();      
   }

   private void position(int index) {
      content.position(HEADER_SIZE + index);
   }
 
   public int remaining(int index) {
      return ((length() - HEADER_SIZE) - index);
   }

   public void putInt(int index, int i) {
      position(index);
      content.putInt(i);    
   }

   public void putByte(int index, byte b) {
      position(index);
      content.put(b);
   }
   
   public void putByteArray(int index, byte[] b) {
      position(index);
      content.put(b);
   }

   public int getInt(int index) {
      position(index);
      return content.getInt();
   }

   public byte getByte(int index) {
      position(index);
      return content.get();
   }
   
   public byte[] getByteArray(int index, int length) {
      position(index);
      byte[] result = new byte[length];
      content.get(result);
      return result;
   }
   

   /**
    * Standard object methods
    */
   public boolean equals(Object other) {
      if (other instanceof MessageFragment) {
	 MessageFragment that = (MessageFragment) other;
	 return content.equals(that.content);
      } 
      else
	 return false;
   }


   public String toString() {
      return "[length:" + length() + 
	 ", id:"    + getId() + 
	 ", type:"  +  getType() + 
	 ", Number/Total:" + getNumber()+ "/" + getTotal() + "]"
	 + content;
   }
}
