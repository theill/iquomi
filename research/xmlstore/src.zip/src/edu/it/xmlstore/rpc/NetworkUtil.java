package edu.it.xmlstore.rpc;
 
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.ByteBuffer;
import java.net.InetSocketAddress;
import java.net.InetAddress;
import java.math.BigInteger;
import java.net.UnknownHostException;
import edu.it.xmlstore.chord.*;
import edu.it.xmlstore.*;

/**
 * Utility class for network communication. */

public class NetworkUtil {
   // Methods with one argument -> XmlStoreServer.
   // These methods needs to have the IP-address of the proxy-argument
   // send with them.
   public static final byte SET_SUCCESSOR = 1;
   public static final byte SET_PREDECESSOR = 2;
   public static final byte JOIN = 3;
   public static final byte UPDATE_OTHERS = 4;
   public static final byte NOTIFY = 5;
   public static final byte MOVE_KEYS = 6;
   public static final byte MOVE_ALL_KEYS = 7;

   // Methods with two arguments -> XmlStoreServer, int.
   // These methods needs to have the IP-address of the proxy-argument
   // send with them.
   public static final byte UPDATE_FINGER_TABLE = 8;
   public static final byte REMOVE_FROM_FINGER_TABLE = 9;

   // Methods with zero arguments.
   public static final byte SUCCESSOR = 10;
   public static final byte PREDECESSOR = 11;
   public static final byte REMOVE_FROM_OTHERS = 12;
   public static final byte STABILIZE = 13;
   public static final byte LEAVE = 14;

   // Methods with one argument -> ChordId/ValueReference/Element.
   public static final byte FIND_SUCCESSOR = 15;
   public static final byte FIND_PREDECESSOR = 16;
   public static final byte CLOSEST_PRECEDING_FINGER = 17;
   public static final byte SAVE = 18;
   public static final byte LOAD_FROM_DISK = 19;
   public static final byte LOAD = 20;
   public static final byte LOAD_VALUE = 21;

   // Methods with two arguments -> byte[], ValueReference.
   public static final byte SAVE_TO_DISK = 22;
   public static final byte SAVE_VALUE = 23;

   public static final byte LAST_NODE_METHOD = 9;

   // Directory related methods
   public static final byte BIND = 24;
   public static final byte UNBIND = 25;
   public static final byte LOOKUP = 26;
   public static final byte UPDATE = 27;

   // Exceptions in Directory and XmlStoreServer
   public static final byte ALL_OK = -2;
   public static final byte NAME_ALLREADY_BOUND_EXN = -3;
   public static final byte NO_SUCH_ELEMENT_EXN = -4;
   public static final byte CONCURRENT_ACCESS_EXN = -5;

   public static final byte REMOTE_EXN_UNKNOWN_METHOD = -6;
   public static final byte REMOTE_EXN_SAVE_TO_DISK = -7;
   public static final byte REMOTE_EXN_SAVE_VALUE = -8;
   public static final byte REMOTE_EXN_SET_SUCESSOR = -9;
   public static final byte REMOTE_EXN_SET_PREDECESSOR = -10;
   public static final byte REMOTE_EXN_NOTIFY = -11;
   public static final byte REMOTE_EXN_UPDATE_FINGER_TABLE = -12;
   public static final byte REMOTE_EXN_REMOVE_FROM_FINGER_TABLE = -13;
   public static final byte REMOTE_EXN_MOVE_KEYS = -14;
   public static final byte REMOTE_EXN_MOVE_ALL_KEYS = -15;
   public static final byte REMOTE_EXN_SUCCESOR = -16;
   public static final byte REMOTE_EXN_PREDECESSOR = -17;
   public static final byte REMOTE_EXN_CLOSEST_PRECEDING_FINGER = -18;
   public static final byte REMOTE_EXN_FIND_PREDECESSOR = -19;
   public static final byte REMOTE_EXN_FIND_SUCCESSOR = -20;
   public static final byte REMOTE_EXN_LOAD_VALUE = -21;
   

   // Length of an integer in bytes.
   public static final byte INT_LENGTH = 4;

   // Length for header of return value.
   public static final byte HEADER_LENGTH = 5;

   // Length for status of return value.
   public static final byte STATUS_LENGTH = 1;

   // Type of message:
   public static final byte INCOMING = 1;
   public static final byte RETURN_VALUE = 2;
   
   // Length of method type:
   public static final byte METHOD_LENGTH = 1;

   // Used for test in decodeXmlStoreServer.
   // The transmitter can be null, if we do not use the proxy afterwards
   private static Transmitter testTransmitter = null;
   private static boolean testFlag = false;
   public static void testing(Transmitter t) {
      testFlag = true;
      testTransmitter = t;
   }


   // Returns a byte array representation of a string encoded in ascii.
   private static byte[] encode(String host) {
      Charset charset = Charset.forName( "us-ascii" );
      ByteBuffer byteBuffer = charset.encode(host);
      return byteBuffer.array();
   }


    // Returns a string representation of a byte array encoded in ascii.
   private static String decode(byte[] host) {
      Charset charset = Charset.forName( "us-ascii" );
      ByteBuffer byteBuffer = ByteBuffer.wrap(host);
      return charset.decode(byteBuffer).toString();
   }


   /**
    * Returns an XmlStoreServer as an array of bytes. This is the protocol:
    * 1) Length of serverId (int)
    * 2) ServerId
    * 3) Length of address (int)
    * 4) Address
    * 5) Port (int)
    */
   public static byte[] encodeXmlStoreServer(XmlStoreServer n) {
      InetSocketAddress proxyAddress = n.getAddress();
      String stringAddress = proxyAddress.getAddress().getHostAddress();
      byte[] id = n.serverId().toBytes();
      int messageLength = id.length + stringAddress.length() +
                          (3 * INT_LENGTH);
      ByteBuffer result = ByteBuffer.allocate(messageLength);
      result.putInt(id.length);
      result.put(id);
      result.putInt(stringAddress.length());
      result.put(encode(stringAddress));
      result.putInt(proxyAddress.getPort());
      return result.array();
   }


   /**
    * Returns an XmlStoreServer from an array of bytes. This is the protocol:
    * 1) Length of serverId (int)
    * 2) ServerId
    * 3) Length of address (int)
    * 4) Address
    * 5) Port (int)
    */
   public static XmlStoreServer decodeXmlStoreServer(byte[] b, Transmitter transmitter)
      throws RemoteException {
      InetAddress proxyAddress = null;
      ByteBuffer readBuffer = ByteBuffer.wrap(b);
      int idLength = readBuffer.getInt();
      byte[] idArray = new byte[idLength];
      readBuffer.get(idArray, 0, idLength);
      ValueReference id = new ChordIdImpl(new BigInteger(idArray));
      int ipAddressLength = readBuffer.getInt();
      byte[] ipAd = new byte[ipAddressLength];
      readBuffer.get(ipAd, 0, ipAddressLength);
      try {
          proxyAddress = InetAddress.getByName(decode(ipAd));
      }
      catch (UnknownHostException e) {
         throw new RemoteException(e.toString());
      }
      int port = readBuffer.getInt();
      InetSocketAddress address = new InetSocketAddress(proxyAddress, port);

      if (testFlag)
	 return new XmlStoreServerProxy(id, address, testTransmitter);
      else {
	 // If we have received "ourselves" (the server on this virtual machine)
	 // then return "ourselves" instead of a proxy      
	 XmlStoreServer localServer = XmlStoreHome.getConnectedServer();
	 if (localServer.serverId().equals(id))
	    return localServer;
	 else
	    return new XmlStoreServerProxy(id, address);
      }
   }
}
