package edu.it.xmlstore.rpc.udp;

import edu.it.xmlstore.rpc.OutgoingMessage;

public class OutgoingUdpMessage extends AbstractUdpMessage implements OutgoingMessage {

   public OutgoingUdpMessage(int id, int length, byte type) {
      // Initialize list of fragments
      fragments = new FragmentList(id);

      // Create the necessary fragments for a message
      // of length
      short fragmentsNeeded = (short) (length / MessageFragment.MAX_MESSAGE_SIZE);
      if ( ((length % MessageFragment.MAX_MESSAGE_SIZE) != 0) || (length == 0) )
	 fragmentsNeeded += 1;


      int remainingLength = length;
      for (short i = 1; i <= fragmentsNeeded; i++) {
	 int fragmentLength = remainingLength >= MessageFragment.MAX_MESSAGE_SIZE 
	                                      ?  MessageFragment.MAX_MESSAGE_SIZE : remainingLength;
	 remainingLength -= fragmentLength;
	 fragments.add(new MessageFragment(id, fragmentLength, type, i, fragmentsNeeded));
      }
      
      assert remainingLength == 0 : "Fragments incorrectly calculated";
   }      

   public void putByte(byte b) {
      fragments.putByte(b);
   }

   public void putByteArray(byte[] b) {
      fragments.putByteArray(b);
   }

   public void putInt(int i) {
      fragments.putInt(i);
   }
}
