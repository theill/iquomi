package edu.it.xmlstore.rpc;

public interface IncomingMessage {  
   public byte   getByte();  
   public byte[] getByteArray(int length);
   public int    getInt();
}
