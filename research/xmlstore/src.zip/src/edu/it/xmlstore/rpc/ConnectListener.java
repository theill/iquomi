package edu.it.xmlstore.rpc;

import java.net.MulticastSocket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.DatagramPacket;
import java.net.UnknownHostException;
import java.io.IOException;
import java.util.StringTokenizer;
import edu.it.xmlstore.ValueReference;

/**
 * Listener thread that replies XML Stores that want to join the system.
 * When an XML Store wants to join the network it sends out a multicast. This
 * multicast is received by a ConnectListener thread of another XML Store,
 * which sends back its address and node id to the requesting XML Store.
 */
public class ConnectListener implements Runnable {

   // socket for listening for and replying to incoming requests
   MulticastSocket receivingSocket;
   DatagramSocket transmittingSocket;

   public final String response;
   private boolean hasNameService = false;
   private boolean hasXmlStoreServer = false;

   public static final int LISTENING_PORT = 7777;
   public static final String GROUP_ADDRESS = "230.0.0.1";

   public static final String XMLSTORE_LOOKUP_PREFIX =
                                            "[XMLStoreServer]Lookup XmlStore";
   public static final String NAMESERVICE_LOOKUP_PREFIX =
                                          "[XMLStoreServer]Lookup Nameservice";

   public static final String XMLSTORE_RESPONSE_PREFIX =
                                          "[XMLStoreServer]XmlStore Location";
   public static final String NAMESERVICE_RESPONSE_PREFIX =
                                       "[XMLStoreServer]Nameservice Location";

   // constructor for making a listener for XmlStoreServer requests
   public ConnectListener(ValueReference serverId, int messageListenerPort)
                                                       throws IOException {
      initialize();
      String temp = new String(XMLSTORE_RESPONSE_PREFIX + ":" +
                               InetAddress.getLocalHost().getHostAddress() +
                               ":" + messageListenerPort + "," + serverId);
      response = temp;
      hasXmlStoreServer = true;
   }


   // constructor for making a listener for Name Service requests
   public ConnectListener(int nameServicePort) throws IOException {
      initialize();
      String temp = new String(NAMESERVICE_RESPONSE_PREFIX + ":" +
                        InetAddress.getLocalHost().getHostAddress() +
                        ":" + nameServicePort);
      response = temp;
      hasNameService = true;
   }


   private void initialize() throws IOException {
      receivingSocket = new MulticastSocket(LISTENING_PORT);
      transmittingSocket = new DatagramSocket();
   }


   public void run() {
      try {
         setup();
         while (true) {
            receiveIncomingRequests();
         }
      }
      catch (Exception e) {
         // give up...
         System.err.println("Error: " + e);
      }
   }


   public void setup() throws UnknownHostException, IOException {
      InetAddress group = InetAddress.getByName(GROUP_ADDRESS);
      receivingSocket.joinGroup(group);
   }


   public void receiveIncomingRequests() throws IOException {
      byte[] buf = new byte[1000];
      DatagramPacket recv = new DatagramPacket(buf, buf.length);

      // blocking receive
      receivingSocket.receive(recv);

      // use a tokenizer to parse the address & port out of incoming request
      StringTokenizer message = new StringTokenizer(new String(buf).trim(), ":,");
      String prefix = message.nextToken();
      if (   (prefix.equals(XMLSTORE_LOOKUP_PREFIX) && hasXmlStoreServer)
          || (prefix.equals(NAMESERVICE_LOOKUP_PREFIX) && hasNameService)) {
         // parse ip and port
         InetAddress address = InetAddress.getByName(message.nextToken());
         int port = Integer.parseInt(message.nextToken());
         transmittingSocket.send(new DatagramPacket(response.getBytes(), response.length(), recv.getSocketAddress()));
      }
   }
}
