package edu.it.xmlstore.rpc;

/**
 * Exception thrown when a error occurs during network communication.
 */
public class RemoteException extends java.io.IOException {
   public RemoteException(String message) {
         super(message);
   }
}