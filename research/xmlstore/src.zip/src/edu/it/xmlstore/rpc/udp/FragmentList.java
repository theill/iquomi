package edu.it.xmlstore.rpc.udp;

import java.util.LinkedList;
import java.nio.ByteBuffer;

// Contains the fragments associated with a single message
public class FragmentList {   

   // The fragments 
   LinkedList fragments;

   // Id of message
   private int id;

   // Index into buffers
   private int index;
   private int currentFragment;

   // Constants
   private static final int BYTE_SIZE = 1;
   private static final int INT_SIZE = 4; 
   
   // Constructor
   public FragmentList(int id) {
      this.id = id;
      fragments = new LinkedList();
      reset();      
   }
   

   public int getId() {
      return id;
   }


   public int size() {
      return fragments.size();
   } 


   public void add(MessageFragment added) {
      // Check fragment is consistent with this list
      if (! checkConsistency(added))
	 throw new RuntimeException("Inconsistent fragments in incoming message id: " + id);

      // Insert fragments sorted 
      else {
	 int i = 0;
	 for ( ; i < fragments.size(); i++) {
	    MessageFragment current = (MessageFragment)fragments.get(i);

	    if (added.getNumber() <= current.getNumber()) {
	       // Only insert fragment once (not if its equal)	    
	       if (added.getNumber() < current.getNumber())
		  fragments.add(i, added);
	       break;
	    }
	 }

	 // We could be the last element in the list
	 if (i == fragments.size())
	    fragments.addLast(added);
      }
   }


   // Checks that the added fragment has the right id and total.
   private boolean checkConsistency(MessageFragment f) {
      boolean result = false;
      if (id == f.getId()) {     
	 result = true;
	 // Make sure total is consistent across all fragments.
	 if (fragments.size() > 0) {
	    MessageFragment first = iterator().next();
	    result = (first.getTotal() == f.getTotal());
	 }
      }
      return result;
   }

   // Resets the relative index into buffers
   public void reset() {
      index = 0;
      currentFragment = 0;
   }

   // get and put a byte
   public void putByte(byte b) {
      if (getCurrentFragment().remaining(index) < BYTE_SIZE) 
	 nextFragment();

      getCurrentFragment().putByte(index, b);
      index += BYTE_SIZE;
   }

   public byte getByte() {
      if (getCurrentFragment().remaining(index) < BYTE_SIZE) 
	 nextFragment();

      byte result = getCurrentFragment().getByte(index);
      index += BYTE_SIZE;
      return result;
   }

   // get and put an int
   public void putInt(int i) {         
      // handle fragmentation if necessary    
      if (getCurrentFragment().remaining(index) < INT_SIZE) {
	 byte[] intAsBytes = intToByteArray(i);
	 for (int idx = 0; idx < INT_SIZE; idx++)	    
	    putByte(intAsBytes[idx]);	    
      }
      else {
	 getCurrentFragment().putInt(index, i);
	 index += INT_SIZE;    
      }
   }

   public int getInt() {
      // handle fragmentation if necessary
      if (getCurrentFragment().remaining(index) < INT_SIZE) {	 
	 byte[] result = new byte[INT_SIZE];
	 for (int idx = 0; idx < INT_SIZE; idx++)	    
	    result[idx] = getByte();
	 return byteArrayToInt(result);
      }
      else {
	 int result = getCurrentFragment().getInt(index);
	 index += INT_SIZE;
	 return result;
      }
   }

   // get and put a byte array
   public void putByteArray(byte[] b) {
      if (getCurrentFragment().remaining(index) < b.length) {	 
	 for (int idx = 0; idx < b.length; idx++)	    
	    putByte(b[idx]);	    
      }
      else {
	 getCurrentFragment().putByteArray(index, b);
	 index += b.length;
      }
   }

   public byte[] getByteArray(int length) {
      if (getCurrentFragment().remaining(index) < length) {	 
	 byte[] result = new byte[length];
	 for (int idx = 0; idx < length; idx++)	    
	    result[idx] = getByte();
	 return result;
      }
      else {
	 byte[] result = getCurrentFragment().getByteArray(index, length);
	 index += length;
	 return result;
      }
   }

   // Returns current fragment by looking at index
   private MessageFragment getCurrentFragment() {
      return (MessageFragment)fragments.get(currentFragment);      
   }

   private void nextFragment() {
      currentFragment++;
      index = 0;      
      assert currentFragment <= fragments.size() : "No more fragments!";
   }

   public FragmentList.Iterator iterator() {
      return new FragmentList.Iterator(fragments.iterator());
   }

   private static byte[] intToByteArray(int i) {
      ByteBuffer bb = ByteBuffer.allocate(INT_SIZE);
      bb.putInt(i);
      return bb.array();
   }

   private static int byteArrayToInt(byte[] b) {
      ByteBuffer bb = ByteBuffer.wrap(b);
      return bb.getInt();
   }

   public static class Iterator {
      private java.util.Iterator iterator;
      
      private Iterator(java.util.Iterator iterator) {
	 this.iterator = iterator;
      }

      public boolean hasNext() {
	 return iterator.hasNext();
      }
      
      public MessageFragment next() {
	 return (MessageFragment)iterator.next();
      }      
   }
}

