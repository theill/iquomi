package edu.it.xmlstore.rpc;

import edu.it.xmlstore.directory.*;
import edu.it.xmlstore.directory.DirectoryImpl;
import edu.it.xmlstore.XmlStoreHome;
import edu.it.xmlstore.ValueReference;
import edu.it.xmlstore.ValueUtil;

import java.nio.ByteBuffer;

/**
 * Determines the type of method and invokes the corresponding method on the
 * actual XmlStoreServerImpl. 
 * Returns an outgoing message.
 * Called by MessageTransmitter.
 */
public class DirectoryMessageDispatcher implements MessageDispatcher {
   private DirectoryImpl directory;
   private Transmitter transmitter;
   

   public DirectoryMessageDispatcher(Directory directory) {
      if (directory instanceof DirectoryImpl)
	 this.directory = (DirectoryImpl)directory;
      else
	 throw new RuntimeException("Incompatible Directory, expected DirectoryImpl.");
   }
   
   // Useful for testing
   public void setTransmitter(Transmitter t) {
      transmitter = t;
   }


   public OutgoingMessage receive(IncomingMessage inMessage) {
      // make sure transmitter is initialized
      if (transmitter == null)
	 transmitter = XmlStoreHome.getMessageFactory().getTransmitter();

      // Wrap message in protocol
      DirectoryMessageProtocol message = new DirectoryMessageProtocol(inMessage);
      switch(message.getMethod())  {
      case NetworkUtil.BIND:
	 return handleBind(message);
      case NetworkUtil.UNBIND:
	 return handleUnbind(message);
      case NetworkUtil.LOOKUP:
	 return handleLookup(message);
      case NetworkUtil.UPDATE:
	 return handleUpdate(message);
      default:
	 return createOutgoingMessageStatus(NetworkUtil.REMOTE_EXN_UNKNOWN_METHOD, inMessage);
      }
   }  

   // ----------------- Method handlers --------------------

   // Methods handlers for methods that only return a status.
   private OutgoingMessage handleBind(DirectoryMessageProtocol message) {
      byte status = NetworkUtil.ALL_OK;
      String name = message.nextArgString();
      ValueReference ref = message.nextArgValueReference();
      try {
         directory.bind(name, ref);
      }
      catch (NameAllreadyBoundException e) {
         status = NetworkUtil.NAME_ALLREADY_BOUND_EXN;
      }
      return createOutgoingMessageStatus(status, message.getIncomingMessage());
   }


   private OutgoingMessage handleLookup(DirectoryMessageProtocol message) {
      byte status = NetworkUtil.ALL_OK;
      String name = message.nextArgString();      
      try {
         ValueReference ref = directory.lookup(name);
	 return createOutgoingMessageValue(ref, message.getIncomingMessage());
      }
      catch (NoSuchElementException e) {
	 return createOutgoingMessageStatus(NetworkUtil.NO_SUCH_ELEMENT_EXN, message.getIncomingMessage());
      }
   }

   private OutgoingMessage handleUnbind(DirectoryMessageProtocol message) {
      byte status = NetworkUtil.ALL_OK;
      String name = message.nextArgString();      
      try {
         ValueReference ref = directory.unbind(name);
	 return createOutgoingMessageValue(ref, message.getIncomingMessage());
      }
      catch (NoSuchElementException e) {
	 return createOutgoingMessageStatus(NetworkUtil.NO_SUCH_ELEMENT_EXN, message.getIncomingMessage());
      }
   }


   private OutgoingMessage handleUpdate(DirectoryMessageProtocol message) {     
      byte status = NetworkUtil.ALL_OK;
      String name                = message.nextArgString();      
      ValueReference newRef      = message.nextArgValueReference();
      ValueReference expectedRef = message.nextArgValueReference();
      try {
         directory.update(name, newRef, expectedRef);
      }
      catch (NoSuchElementException e) {
         status = NetworkUtil.NO_SUCH_ELEMENT_EXN;
      }
      catch (ConcurrentAccessException e) {
	 status = NetworkUtil.CONCURRENT_ACCESS_EXN;
      }
      return createOutgoingMessageStatus(status, message.getIncomingMessage());
   }


   // ********** Helper methods **********

   // Returns an outgoing message that only contains status.
   private OutgoingMessage createOutgoingMessageStatus(byte status, IncomingMessage message) {
      OutgoingMessage reply =
	 XmlStoreHome.getMessageFactory().createOutgoingMessage(message,
								NetworkUtil.STATUS_LENGTH);
      reply.putByte(status);
      return reply;
   }


   /**
    * Returns an outgoing message that contains status = ALL_OK and an 
    * XmlstoreServer as return value. This is the protocol:
    * 1) Status   (byte)
    * 2) Length of return value (int)
    * 3) Return value (byte[])
    */
   private OutgoingMessage createOutgoingMessageValue(ValueReference ref, IncomingMessage message) {
      byte[] refAsBytes = ref.toBytes();
      OutgoingMessage reply = XmlStoreHome.getMessageFactory().createOutgoingMessage(message,
										     NetworkUtil.STATUS_LENGTH +
										     NetworkUtil.INT_LENGTH +
										     refAsBytes.length);
      reply.putByte(NetworkUtil.ALL_OK);
      reply.putInt(refAsBytes.length);
      reply.putByteArray(refAsBytes);
      return reply;
   }



   // *************************************************'
   
   /**
    * Inner class that represents a RMI-call from a proxy to an XmlStoreServer. 
    * It extracts the arguments from an incoming message.
    * This is the protocol:
    * 1) Method   (byte)
    * 2) Number of arguments (byte) (0, 1 or 2)
    * 3) Length of argument1 (int)  (only for methods with one and two arguments)
    * 4) Length of argument2 (int)  (only for methods with two arguments)
    * 5) Argument1 (byte[])         (only for methods with one and two arguments)
    * 6) Argument2 (byte[])         (only for methods with two arguments)
    *
    */
   private static class DirectoryMessageProtocol {
      private IncomingMessage message;
      private byte method;
      private byte numberOfArguments;
      public int[] argLengths;
      private int argsRead = 0;
      private byte[] byteArray;
      
      public DirectoryMessageProtocol(IncomingMessage m) {
	 message = m;
	 // Extract protocol information from incoming message.
	 method = message.getByte();
	 numberOfArguments = message.getByte();
	 argLengths = new int[numberOfArguments];
	 for (int i = 0; i < numberOfArguments; i++)
	    argLengths[i] = message.getInt();
      }

      public byte getMethod() {
	 return method;
      }
      
      public IncomingMessage getIncomingMessage() {
	 return message;
      }

      public ValueReference nextArgValueReference() {
	 return ValueUtil.decode(nextArg());
      }

      public String nextArgString() {
	 return new String(nextArg());
      }      
     
      public byte[] nextArg() { 
	 assert argsRead < numberOfArguments : "Error in Message. No more arguments!";
	 return message.getByteArray(argLengths[argsRead++]);
      }
   }
}
