package edu.it.xmlstore;

import edu.it.xmlstore.chord.ChordNode;
import java.io.IOException;
import edu.it.xmlstore.xml.Element;
import edu.it.xmlstore.rpc.RemoteException;
import edu.it.xmlstore.xml.Node;
import java.net.InetSocketAddress;

/**
 * Interface representing XmlStoreServer.
 * XmlStoreServer is a node in a peer-to-peer network, based on the
 * Chord-protocol.
 */
public interface XmlStoreServer extends ChordNode {
   public ValueReference save(Element element) throws RemoteException;
   public void saveToDisk(byte[] value, ValueReference ref)
                                             throws RemoteException;
   public void saveValue(byte[] value, ValueReference key)
                                             throws RemoteException;
   public void moveKeys(XmlStoreServer p) throws RemoteException;
   public void moveAllKeys(XmlStoreServer p) throws RemoteException;
   public void join(XmlStoreServer n) throws RemoteException;
   public Node load(ValueReference ref) throws RemoteException,
                                               ValueNotFoundException;
   public byte[] loadFromDisk(ValueReference key) throws IOException;
   public byte[] loadValue(ValueReference key) throws ValueNotFoundException,
                                                      RemoteException;
   public InetSocketAddress getAddress();
}