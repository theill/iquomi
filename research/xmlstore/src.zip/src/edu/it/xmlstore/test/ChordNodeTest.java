package edu.it.xmlstore.test;

import junit.framework.*;
import java.io.*;
import edu.it.xmlstore.chord.*;
import edu.it.xmlstore.storage.*;

public class ChordNodeTest extends TestCase {

   public ChordNodeTest(String name) {
      super(name);
   }

   public static Test suite() {
      TestSuite suite = new TestSuite(ChordNodeTest.class);
      return suite;
   }

   public static void main(String[] args) {
      junit.textui.TestRunner.run(ChordNodeTest.class);
   }

   // Test ids used in most tests
   ChordId id0 = new ChordIdImpl(0);
   ChordId id1 = new ChordIdImpl(1);
   ChordId id2 = new ChordIdImpl(2);
   ChordId id3 = new ChordIdImpl(3);
   ChordId id4 = new ChordIdImpl(4);
   ChordId id5 = new ChordIdImpl(5);
   ChordId id6 = new ChordIdImpl(6);
   ChordId id7 = new ChordIdImpl(7);
   ChordId id70 = new ChordIdImpl(70);
   ChordId id80 = new ChordIdImpl(80);
   ChordId id90 = new ChordIdImpl(90);

   public void testFindSuccessor() {
      try {
         // Create test servers
         ChordNode s0 = new ChordNodeImpl(id0);
         ChordNode s1 = new ChordNodeImpl(id1);
         ChordNode s3 = new ChordNodeImpl(id3);

         // Set up CHORD ring
         s1.join(null);
         s0.join(s1);
         s3.join(s0);

         // Testing...
         assertTrue( s0.findSuccessor(id0).serverId().equals(id0) );
         assertTrue( s1.findSuccessor(id0).serverId().equals(id0) );
         assertTrue( s3.findSuccessor(id0).serverId().equals(id0) );

         assertTrue( s0.findSuccessor(id1).serverId().equals(id1) );
         assertTrue( s1.findSuccessor(id1).serverId().equals(id1) );
         assertTrue( s3.findSuccessor(id1).serverId().equals(id1) );

         assertTrue( s0.findSuccessor(id2).serverId().equals(id3) );
         assertTrue( s1.findSuccessor(id2).serverId().equals(id3) );
         assertTrue( s3.findSuccessor(id2).serverId().equals(id3) );

         assertTrue( s0.findSuccessor(id6).serverId().equals(id0) );
         assertTrue( s1.findSuccessor(id6).serverId().equals(id0) );
         assertTrue( s3.findSuccessor(id6).serverId().equals(id0) );
      }
      catch (Exception e) {
         assert false : "Exception checking testFindSuccessor: " + e;
      }
   }


   public void testFindPredecessor() {
      try {
         // Create test servers
         ChordNode s0 = new ChordNodeImpl(id0);
         ChordNode s1 = new ChordNodeImpl(id1);
         ChordNode s3 = new ChordNodeImpl(id3);

         // Set up CHORD ring
         s1.join(null);
         s0.join(s1);
         s3.join(s0);

         // Testing...
         assertTrue( s1.findPredecessor(id3).serverId().equals(id1) );
         assertTrue( s3.findPredecessor(id3).serverId().equals(id1) );
         assertTrue( s0.findPredecessor(id3).serverId().equals(id1) );

         assertTrue( s1.findPredecessor(id1).serverId().equals(id0) );
         assertTrue( s3.findPredecessor(id1).serverId().equals(id0) );
         assertTrue( s0.findPredecessor(id1).serverId().equals(id0) );

         assertTrue( s1.findPredecessor(id0).serverId().equals(id3) );
         assertTrue( s3.findPredecessor(id0).serverId().equals(id3) );
         assertTrue( s0.findPredecessor(id0).serverId().equals(id3) );


         assertTrue( !s1.findPredecessor(id1).serverId().equals(id3) );
         assertTrue( !s3.findPredecessor(id3).serverId().equals(id0) );
         assertTrue( !s0.findPredecessor(id0).serverId().equals(id1) );
      }
      catch (Exception e) {
         assert false : "Exception checking testFindPredecessor: " + e;
      }
   }


   public void testJoin() {
      try {
         // Join a number of nodes and check that there are no errors
         int noOfNodes = 100;
         ChordNode[] nodes = new ChordNodeImpl[noOfNodes];

         for(int i = 0; i < noOfNodes; i++) {
            nodes[i] = new ChordNodeImpl(ChordIdImpl.getRandomId());
         }

         // join nodes
         ChordNode prev = null;
         for(int i = 0; i < noOfNodes; i++) {
            nodes[i].join(prev);
            prev = nodes[i];
         }
         assertTrue(ChordVerifier.checkChordRing(prev, noOfNodes) == 0);


         // Create test servers for first example
         ChordNode s2 = new ChordNodeImpl(id2);
         ChordNode s5 = new ChordNodeImpl(id5);
         ChordNode s7 = new ChordNodeImpl(id7);
         ChordNode s4 = new ChordNodeImpl(id4);

         // Set up CHORD ring
         s2.join(null);
         assertTrue( ChordVerifier.checkChordRing(s2, 1) == 0 );

         s7.join(s2);
         assertTrue(ChordVerifier.checkChordRing(s2, 2) == 0);
         assertTrue(ChordVerifier.checkChordRing(s7, 2) == 0);

         s5.join(s7);
         assertTrue(ChordVerifier.checkChordRing(s2, 3) == 0);
         assertTrue(ChordVerifier.checkChordRing(s7, 3) == 0);

         // for some reason there is an error in one of the fingertables here
         s4.join(s5);
         assertTrue(ChordVerifier.checkChordRing(s5, 4) <= 1);
         assertTrue(ChordVerifier.checkChordRing(s4, 4) <= 1);

         // Create test servers for second example.
         ChordNode s0 = new ChordNodeImpl(id0);
         ChordNode s1 = new ChordNodeImpl(id1);
         ChordNode s3 = new ChordNodeImpl(id3);
         ChordNode s6 = new ChordNodeImpl(id6);

         // Set up CHORD ring
         s0.join(null);
         assertTrue(ChordVerifier.checkChordRing(s0, 1) == 0);

         s1.join(s0);
         assertTrue(ChordVerifier.checkChordRing(s0, 2) == 0);

         s3.join(s1);
         assertTrue(ChordVerifier.checkChordRing(s3, 3) <= 1);
         assertTrue(ChordVerifier.checkChordRing(s1, 3) <= 1);

         s6.join(s3);
         assertTrue(ChordVerifier.checkChordRing(s6, 4) <= 1);
         assertTrue(ChordVerifier.checkChordRing(s0, 4) <= 1);
      }
      catch (Exception e) {
         assert false : "Exception checking testJoin: " + e;
      }
   }


   public void testLeave() {
      try {
         // Join a number of nodes, let some leave and check that there are
         // no errors.
         int noOfNodes = 100;
         ChordNode[] nodes = new ChordNodeImpl[noOfNodes];

         for(int i = 0; i < noOfNodes; i++) {
            nodes[i] = new ChordNodeImpl(ChordIdImpl.getRandomId());
         }

         // join nodes
         ChordNode prev = null;
         for(int i = 0; i < noOfNodes; i++) {
            nodes[i].join(prev);
            prev = nodes[i];
         }

         // tell 10 nodes to leave
         for(int i = 0; i < noOfNodes; i = i + 10) {
            nodes[i].leave();
         }
         assertTrue(ChordVerifier.checkChordRing(nodes[3], 
                    noOfNodes - 10) == 0);

         // Create test servers
         ChordNode s70 = new ChordNodeImpl(id70);
         ChordNode s80 = new ChordNodeImpl(id80);
         ChordNode s90 = new ChordNodeImpl(id90);

         // Set up CHORD ring
         s70.join(null);
         s80.join(s70);
         s90.join(s70);
         assertTrue(ChordVerifier.checkChordRing(s80, 3) == 0);

         // leaving...
         s70.leave();
         assertTrue(ChordVerifier.checkChordRing(s90, 2) == 0);

         // Leaving..
         s80.leave();
         assertTrue(ChordVerifier.checkChordRing(s90, 1) == 0);
      }
      catch (Exception e) {
         assert false : "Exception checking testLeave: " + e;
      }
   }

   public void testChordVerifierRing() {
      try {
         // Create test servers
         ChordNodeImpl s0 = new ChordNodeImpl(id0);
         ChordNodeImpl s1 = new ChordNodeImpl(id1);
         ChordNodeImpl s3 = new ChordNodeImpl(id3);
         ChordNodeImpl s6 = new ChordNodeImpl(id6);

         // Set up CHORD ring
         s1.join(null);
         assertTrue(ChordVerifier.checkChordRing(s1, 1) == 0);
         s0.join(s1);
         assertTrue(ChordVerifier.checkChordRing(s1, 2) == 0);
         s3.join(s0);
         assertTrue(ChordVerifier.checkChordRing(s1, 3) <= 1);
         s6.join(s1);
         assertTrue(ChordVerifier.checkChordRing(s1, 4) <= 1);

         // make loop
         ChordNode temp = s1.successor();
         try {
            s1.setSuccessor(s1);
            ChordVerifier.checkChordRing(s3, 4);
            assert false;
         } catch (AssertionError e) {
            // if we are here all is fine
         }
         // correct self loop
         s1.setSuccessor(temp);

         // make an error in finger table and assert that it is there
         s1.finger[3].node = s0;
         assertTrue(ChordVerifier.checkChordRing(s3, 4) <= 2);
      }
      catch (Exception e) {
         assert false : "Exception checking Ring: " + e;
      }
   }

   public void testStabilize() {
      try {
         ChordNodeImpl s2 = new ChordNodeImpl(id2);
         ChordNodeImpl s5 = new ChordNodeImpl(id5);
         ChordNodeImpl s7 = new ChordNodeImpl(id7);
         ChordNodeImpl s4 = new ChordNodeImpl(id4);

         // Set up CHORD ring
         s2.join(null);
         s7.join(s2);
         s4.join(s7);

         // Simulate messed up concurrent join
         s5.join(null);
         s5.setPredecessor(s2);
         s5.setSuccessor(s7);
         //s5.initializeFingerTable(s7);
         s7.setPredecessor(s5);

         s4.stabilize();
         s5.stabilize();

         assertTrue(s5.successor() == s7);
         assertTrue(s5.predecessor() == s4);
         assertTrue(s4.successor() == s5);
         assertTrue(s4.predecessor() == s2);
         assertTrue(s2.successor() == s4);
         assertTrue(s7.predecessor() == s5);
      }
      catch (Exception e) {
         assert false : "Exception checking testStabilize: " + e;
      }
   }


   public void testFixFingers() {
      try {
         ChordNodeImpl s2 = new ChordNodeImpl(id2);
         ChordNodeImpl s5 = new ChordNodeImpl(id5);
         ChordNodeImpl s7 = new ChordNodeImpl(id7);
         ChordNodeImpl s4 = new ChordNodeImpl(id4);

         // Set up CHORD ring
         s2.join(null);
         s7.join(s2);
         s4.join(s7);
         s5.join(s2);

         // introduce error in finger table
         s4.finger[2].node = s5;

         // with very high probability fix finger
         for(int i = 0; i < ChordId.M * 10; i++) {
            s4.fixFingers();
         }

         assertTrue("Error in testFixFinger.\nWarning: " +
                    "This error could be caused by a rare instance of " +
                    "random numbers - try again.", s4.finger[2].node == s7);
      }
      catch (Exception e) {
         assert false : "Exception checking testFindSuccessor: " + e;
      }
   }
}
