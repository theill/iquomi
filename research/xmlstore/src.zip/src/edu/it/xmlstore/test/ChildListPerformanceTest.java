package edu.it.xmlstore.test;

import edu.it.xmlstore.xml.*;
import java.util.Random;

public class ChildListPerformanceTest {

   static Node testnode = CharData.createCharData("Test node");
   static final int REPETITIONS = 10;

   public static void main(String[] args) {
      int[] testsizes = {5, 10, 50, 100, 500, 1000, 1500, 2000, 5000, 10000,
                         15000, 25000, 50000, 75000, 100000};

      // Test redblack
      System.out.println("Testing RED BLACK\n");
      ChildList empty = new RbTreeChildList(new Node[]{});
      for (int i = 0; i < testsizes.length; i++)
         test(empty, testsizes[i]);

      System.out.println("Done!\n");

      // Test array
      System.out.println("Testing ARRAY\n");
      empty = new ArrayChildList(new Node[]{});
      for (int i = 0; i < testsizes.length; i++)
         test(empty, testsizes[i]);
      System.out.println("Done!\n");
   }

   public static void test(ChildList list, int size) {
      Random rand = new Random(7913);
      ChildList original = list;
      long totaltime = 0;

      for (int j = 1; j <= REPETITIONS; j++) {
        // insert 'size' children in child list
        long start = System.currentTimeMillis();
        for (int i = 1; i <= size; i++)
           list = list.insert(testnode, rand.nextInt(i));
        long stop = System.currentTimeMillis();
        System.out.println("Mellemtid: " + (stop - start));

        // measure total time taken.
        totaltime += (stop - start);
        list = original;
      }
      System.out.println("" + list.getClass() + " with size " +
                 size + " processed in " + (totaltime / REPETITIONS) + " ms.");
   }
}