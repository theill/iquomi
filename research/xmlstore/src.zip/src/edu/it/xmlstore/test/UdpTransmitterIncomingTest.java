package edu.it.xmlstore.test;

import junit.framework.*;

import edu.it.xmlstore.rpc.udp.*;
import edu.it.xmlstore.rpc.*;
import edu.it.xmlstore.chord.*;
import edu.it.xmlstore.*;

import java.net.DatagramSocket;
import java.net.DatagramPacket;
import java.net.SocketAddress;
import java.net.InetSocketAddress;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Arrays;


public class UdpTransmitterIncomingTest extends TestCase {

   // Initialize transmitter.
   private static final int TRANSMITTER_PORT = 10000;
   private static final InetSocketAddress TRANSMITTER_ADDRESS = new InetSocketAddress(TRANSMITTER_PORT);

   private static ValueReference id60 = null;
   private static FakeXmlStoreServer fakeServer = null;
   private static XmlStoreMessageDispatcher dispatcher = null;
   private static UdpTransmitter udpTransmitter = null;;

   private static OutgoingUdpMessage request;
   private static SocketAddress receiver = TRANSMITTER_ADDRESS;
   private static DatagramSocket socket = null;
   private static MessageFragment receivedFragment;

   private static ValueReference refTest = ValueUtil.getTestValueReference(100);
   
   private static final int SENDER_PORT = 10005;
   private static final InetSocketAddress SENDER_ADDRESS = new InetSocketAddress(SENDER_PORT);
   

   public UdpTransmitterIncomingTest(String name) {
      super(name);
      if (udpTransmitter == null) {
	 try {
	    id60 = new ChordIdImpl(60);
	    fakeServer = new FakeXmlStoreServer(id60, TRANSMITTER_PORT);
	    dispatcher = new XmlStoreMessageDispatcher(fakeServer);
	    udpTransmitter = new UdpTransmitter(TRANSMITTER_PORT, dispatcher);  
	    dispatcher.setTransmitter(udpTransmitter);
	    
	    socket = new DatagramSocket(SENDER_ADDRESS);    
	    socket.setReceiveBufferSize(MessageFragment.MAX_DATAGRAM_SIZE);   
	 }
	 catch (Exception e) {
	    throw new RuntimeException("Error in UdpTransmitterIncomingTest constructor");
	 }
      }
   }


   public static Test suite() {
      TestSuite suite = new TestSuite(UdpTransmitterIncomingTest.class);
      return suite;
   }


   public static void main(String[] args) {
      junit.textui.TestRunner.run(UdpTransmitterIncomingTest.class);
   }



   // ************* Test methods ****************
 
   // Send a request which only spans one fragment.
   public void testReceiveRequest() {
      byte[] content = new byte[]{0, 1, 2, 3, 4, 5, 6, 7};
      request = (OutgoingUdpMessage)
	 createMessageWithTwoArguments(NetworkUtil.SAVE_TO_DISK, content, ((ChordId) refTest).toBytes());
      FragmentList.Iterator fragments = request.iterator();
      IncomingUdpMessage i = null;
      try {
	 send(fragments.next());
	  i = receive();
      }
      catch (Exception e) {
	 throw new RuntimeException("Error in TestReceiveRequest: " + e);
      }
      assertTrue(fakeServer.saveToDiskCalled);
      assertTrue(Arrays.equals(fakeServer.receivedValue, content));
      assertEquals(fakeServer.receivedRef, refTest);
      assertTrue(i.getByte() == NetworkUtil.ALL_OK);
      fakeServer.reset();
   }
      
   
   // Sends a request where fragment two is missing. It will only be sent when the transmitter 
   // requests a retransmission.
   public void testReceiveRequestWithMissingFragment() { 
      byte[] content = new byte[MessageFragment.MAX_MESSAGE_SIZE * 3];
      for (int j=0; j < content.length; j++) 
	 content[j] = (byte)(j*Math.random());
      request = (OutgoingUdpMessage)
	 createMessageWithTwoArguments(NetworkUtil.SAVE_TO_DISK, content, ((ChordId) refTest).toBytes());
      FragmentList.Iterator fragments = request.iterator();
      IncomingUdpMessage i = null;
      try {
	 send(fragments.next());
	 MessageFragment missing = fragments.next();
	 send(fragments.next());
	 send(fragments.next());

	 // receive request for retransmission
	 do {
	    receivedFragment = receiveFragment();
	 } while (receivedFragment.getType() != MessageFragment.TYPE_RETRANSMIT_REQUEST);
	 send(missing);	  
	 i = receive();
      }
      catch(IOException e) {
	 throw new RuntimeException("Error in testReceiveRequestWithMissingFragment: " + e);
      }      
      assertTrue("1", fakeServer.saveToDiskCalled);
      //assertTrue("2", Arrays.equals(fakeServer.receivedValue, content));
      //assertEquals("3", fakeServer.receivedRef, refTest);
      //assertTrue("4", i.getByte() == NetworkUtil.ALL_OK);
      fakeServer.reset();
   }

   // Test that we can retransmit part of a reply. We simulate that we do not receive the
   // reply, and therefore we want the transmitter to send the missing reply again. 
   public void testRequestFragment() {
      byte[] content = new byte[]{0, 1, 2, 3, 4, 5, 6, 7};
      request = (OutgoingUdpMessage)
	 createMessageWithTwoArguments(NetworkUtil.SAVE_TO_DISK, content, ((ChordId) refTest).toBytes());
      FragmentList.Iterator fragments = request.iterator();
      IncomingUdpMessage i = null;
      MessageFragment reqFrag = null;
      MessageFragment again = null;
      try {
	 send(fragments.next());
	 i = receive();

	 // Request first packet of reply once again
	 reqFrag = new MessageFragment(i.getId(), 
				       NetworkUtil.INT_LENGTH, 
				       MessageFragment.TYPE_RETRANSMIT_REPLY,
				       (short)1,
				       (short)1);
	 // Store the package number to be retransmitted
	 reqFrag.putInt(0, 1);
	 send(reqFrag);
	 // Receive fragment 1 again.
	 again = receiveFragment();
      }
      catch (Exception e) {
	 throw new RuntimeException("Error in TestRequestFragment: " + e);
      }
      
      // Test that we received fragment one again.
      assertTrue(again.getId() == i.getId());
      assertTrue(again.getNumber() == 1);
      assertTrue(again.getTotal() == 1);
      assertTrue(again.getType() == MessageFragment.TYPE_REPLY);
      
      assertTrue(fakeServer.saveToDiskCalled);
      assertTrue(Arrays.equals(fakeServer.receivedValue, content));
      assertEquals(fakeServer.receivedRef, refTest);
      assertTrue(i.getByte() == NetworkUtil.ALL_OK);
      fakeServer.reset();
   }

   
   // We first send a request then we send a request for the status of the first request. 
   // Since the request takes a long time in fakeXmlStore the status will be 
   // "running". We then wait a while and status should be "complete".
   public void testRequestStatus() {
      byte[] content = new byte[]{0, 1, 2, 3, 4, 5, 6, 7};
      request = (OutgoingUdpMessage)
	 createMessageWithTwoArguments(NetworkUtil.SAVE_TO_DISK, content, ((ChordId) refTest).toBytes());
      int id = request.getId();
      FragmentList.Iterator fragments = request.iterator();
      IncomingUdpMessage i = null;
      MessageFragment reqStatus = null;
      MessageFragment statusReply = null;
      try {
	 send(fragments.next());

	 // Request status.
	 reqStatus = new MessageFragment(id, 
					 0, 
					 MessageFragment.TYPE_STATUS_REQUEST,
					 (short)1,
					 (short)1);
	 try {Thread.sleep(20);}catch(InterruptedException e){};
	 send(reqStatus);
	 statusReply = receiveFragment();
	 
	 // Check that the status of the request is "running".
	 assertTrue(statusReply.getType() == MessageFragment.TYPE_STATUS);
	 assertTrue(statusReply.getByte(0) == MessageFragment.STATUS_RUNNING);
	 
	 // Wait a while for the request to finish.
	 try {Thread.sleep(100);}catch(InterruptedException e){};
	 i = receive();
	 send(reqStatus);
	 statusReply = receiveFragment();
	 
	 // Check that the status of the request has moved from "running" to "complete".
	 assertTrue(statusReply.getType() == MessageFragment.TYPE_STATUS);
	 assertTrue(statusReply.getByte(0) == MessageFragment.STATUS_COMPLETE); 

	 
	 //try {Thread.sleep(2000);}catch(InterruptedException e){};
	 //send(reqStatus);
	 //statusReply = receiveFragment();

	 // Check that the status of the request has moved from "complete" to "unknown"
	 // because the request has been removed.
	 //assertTrue(statusReply.getType() == MessageFragment.TYPE_STATUS);
	 //assertTrue(statusReply.getByte(0) == MessageFragment.STATUS_UNKNOWN); 
	 
      }
      catch (Exception e) {
	 throw new RuntimeException("Error in TestRequestStatus: " + e);
      }
   }

   /*
   // We create a request that spands four fragments. We only send three fragments. The
   // third is never sent. Therefore the request should be removed from pending incoming
   // messages.
   public void testReceiveUnfinishedRequest() {
      byte[] content = new byte[MessageFragment.MAX_MESSAGE_SIZE * 3];
      for (int j=0; j < content.length; j++) 
	 content[j] = (byte)(j*Math.random());
      request = (OutgoingUdpMessage)
	 createMessageWithTwoArguments(NetworkUtil.SAVE_TO_DISK, content, ((ChordId) refTest).toBytes());
      int id = request.getId();
      FragmentList.Iterator fragments = request.iterator();
      IncomingUdpMessage i = null;
      MessageFragment reqStatus = null;
      MessageFragment statusReply = null;
      try {
	 send(fragments.next());
	 MessageFragment missing = fragments.next();
	 send(fragments.next());
	 send(fragments.next());

	 // Receive request for retransmission.
	 receiveFragment();
	 receiveFragment();
	 receiveFragment();
	 receiveFragment();
	 receiveFragment();
	 
	 // Wait for the transmitter to time out.
	 try {Thread.sleep(200);}catch(InterruptedException e){};

	 // Request status.
	 reqStatus = new MessageFragment(id, 
					 0, 
					 MessageFragment.TYPE_STATUS_REQUEST,
					 (short)1,
					 (short)1);
	 send(reqStatus);
	 statusReply = receiveFragment();

	 // Check that the status of the request is "unknown"
	 // because the request has been removed.
	 assertTrue(statusReply.getType() == MessageFragment.TYPE_STATUS);
	 assertTrue(statusReply.getByte(0) == MessageFragment.STATUS_UNKNOWN); 
      }
      catch (Exception e) {
	 throw new RuntimeException("Error in TestRequestStatus: " + e);
      }
   }
   */

   // ************* Helper methods ****************
   
      
   private void send(MessageFragment fragment) throws IOException {
      socket.send(new DatagramPacket(fragment.asArray(), 
				     fragment.asArray().length, 
				     receiver));
   }
      

   private MessageFragment receiveFragment() throws IOException {
      // Read bytes from datagram socket	 
      byte[] buffer = new byte[MessageFragment.MAX_DATAGRAM_SIZE];
      DatagramPacket incomingPacket = new DatagramPacket(buffer, MessageFragment.MAX_DATAGRAM_SIZE);
      socket.receive(incomingPacket);

      //System.out.println( "TEST: Received packet from " + incomingPacket.getSocketAddress() );
      // Note sender and return received fragment
      // sender = incomingPacket.getSocketAddress();
      receivedFragment = new MessageFragment(buffer);
      return receivedFragment;
   }


   private IncomingUdpMessage receive() throws IOException {
      // Read first fragment and determine whether more are coming
      IncomingUdpMessage message = null;
      MessageFragment fragment = null;

      do {	    
	 fragment = receiveFragment();
	 if (message == null)
	    message = new IncomingUdpMessage(fragment.getId());
	 message.addFragment(fragment);

      } while (!message.isComplete());
	 
      return message;
   }


   /**
    * Creates an outgoing message with two arguments to a method on the remote 
    * server. This is the protocol:
    * 1) Method   (byte)
    * 2) Number of arguments (byte)
    * 3) Length of argument1 (int)
    * 4) Length of argument2 (int)
    * 5) Argument1 (byte[])
    * 6) Argument2 (byte[])
    */
   private OutgoingMessage createMessageWithTwoArguments(byte method, 
							 byte[] arg1, 
							 byte[] arg2) {
      OutgoingMessage message = 
	 XmlStoreHome.getMessageFactory().createOutgoingMessage(10 +
								arg1.length + arg2.length);
      message.putByte(method);
      message.putByte((byte)2);
      message.putInt(arg1.length);
      message.putInt(arg2.length);
      message.putByteArray(arg1);
      message.putByteArray(arg2);
      return message;
   }
}
