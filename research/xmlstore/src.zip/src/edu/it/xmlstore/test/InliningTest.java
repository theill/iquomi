package edu.it.xmlstore.test;

import java.io.File;
import junit.framework.*;
import edu.it.xmlstore.*;
import edu.it.xmlstore.xml.*;
import edu.it.xmlstore.chord.*;


public class InliningTest extends TestCase {
   private static char sep =  File.separatorChar;
   private static String testFile = ".." + sep 
                                    + "files" + sep 
                                    + "xmldocs" + sep
                                    + "inlining.xml";

   public InliningTest(String name) {
      super(name);
   }

   public static Test suite() {
      TestSuite suite = new TestSuite(InliningTest.class);
      return suite;
   }

   public static void main(String[] args) {
      junit.textui.TestRunner.run(InliningTest.class);
   }

   ValueReference id70 = new ChordIdImpl(70);
   ValueReference id80 = new ChordIdImpl(80);
    
   public void testInlining() {
      try {
         // Create test server
         XmlStoreServerImpl s70 = new XmlStoreServerImpl(id70);
         XmlStoreServerImpl s80 = new XmlStoreServerImpl(id80);
         s70.join(null);
         s80.join(s70);
         
         // Convert test document to object representation
	 Element savedDoc = Element.createElementFromFile(testFile);         
	 ValueReference ref = s70.save(savedDoc);
         assertTrue(savedDoc.isSaved());
	 Node loadedDoc = s80.load(ref);
	 assertTrue(savedDoc.equalsContents(loadedDoc));

	 // Leave properly
         s70.leave();
         s80.leave();
      } 
      catch (Exception e) {
         e.printStackTrace();
         assertTrue("Exception in InliningTest: " + e, false);
      }        
   }     

   /* Small test for finding out how long the string representation and byte ditto actually is
   public void testRefSize() {
      ValueReference max = new ChordIdImpl(ChordId.MAX_VALUE);
      byte[] refAsBytes = max.toBytes();
      System.out.println("Byte array length: " + refAsBytes.length);
      String s = max.toString();
      System.out.println("String length: " + s.length());
      System.out.println("String: " + s);

   }
   */

        
}
