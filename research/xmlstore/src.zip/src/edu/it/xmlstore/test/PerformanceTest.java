package edu.it.xmlstore.test;

import edu.it.xmlstore.*;
import edu.it.xmlstore.rpc.*;
import edu.it.xmlstore.chord.*;
import edu.it.xmlstore.xml.*;
import edu.it.xmlstore.rpc.*;
import edu.it.xmlstore.directory.*;
import java.io.*;
import java.net.*;

public class PerformanceTest {
   FileWriter out;
   static Directory directory;

   private void saveTest(XmlStoreServer server, String document) {
      try {
         System.gc();
         Element element = Element.createElementFromFile("./../xmldocs/" +
							 document);
         System.out.println(document + " created.");
         long timeBefore = System.currentTimeMillis();
         ValueReference vr = server.save(element);
         long time = System.currentTimeMillis() - timeBefore;
         directory.bind(document, vr);
         writeResultToFile(document, time);
         System.out.println(document + " saved and result written.");
      }
      catch(Exception e) {
         System.out.println("Error saving document: " + e);
         writeErrorToFile(document, true);
      }
   }

   private void loadTest(XmlStoreServer server, String document) {
      try {
         System.gc();
         ValueReference vr = directory.lookup(document);
         long timeBefore = System.currentTimeMillis();
         Node n = server.load(vr);
         String temp = n.asString();
         long time = System.currentTimeMillis() - timeBefore;
         writeResultToFile(document, time);
         System.out.println(document + " loaded and result written.");
      }
      catch(Exception e) {
         System.out.println("Error loading document: " + e);
         writeErrorToFile(document, false);
      }
   }

   private void writeResultToFile(String document, long time) {
      try {
         out.write("Document: \"" + document + "\" time: " + time + "\n");
         out.flush();
      } catch (IOException e) {
         System.out.println("Error saving document: " + e);
         System.exit(-1);
      }
   }

   private void writeErrorToFile(String document, boolean save) {
      try {
         if (save)
            out.write("Error. Document: " + document + " cannot be saved.\n");
         else
            out.write("Error. Document: " + document + " cannot be loaded.\n");
         out.flush();
      } catch (IOException e) {
         System.out.println("Error writing error to document: " + e);
         System.exit(-1);
      }
   }


   public static void main(String[] args) throws IOException {
      assert args.length == 2 :
	 "Remember to give port number and filenames as arguments";
      int port = Integer.parseInt(args[0]);
      int save = Integer.parseInt(args[1]);
      XmlStoreServer server = XmlStoreHome.bootstrap(port);
      XmlStoreHome.addConnectedServer(server);
      directory = XmlStoreHome.getDirectory(port);
      System.out.println("Found external server: " + server);

      File dir = new File("./../xmldocs/");
      String[] documents = dir.list();

      PerformanceTest p = new PerformanceTest();
      p.setup();
      if (save == 1) {
	 p.out.write("Saving documents\n");
	 for (int i = 0; i < documents.length; i++)
	    p.saveTest(server, documents[i]);
	 System.out.println("Done saving");
      
      }
      else {
	 p.out.write("Loading documents\n");
	 for (int i = 0; i < documents.length; i++)
	    p.loadTest(server, documents[i]);
	 System.out.println("Done loading");
      }
      p.shutdown();
   }

   private void setup() {
      try {
         out = new FileWriter("./../performanceResults/result.txt", true);
      } catch (IOException e) {
         System.out.println("Error in setup: " + e);
         System.exit(-1);
      }
   }

   private void shutdown() {
      try {
         out.close();
      } catch (IOException e) {
         System.out.println("Error in shutdown: " + e);
         System.exit(-1);
      }
   }
}

// java -cp build edu.it.xmlstore.test.PerformanceTest 7000 1
// java -cp build edu.it.xmlstore.directory.DirectoryImpl 
