package edu.it.xmlstore.test;

import junit.framework.*;
import edu.it.xmlstore.chord.*;
import java.math.BigInteger;

/**
 * NB! This test only works when ChordId.M == 160!
 */

public class ChordIdImplTest extends TestCase {

   public ChordIdImplTest(String name) {
      super(name);
   }

   public static Test suite() {
      TestSuite suite = new TestSuite(ChordIdImplTest.class);
      return suite;
   }

   public static void main(String[] args) {
      junit.textui.TestRunner.run(ChordIdImplTest.class);
   }


   public void testWrapAround() {
      // Negative numbers
      ChordId idneg10 = new ChordIdImpl(-10);
      assertTrue( idneg10.equals(new ChordIdImpl(ChordId.MAX_VALUE.subtract(
                                                     new BigInteger("10")))) );

      // Higher than maximum
      ChordId verylarge = new ChordIdImpl(
                                 ChordId.MAX_VALUE.add(
                                 new BigInteger("2")).toString() );
      assertTrue( verylarge.equals(new ChordIdImpl(1)) );

      // Zero and Maximum
      ChordId id0 = new ChordIdImpl(0);
      assertTrue( id0.equals(new ChordIdImpl(0)) );
      ChordId idmax = new ChordIdImpl(ChordId.MAX_VALUE.toString());
      assertTrue( idmax.equals(new ChordIdImpl(ChordId.MAX_VALUE.toString())));
   }


   public void testEquals() {
      ChordId id0 = new ChordIdImpl(0);
      ChordId id1 = new ChordIdImpl(1);
      ChordId id1a = new ChordIdImpl(1);
      ChordId large = new ChordIdImpl(565465132);

      assertTrue( id1.equals(id1a) );
      assertTrue( large.equals(large) );

      assertTrue( !id0.equals(id1) );
      assertTrue( !id0.equals(large) );
   }

   public void testAdd() {
      ChordId id5 = new ChordIdImpl(5);
      ChordId id22 = new ChordIdImpl(22);
      ChordId idmax = new ChordIdImpl(ChordId.MAX_VALUE);

      assertTrue( id5.add(id22).equals(new ChordIdImpl(27)) );
      assertTrue( !id5.add(id22).equals(new ChordIdImpl(0)) );
      assertTrue( idmax.add(id5).equals(new ChordIdImpl(4)) );
   }

   public void testSubtract() {
      ChordIdImpl id5 = new ChordIdImpl(5);
      ChordIdImpl id22 = new ChordIdImpl(22);

      assertTrue( id22.subtract(id5).equals(new ChordIdImpl(17)) );
      assertTrue( id5.subtract(id22).equals(
                  new ChordIdImpl(ChordId.MAX_VALUE.subtract(
                                  new BigInteger("17")))) );
   }

   public void testPow() {
      ChordId id2 = new ChordIdImpl(2);
      ChordId id3 = new ChordIdImpl(3);

      assertTrue( id2.pow(0).equals(new ChordIdImpl(1)) );
      assertTrue( id2.pow(1).equals(new ChordIdImpl(2)) );
      assertTrue( id2.pow(2).equals(new ChordIdImpl(4)) );
      assertTrue( id2.pow(3).equals(new ChordIdImpl(8)) );

      assertTrue( id3.pow(0).equals(new ChordIdImpl(1)) );
      assertTrue( id3.pow(1).equals(new ChordIdImpl(3)) );
      assertTrue( id3.pow(2).equals(new ChordIdImpl(9)) );
      assertTrue( id3.pow(3).equals(new ChordIdImpl(27)) );

        //2^159 found by haskell:
      assertTrue( id2.pow(159).equals(
                     new ChordIdImpl(new BigInteger(
                        "730750818665451459101842416358141509827966271488"))));
   }

   public void testLessThan() {
      ChordId id2 = new ChordIdImpl(2);
      ChordId id2a = new ChordIdImpl(2);
      ChordId id3 = new ChordIdImpl(3);

      assertTrue( id2.lessThan(id3) );
      assertTrue( !id2.lessThan(id2a) );
      assertTrue( !id3.lessThan(id2) );
   }

   public void testLessThanEqual() {
      ChordId id2 = new ChordIdImpl(2);
      ChordId id2a = new ChordIdImpl(2);
      ChordId id3 = new ChordIdImpl(3);

      assertTrue( id2.lessThanEqual(id3) );
      assertTrue( id2.lessThanEqual(id2a) );
      assertTrue( !id3.lessThanEqual(id2) );
   }

   public void testGreaterThan() {
      ChordId id2 = new ChordIdImpl(2);
      ChordId id2a = new ChordIdImpl(2);
      ChordId id3 = new ChordIdImpl(3);

      assertTrue( id3.greaterThan(id2) );
      assertTrue( !id2.greaterThan(id2a) );
      assertTrue( !id2.greaterThan(id3) );
   }

   public void testGreaterThanEqual() {
      ChordId id2 = new ChordIdImpl(2);
      ChordId id2a = new ChordIdImpl(2);
      ChordId id3 = new ChordIdImpl(3);

      assertTrue( id3.greaterThanEqual(id2) );
      assertTrue( id2.greaterThanEqual(id2a) );
      assertTrue( !id2.greaterThanEqual(id3) );
   }

   public void testIsBetween() {
      ChordId zero = new ChordIdImpl(0);
      ChordId one = new ChordIdImpl(1);
      ChordId two = new ChordIdImpl(2);
      ChordId three = new ChordIdImpl(3);
      ChordId five = new ChordIdImpl(5);
      ChordId six = new ChordIdImpl(6);

      assertTrue( ChordId.isBetween(two, one, three) );
      assertTrue( ChordId.isBetween(six, three, zero) );

      assertTrue( !ChordId.isBetween(zero, zero, one) );
      assertTrue( !ChordId.isBetween(zero, zero, zero) );
      assertTrue( !ChordId.isBetween(six, zero, one) );
      assertTrue( !ChordId.isBetween(five, six, zero) );
      assertTrue( !ChordId.isBetween(one, zero, one) );
   }

   public void testIsBetweenLeftIncl() {
      ChordId zero = new ChordIdImpl(0);
      ChordId one = new ChordIdImpl(1);
      ChordId two = new ChordIdImpl(2);
      ChordId three = new ChordIdImpl(3);
      ChordId five = new ChordIdImpl(5);
      ChordId six = new ChordIdImpl(6);

      assertTrue( ChordId.isBetweenLeftIncl(three, zero, six) );
      assertTrue( ChordId.isBetweenLeftIncl(one, one, zero) );
      assertTrue( ChordId.isBetweenLeftIncl(two, one, three) );
      assertTrue( ChordId.isBetweenLeftIncl(six, three, zero) );
      assertTrue( ChordId.isBetweenLeftIncl(zero, zero, zero) );
      assertTrue( ChordId.isBetweenLeftIncl(one, zero, zero) );

      assertTrue( !ChordId.isBetweenLeftIncl(one, zero, one) );
      assertTrue( !ChordId.isBetweenLeftIncl(one, two, one) );
      assertTrue( !ChordId.isBetweenLeftIncl(six, zero, one) );
      assertTrue( !ChordId.isBetweenLeftIncl(five, six, zero) );
   }

   public void testIsBetweenRightIncl() {
      ChordId zero = new ChordIdImpl(0);
      ChordId one = new ChordIdImpl(1);
      ChordId two = new ChordIdImpl(2);
      ChordId three = new ChordIdImpl(3);
      ChordId five = new ChordIdImpl(5);
      ChordId six = new ChordIdImpl(6);

      assertTrue( ChordId.isBetweenRightIncl(three, zero, six) );
      assertTrue( ChordId.isBetweenRightIncl(one, zero, one) );
      assertTrue( ChordId.isBetweenRightIncl(two, one, three) );
      assertTrue( ChordId.isBetweenRightIncl(six, three, zero) );
      assertTrue( ChordId.isBetweenRightIncl(zero, zero, zero) );
      assertTrue( ChordId.isBetweenRightIncl(one, two, one) );

      assertTrue( !ChordId.isBetweenRightIncl(one, one, zero) );
      assertTrue( !ChordId.isBetweenRightIncl(six, zero, one) );
      assertTrue( !ChordId.isBetweenRightIncl(five, six, zero) );
   }
}
