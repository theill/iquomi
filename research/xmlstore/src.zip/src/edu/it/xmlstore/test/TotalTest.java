package edu.it.xmlstore.test;

import junit.framework.*;

public class TotalTest extends TestCase {

   public TotalTest(String name) {
      super(name);
   }

   public static Test suite() {
      TestSuite suite = new TestSuite();

      // Chord related tests     
      suite.addTestSuite(edu.it.xmlstore.test.ChordIdImplTest.class);
      suite.addTestSuite(edu.it.xmlstore.test.ChordNodeTest.class);

      // XML related tests
      suite.addTestSuite(edu.it.xmlstore.test.NodeTest.class);
      suite.addTestSuite(edu.it.xmlstore.test.ArrayChildListTest.class);
      suite.addTestSuite(edu.it.xmlstore.test.BinaryTreeChildListTest.class);
      suite.addTestSuite(edu.it.xmlstore.test.RbTreeChildListTest.class);
      suite.addTestSuite(edu.it.xmlstore.test.InliningTest.class);

      // Storage related tests
      suite.addTestSuite(edu.it.xmlstore.test.RAFileDiskTest.class);
      suite.addTestSuite(edu.it.xmlstore.test.MultiFileDiskTest.class);

      // XML Store Server related tests
      suite.addTestSuite(edu.it.xmlstore.test.XmlHomeTest.class);
      suite.addTestSuite(edu.it.xmlstore.test.XmlStoreServerTest.class);

      // Name Service related tests
      suite.addTestSuite(edu.it.xmlstore.test.DirectoryTest.class);

      // RPC related tests
      suite.addTestSuite(edu.it.xmlstore.test.UdpTransmitterTest.class);
      suite.addTestSuite(edu.it.xmlstore.test.UdpTransmitterIncomingTest.class);
      suite.addTestSuite(edu.it.xmlstore.test.UdpMessageTest.class);     
      suite.addTestSuite(edu.it.xmlstore.test.XmlStoreMessageDispatcherTest.class);      
      suite.addTestSuite(edu.it.xmlstore.test.RemoteDirectoryTest.class);

      return suite;
   }

   public static void main(String[] args) {
      junit.textui.TestRunner.run(TotalTest.suite());
   }
}
