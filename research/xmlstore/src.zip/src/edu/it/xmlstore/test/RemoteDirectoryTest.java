package edu.it.xmlstore.test;

import edu.it.xmlstore.rpc.udp.*;
import edu.it.xmlstore.rpc.*;
import edu.it.xmlstore.xml.*;
import edu.it.xmlstore.*;
import edu.it.xmlstore.directory.*;

import junit.framework.*;

import java.net.InetAddress;

public class RemoteDirectoryTest extends TestCase {

   public RemoteDirectoryTest(String name) {
      super(name);
   }

   public static Test suite() {
      TestSuite suite = new TestSuite(RemoteDirectoryTest.class);
      return suite;
   }

   public static void main(String[] args) {
      junit.textui.TestRunner.run(RemoteDirectoryTest.class);
   }

   static {
      try {
	 // Proxies use the system transmitter (at port 8096) to send messages
	 XmlStoreHome.getMessageFactory().initializeTransmitter(8096, null);
      } catch (RemoteException e) {
	 System.err.println("Could not initialize RemoteDirectoryTest:" + e);
	 throw new RuntimeException("Could not initialize RemoteDirectoryTest.");
      }
   }

   public void testBindLookup() {
      Transmitter dt = null;
      try {
         // Create and start name service at localhost:10001
	 Directory dir = new DirectoryImpl();      
	 DirectoryMessageDispatcher md = new DirectoryMessageDispatcher(dir);
	 dt = new UdpTransmitter(10001, md);
	 md.setTransmitter(dt);

	 // create proxy to name service and start communicating
         DirectoryProxy proxy = new DirectoryProxy(InetAddress.getLocalHost(), 10001);


	 // do tests
	 ValueReference ref1  = ValueUtil.getTestValueReference(1);
	 ValueReference ref2  = ValueUtil.getTestValueReference(2);
	 ValueReference ref3  = ValueUtil.getTestValueReference(3);

	 String name1 = "Ref1";
	 String name2 = "Ref2";
	 String unknownName = "Unknown";

	 // bind a name and look it up
	 proxy.bind(name1, ref1);
	 proxy.bind(name2, ref2);
	 assertEquals(ref1, proxy.lookup(name1));
	 
	 // bind an already bound name -- we expect an exception
	 try {
	    proxy.bind(name1, ref3);
	    assertTrue(false);
	 }
	 catch (NameAllreadyBoundException e) {
	    // all went well ...
	 }

	 // lookup unknown name -- we expect an exception
	 try {
	    proxy.lookup(unknownName);
	    assertTrue(false);
	 }
	 catch (NoSuchElementException e) {
	    // all went well ...
	 }

      }
      catch (Exception e) {
	 e.printStackTrace(System.out);
         assertTrue("Exception checking remote methods in Directory: " + e, false);
      }     
   }

   public void testUnbind() {
      DirectoryProxy proxy = null;
      try {
         // Create and start name service at localhost:10002
	 Directory dir = new DirectoryImpl();      
	 DirectoryMessageDispatcher md = new DirectoryMessageDispatcher(dir);
	 Transmitter dt = new UdpTransmitter(10002, md);
	 md.setTransmitter(dt);

	 // create proxy to name service and start communicating
         proxy = new DirectoryProxy(InetAddress.getLocalHost(), 10002);


	 ValueReference ref1  = ValueUtil.getTestValueReference(1);
	 String name = "name";

	 try {
	    proxy.bind(name, ref1);
	    assertEquals(ref1, proxy.lookup(name));
	 }
	 catch (NameAllreadyBoundException e) {
	    assertTrue(false);
	 }
	 catch (NoSuchElementException e) {
	    assertTrue(false);
	 }

	 try {
	    proxy.unbind(name);
	 }
	 catch(NoSuchElementException e) {
	    assertTrue(false);
	 }
      
	 try {
	    proxy.lookup(name);
	    assertTrue(false);
	 }
	 catch(NoSuchElementException e) {
	    // great ...
	 }
      }
      catch (Exception e) {
	 e.printStackTrace(System.out);
         assertTrue("Exception checking remote methods in Directory: " + e, false);
      }
   }

   public void testUpdate() {
      DirectoryProxy proxy = null;
      try {
         // Create and start name service at localhost:10003
	 Directory dir = new DirectoryImpl();      
	 DirectoryMessageDispatcher md = new DirectoryMessageDispatcher(dir);
	 Transmitter dt = new UdpTransmitter(10003, md);
	 md.setTransmitter(dt);

	 // create proxy to name service and start communicating
         proxy = new DirectoryProxy(InetAddress.getLocalHost(), 10003);

         ValueReference ref1  = ValueUtil.getTestValueReference(1);
         ValueReference ref2  = ValueUtil.getTestValueReference(2);
         ValueReference ref3  = ValueUtil.getTestValueReference(3);

         String name = "name";
         try {
            proxy.bind(name, ref1);
         }
         catch(NameAllreadyBoundException e) {
            assertTrue(false);
         }

         // rebind with an unexpected value -- we expect an exception
         try {
            proxy.update(name, ref2, ref3);
            assertTrue("No Exception", false);
         }
         catch(ConcurrentAccessException e) {
            // great ...
         }
         catch(NoSuchElementException e) {
            assertTrue(false);
         }

         // rebind with an expected value
         try {
            proxy.update(name, ref2, ref1);
            assertEquals(ref2, proxy.lookup(name));
         }
         catch(ConcurrentAccessException e) {
            assertTrue(false);
         }
         catch(NoSuchElementException e) {
            assertTrue(false);
         }

      }
      catch (Exception e) {
	 e.printStackTrace(System.out);
         assertTrue("Exception checking remote methods in Directory: " + e, false);
      }

   }
}
