package edu.it.xmlstore.test;

import edu.it.xmlstore.*;
import edu.it.xmlstore.xml.*;

import java.io.*;

public class ModificationTest {

   public static void main(String[] args) throws IOException {
      assert args.length == 1 : "Remember to give port number as argument";
      int port = Integer.parseInt(args[0]);

      try {
         // Find server
         XmlStoreServer server = XmlStoreHome.bootstrap(port);         

         // Convert hamlet to nodes...
         Node hamlet = Element.createElementFromFile(".." + File.separatorChar + 
						     ".." + File.separatorChar + 
						     "files" + File.separatorChar + 
						     "xmldocs" + File.separatorChar +
                                                     "hamlet.xml");
         System.out.println("Hamlet loaded");

         // Save document
         long start = System.currentTimeMillis();
         server.save((Element)hamlet);
         long stop = System.currentTimeMillis();
         System.out.println("Saved Hamlet in  " + (stop-start) + " ms.");

         // make modification - save again
         // Add character
         ChildList persons = XmlHome.lookup(hamlet, "PERSONAE/*");

         Node richard = Element.createElement("PERSONA", new Node[]{
                    CharData.createCharData("RICHARD, Duke of Gloucester," +
                                            "afterwards King Richard III.")});
         hamlet = XmlHome.insertBefore(hamlet, "PERSONAE",
                                       persons.get(1), richard);
         start = System.currentTimeMillis();
         server.save((Element)hamlet);
         stop = System.currentTimeMillis();
         System.out.println("Character added. Time: " + (stop-start));

         // make modification - save again
         // change the title
         Node newTitle = CharData.createCharData("The Comedy of Hamlet," +
                                                 "Prince of Denmark");
         Node oldTitle =
                 XmlHome.lookup(hamlet, "TITLE").get(0).getChildNodes().get(0);
         hamlet = XmlHome.replace(hamlet, "TITLE", oldTitle, newTitle);
         start = System.currentTimeMillis();
         server.save((Element)hamlet);
         stop = System.currentTimeMillis();
         System.out.println("Title changed. Time: " + (stop-start));

         // make modification - save again
         // add speech
         ChildList speeches = XmlHome.lookup(hamlet, "ACT/SCENE/SPEECH");
         Node newSpeaker = Element.createElement("SPEAKER",
                     new Node[] {CharData.createCharData("KING RICHARD III")});
         Node newLine = Element.createElement("LINE", new Node[]
                        {CharData.createCharData("A horse! a horse! " +
                                                 "my kingdom for a horse!")});
         Node newSpeech = Element.createElement("SPEECH",
                                              new Node[]{newSpeaker, newLine});
         hamlet = XmlHome.insertBefore(hamlet, "ACT/SCENE", speeches.get(4),
                                       newSpeech);
         start = System.currentTimeMillis();
         server.save((Element)hamlet);
         stop = System.currentTimeMillis();
         System.out.println("Speech added. Time: " + (stop-start));

         // make modification - save again
         // change "to be" to "to do"
         //<LINE>To be, or not to be: that is the question:</LINE>
         newLine = Element.createElement("LINE", new Node[]
                           {CharData.createCharData("To do, or not to do:" +
                           "that is the question:")});
         ChildList lines = XmlHome.lookup(hamlet, "ACT/SCENE/SPEECH/LINE");

         int lineNo = -1;
         for (int i = 0; i < lines.size(); i++)
            if(lines.get(i).getChildNodes().get(0).getValue().startsWith("To " +
               "be, or not to be:")) {
               lineNo = i;
               break;
            }
         hamlet = XmlHome.replace(hamlet, "ACT[3]/SCENE/SPEECH[19]",
                                  lines.get(lineNo), newLine);
         start = System.currentTimeMillis();
         server.save((Element)hamlet);
         stop = System.currentTimeMillis();
         System.out.println("Line changed. Time: " + (stop-start));

         // make modification - save again
         // delete final scene of play
         ChildList lastScene = XmlHome.lookup(hamlet, "ACT[5]/SCENE[2]");
         hamlet = XmlHome.remove(hamlet, "ACT[5]", lastScene.get(0));
         ChildList lastAct = XmlHome.lookup(hamlet, "ACT[5]");
         start = System.currentTimeMillis();
         server.save((Element)hamlet);
         stop = System.currentTimeMillis();
         System.out.println("Final scene deleted. Time: " + (stop-start));
         //System.out.println("Result: " + hamlet.asString());
      }
      catch(Exception e) {
         System.out.println("Error during test: " + e);
      }
   }
}

