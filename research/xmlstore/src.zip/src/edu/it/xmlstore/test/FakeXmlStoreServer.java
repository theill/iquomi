package edu.it.xmlstore.test;

import edu.it.xmlstore.rpc.*;
import edu.it.xmlstore.rpc.udp.UdpTransmitter;
import edu.it.xmlstore.*;
import edu.it.xmlstore.xml.*;
import edu.it.xmlstore.chord.*;
import java.net.InetSocketAddress;
import java.io.IOException;
import java.util.Arrays;


// XmlStoreServer for test.
class FakeXmlStoreServer extends XmlStoreServerImpl {
   public boolean saveToDiskCalled = false;
   public boolean saveValueCalled = false;
   public boolean updateFingerTableCalled = false;
   public boolean removeFromFingerTableCalled = false;
   public boolean setPredecessorCalled = false;
   public boolean setSuccessorCalled = false;
   public boolean notifyCalled = false;
   public boolean moveKeysCalled = false;
   public boolean moveAllKeysCalled = false;
   public byte[] receivedValue;
   public ValueReference receivedRef;

      
   public static final int PORT60 = 8160;

   // Return values.
   public ValueReference ref60 = ValueUtil.getTestValueReference(60);
   public XmlStoreServer returnXmlStore = new XmlStoreServerImpl(ref60, PORT60);
   public byte[] returnByteArray = new byte[]{0, 1, 2, 3, 4, 5, 6, 7}; 
      
   public FakeXmlStoreServer(ValueReference serverId, int port) {
      super(serverId, port);
   }

   public void reset() {
      saveToDiskCalled = false;
      receivedValue = null;
      receivedRef = null;
   }

   public void saveToDisk(byte[] value, ValueReference ref) 
      throws RemoteException {
      saveToDiskCalled =  true;
      receivedValue = value;
      receivedRef = ref;
      // Wait a while to simulate running request.
      try {Thread.sleep(200);}catch(InterruptedException e){};
   }

   public void saveValue(byte[] value, ValueReference key) 
      throws RemoteException {
      saveValueCalled = true; 
   }

   public void updateFingerTable(ChordNode n, int i) 
      throws RemoteException {
      updateFingerTableCalled = true;
   }

   public void removeFromFingerTable(ChordNode n, int i) 
      throws RemoteException {
      removeFromFingerTableCalled = true;
   }
      
   public ChordNode closestPrecedingFinger(ChordId id) 
      throws RemoteException {
      return returnXmlStore;
   }

   public ChordNode findPredecessor(ChordId id) 
      throws RemoteException {
      return returnXmlStore;
   }

   public ChordNode findSuccessor(ChordId id) 
      throws RemoteException {
      return returnXmlStore;
   }

   public void setPredecessor(ChordNode predecessor) {
      setPredecessorCalled = true;
   }

   public void setSuccessor(ChordNode n) {
      setSuccessorCalled = true;
   }

   public void notify(ChordNode n) {
      notifyCalled = true;
   }

   public byte[] loadValue(ValueReference key) throws RemoteException {
      return returnByteArray;
   }

   public void moveKeys(XmlStoreServer n) throws RemoteException {
      moveKeysCalled = true;
   }

   public void moveAllKeys(XmlStoreServer n) throws RemoteException {
      moveAllKeysCalled = true;
   }

   public ChordNode successor() throws RemoteException {
      return returnXmlStore;
   }

   public ChordNode predecessor() {
      return returnXmlStore;
   }
}
