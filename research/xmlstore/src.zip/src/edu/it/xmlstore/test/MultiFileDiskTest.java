package edu.it.xmlstore.test;

import junit.framework.*;

import edu.it.xmlstore.storage.*;
import edu.it.xmlstore.ValueReference;
import edu.it.xmlstore.XmlStoreServerImpl;
import edu.it.xmlstore.ValueUtil;

import java.io.File;

public class MultiFileDiskTest extends TestCase {

   public MultiFileDiskTest(String name) {
      super(name);
   }

   public static Test suite() {
      TestSuite suite = new TestSuite(MultiFileDiskTest.class);
      return suite;
   }

   public static void main(String[] args) {
      junit.textui.TestRunner.run(MultiFileDiskTest.class);
   }

   public void testSave() {
      try {
         Disk disk = new MultiFileDisk(XmlStoreServerImpl.SAVE_DIRECTORY + File.separatorChar + "multifiletest");

         String value1  = "First value";
         String value1a = "First value";
         String value2  = "Second value";

         ValueReference ref1  = ValueUtil.getValueReference(value1.getBytes());
         ValueReference ref2  = ValueUtil.getValueReference(value2.getBytes());
         ValueReference ref1a = ValueUtil.getValueReference(value1a.getBytes());

         disk.save(value1.getBytes(), ref1);
         disk.save(value2.getBytes(), ref2);
         disk.save(value1a.getBytes(), ref1a);

         assertTrue(ref1.equals(ref1a));
         assertTrue(!ref2.equals(ref1));
      } catch (java.io.IOException e) {
         assertTrue("IOException", false);
      }
   }

   public void testLoad() {
      try {
         Disk disk = new MultiFileDisk(XmlStoreServerImpl.SAVE_DIRECTORY + File.separatorChar + "multifiletest");

         String value1  = "First value";
         String value1a = "First value";
         String value2  = "Second value";

         ValueReference ref1  = ValueUtil.getValueReference(value1.getBytes());
         ValueReference ref2  = ValueUtil.getValueReference(value2.getBytes());
         ValueReference ref1a = ValueUtil.getValueReference(value1a.getBytes());

         disk.save(value1.getBytes(), ref1);
         disk.save(value2.getBytes(), ref2);
         disk.save(value1a.getBytes(), ref1a);

         String lvalue1  = new String( disk.load(ref1) );
         String lvalue1a = new String( disk.load(ref1a) );
         String lvalue2  = new String( disk.load(ref2) );

         assertTrue(value1.equals(lvalue1));
         assertTrue(value1.equals(lvalue1a));
         assertTrue(!value2.equals(lvalue1));
      } catch (java.io.IOException e) {
         assertTrue("IOException", false);
      }
   }

   public void testDelete() {
      Disk disk = new MultiFileDisk(XmlStoreServerImpl.SAVE_DIRECTORY + File.separatorChar + "multifiletest");
      String value1  = "First value";
      String value1a = "First value";
      String value2  = "Second value";

      ValueReference ref1  = ValueUtil.getValueReference(value1.getBytes());
      ValueReference ref2  = ValueUtil.getValueReference(value2.getBytes());
      ValueReference ref1a = ValueUtil.getValueReference(value1a.getBytes());

      try {
         disk.save(value1.getBytes(), ref1);
         disk.save(value2.getBytes(), ref2);
         disk.save(value1a.getBytes(), ref1a);

         disk.delete(ref1);
      } catch (java.io.IOException e) {
         assertTrue("IOException", false);
      }

      // make sure ref1 is not in the store
      try {
         disk.load(ref1);
         assertTrue(false);
      } catch(java.io.IOException e) {
         // everything works
      }
   }
}
