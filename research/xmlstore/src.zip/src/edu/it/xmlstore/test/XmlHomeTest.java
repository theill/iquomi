package edu.it.xmlstore.test;

import junit.framework.*;
import java.io.*;
import edu.it.xmlstore.*;
import java.util.ArrayList;
import java.util.List;
import edu.it.xmlstore.xml.*;

public class XmlHomeTest extends TestCase {

   public XmlHomeTest(String name) {
      super(name);
   }

   public static Test suite() {
      TestSuite suite = new TestSuite(XmlHomeTest.class);
      return suite;
   }

   public static void main(String[] args) {
      junit.textui.TestRunner.run(XmlHomeTest.class);
   }

   // XML tree used in all tests.
   Node text1 = CharData.createCharData("Text1");
   Node text2 = CharData.createCharData("Text2");
   Node text3 = CharData.createCharData("Text3");
   Node text4 = CharData.createCharData("Text4");
   Node para1 = Element.createElement("paragraph",new Node[]{text1});
   Node para2 = Element.createElement("paragraph",new Node[] {text2});
   Node para3 = Element.createElement("paragraph",new Node[]{text3});
   Node para4 = Element.createElement("paragraph",new Node[] {text4});
   Node page1 = Element.createElement("page",new Node[] {para1});
   Node page2 = Element.createElement("page",new Node[]{para2, para3});
   Node page3 = Element.createElement("page",new Node[] {para4});
   Node ch1   = Element.createElement("chapter",new Node[]{page1, page2});
   Node ch2   = Element.createElement("chapter",new Node[] {page3});
   Node book  = Element.createElement("book",new Node[] {ch1, ch2});

/*
<book>
   <chapter>            // ch1
      <page>            // page1
         <paragraph>    // para1
            Text1       // text1
         </paragraph>
     </page>
     <page>             // page2
         <paragraph>    // para2
            Text2       // text2
         </paragraph>
         <paragraph>    // para3
            Text3       // text3
         </paragraph>
     </page>
   </chapter>
   <chapter>            // ch2
      <page>            // page3
         <paragraph>    // para4
            Text4       // text4
         </paragraph>
     </page>
   </chapter>
</book>
*/

   public void testLookup() {
      ChildList children = null;
      try {
         children = XmlHome.lookup(book, "");

         assertTrue(children.size() == 2);
         assertEquals(children.get(0), ch1);
         assertEquals(children.get(1), ch2);

         children = XmlHome.lookup(book, "chapter");
         assertTrue(children.size() == 2);
         assertEquals(children.get(0), ch1);
         assertEquals(children.get(1), ch2);

         children = XmlHome.lookup(book, "*");
         assertTrue(children.size() == 2);
         assertEquals(children.get(0), ch1);
         assertEquals(children.get(1), ch2);

         children = XmlHome.lookup(book, "chapter[1]");
         assertTrue(children.size() == 1);
         assertEquals(children.get(0), ch1);

         children = XmlHome.lookup(book, "chapter[3]");
         assertTrue(children.size() == 0);

         children = XmlHome.lookup(book, "chapter/page");
         assertTrue(children.size() == 3);
         assertEquals(children.get(0), page1);
         assertEquals(children.get(1), page2);
         assertEquals(children.get(2), page3);

         children = XmlHome.lookup(book, "chapter/*");
         assertTrue(children.size() == 3);
         assertEquals(children.get(0), page1);
         assertEquals(children.get(1), page2);
         assertEquals(children.get(2), page3);

         children = XmlHome.lookup(book, "chapter/page[1]");
         assertTrue(children.size() == 2);
         assertEquals(children.get(0), page1);
         assertEquals(children.get(1), page3);

         children = XmlHome.lookup(book, "chapter/page[4]");
         assertTrue(children.size() == 0);

         children = XmlHome.lookup(book, "chapter/page/*");
         assertTrue(children.size() == 4);
         assertEquals(children.get(0), para1);
         assertEquals(children.get(1), para2);
         assertEquals(children.get(2), para3);
         assertEquals(children.get(3), para4);

         children = XmlHome.lookup(book, "chapter/page/paragraph[1]");

         assertTrue(children.size() == 3);
         assertEquals(children.get(0), para1);
         assertEquals(children.get(1), para2);
         assertEquals(children.get(2), para4);

         children = XmlHome.lookup(book, "chapter/page/paragraph[2]");

         assertTrue(children.size() == 1);
         assertEquals(children.get(0), para3);

         children = XmlHome.lookup(book, "chapter/page/paragraph[3]");

         assertTrue(children.size() == 0);
      }
      catch(XmlModificationException e){
         assertTrue("XmlModificationException caught: " + e.toString(), false);
      }
   }


   public void testRemove() {
      Node newNode = null;
      ChildList children = null;

      try {
         newNode = XmlHome.remove(para1, "", text1);

         children = newNode.getChildNodes();
         assertTrue(children.size() == 0);

         newNode = XmlHome.remove(book, "chapter", page1);

         children = newNode.getChildNodes();
         assertTrue(children.size() == 2);
         assertEquals( children.get(1), ch2);

         newNode = XmlHome.remove(book, "chapter[1]", page2);

         children = newNode.getChildNodes();
         children = ((Node)children.get(0)).getChildNodes();   // first chapter.
         assertTrue(children.size() == 1);
         assertEquals( children.get(0), page1);

         newNode = XmlHome.remove(book, "chapter[1]/page[2]/*", text2);

         children = newNode.getChildNodes();
         children = ((Node)children.get(0)).getChildNodes();   // first chapter.
         children = ((Node)children.get(1)).getChildNodes();   // second page.
         assertTrue(children.size() == 2);
         // first paragraph.
         ChildList child1 = ((Node)children.get(0)).getChildNodes();
         // text2 is removed from para2.
         assertTrue(child1.size() == 0);
         // second paragraph.
         ChildList child2 = ((Node)children.get(1)).getChildNodes();
         assertTrue(child2.size() == 1);
         assertEquals( child2.get(0), text3);
      }
      catch(Exception e) {
         assertTrue("Exception caught: " + e.toString(), false);
      }
   }


   public void testAddNode() {
      Node newNode = null;
      ChildList children = null;

      try {
         newNode = XmlHome.append(book, "chapter[2]/page", para3);

         children = newNode.getChildNodes();
         children = children.get(1).getChildNodes();   // second chapter.
         children = children.get(0).getChildNodes();   // first page.
         assertTrue(children.size() == 2);
         assertEquals(children.get(0), para4);
         assertEquals(children.get(1), para3);

         newNode = XmlHome.append(book, "chapter[1]/page[2]", para4);

         children = newNode.getChildNodes();
         children = children.get(0).getChildNodes();   // first chapter.
         children = children.get(1).getChildNodes();   // second page.
         assertTrue(children.size() == 3);
         assertEquals(children.get(0), para2);
         assertEquals(children.get(1), para3);
         assertEquals(children.get(2), para4);

         newNode = XmlHome.append(book, "chapter[3]", para4);

         children = newNode.getChildNodes();
         // Nothing is added, since we only have 2 chapters.
         assertTrue(children.size() == 2);
         assertEquals(children.get(0), ch1);
         assertEquals(children.get(1), ch2);

         newNode = XmlHome.append(book, "*/page/paragraph[2]", text3);

         children = newNode.getChildNodes();
         children = children.get(0).getChildNodes();   // first chapter.
         children = children.get(1).getChildNodes();   // second page.
         children = children.get(1).getChildNodes();   // second paragraph.
         assertTrue(children.size() == 2);
         assertEquals(children.get(0), text3);
         assertEquals(children.get(1), text3);
      }
      catch (Exception e){
         assertTrue("Exception caught: " + e.toString(), false);
      }
   }


   public void testInsertNodeBefore() {
      Node newNode = null;
      ChildList children = null;

      try{
         newNode = XmlHome.insertBefore(book, "chapter[1]", page2, page3);

         children = newNode.getChildNodes();
         children = ((Node)children.get(0)).getChildNodes(); // first chapter.
         assertTrue(children.size() == 3);
         assertEquals(children.get(0), page1);
         assertEquals(children.get(1), page3);
         assertEquals(children.get(2), page2);

         newNode = XmlHome.insertBefore(book, "chapter[2]/*/*",
                                              text4, text3);

         children = newNode.getChildNodes();
         children = ((Node)children.get(1)).getChildNodes(); // second chapter.
         children = ((Node)children.get(0)).getChildNodes(); // first page.
         children = ((Node)children.get(0)).getChildNodes(); // first paragraph.
         assertTrue(children.size() == 2);
         assertEquals(children.get(0), text3);
         assertEquals(children.get(1), text4);
      }
      catch(Exception e) {
         assertTrue("Exception caught: " + e.toString(), false);
      }
   }


   public void testReplaceNode() {
      Node newNode = null;
      ChildList children = null;
      try {
         newNode = XmlHome.replace(book, "chapter[1]", page2, page3);
         children = newNode.getChildNodes();
         children = children.get(0).getChildNodes();   // first chapter.
         assertTrue(children.size() == 2);
         assertEquals(children.get(0), page1);
         assertEquals(children.get(1), page3);
      }
      catch(Exception e){
         assertTrue("Exception caught: " + e.toString(), false);
      }
   }
}