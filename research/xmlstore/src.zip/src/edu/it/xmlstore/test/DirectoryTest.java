package edu.it.xmlstore.test;

import junit.framework.*;
import edu.it.xmlstore.*;
import edu.it.xmlstore.directory.*;
import edu.it.xmlstore.rpc.*;

public class DirectoryTest extends TestCase {

   public DirectoryTest(String name) {
      super(name);
   }

   public static Test suite() {
      TestSuite suite = new TestSuite(DirectoryTest.class);
      return suite;
   }

   public static void main(String[] args) {
      junit.textui.TestRunner.run(DirectoryTest.class);
   }

   public void testBindLookup() {
      try {
         Directory directory = new DirectoryImpl();

         ValueReference ref1  = ValueUtil.getTestValueReference(1);
         ValueReference ref2  = ValueUtil.getTestValueReference(2);
         ValueReference ref3  = ValueUtil.getTestValueReference(3);

         String name1 = "Ref1";
         String name2 = "Ref2";
         String unknownName = "Unknown";


         // bind a name and look it up
         try {
            directory.bind(name1, ref1);
            directory.bind(name2, ref2);
            assertEquals(ref1, directory.lookup(name1));
         }
         catch (NameAllreadyBoundException e) {
            assertTrue(false);
         }
         catch (NoSuchElementException e) {
            assertTrue(false);
         }

         // bind an already bound name -- we expect an exception
         try {
            directory.bind(name1, ref3);
            assertTrue(false);
         }
         catch (NameAllreadyBoundException e) {
            // all went well ...
         }

         // lookup unknown name -- we expect an exception
         try {
            directory.lookup(unknownName);
            assertTrue(false);
         }
         catch (NoSuchElementException e) {
            // all went well ...
         }
      }
      catch (RemoteException e) {
         assertTrue("RemoteException testing directory: " + e, false);
      }
   }

   public void testUnbind() {
      try {
         Directory directory = new DirectoryImpl();
         ValueReference ref1  = ValueUtil.getTestValueReference(1);
         String name = "name";

         try {
            directory.bind(name, ref1);
            assertEquals(ref1, directory.lookup(name));
         }
         catch (NameAllreadyBoundException e) {
            assertTrue(false);
         }
         catch (NoSuchElementException e) {
            assertTrue(false);
         }

         try {
            directory.unbind(name);
         }
         catch(NoSuchElementException e) {
            assertTrue(false);
         }

         try {
            directory.lookup(name);
            assertTrue(false);
         }
         catch(NoSuchElementException e) {
            // great ...
         }
      }
      catch (RemoteException e) {
         assertTrue("RemoteException testing directory: " + e, false);
      }
   }

   public void testUpdate() {
      try {
         Directory directory = new DirectoryImpl();

         ValueReference ref1  = ValueUtil.getTestValueReference(1);
         ValueReference ref2  = ValueUtil.getTestValueReference(2);
         ValueReference ref3  = ValueUtil.getTestValueReference(3);

         String name = "name";

         try {
            directory.bind(name, ref1);
         }
         catch(NameAllreadyBoundException e) {
            assertTrue(false);
         }

         // rebind with an unexpected value -- we expect an exception
         try {
            directory.update(name, ref2, ref3);
            assertTrue(false);
         }
         catch(ConcurrentAccessException e) {
            // great ...
         }
         catch(NoSuchElementException e) {
            assertTrue(false);
         }

         // rebind with an expected value
         try {
            directory.update(name, ref2, ref1);
            assertEquals(ref2, directory.lookup(name));
         }
         catch(ConcurrentAccessException e) {
            assertTrue(false);
         }
         catch(NoSuchElementException e) {
            assertTrue(false);
         }
      }
      catch (RemoteException e) {
         assertTrue("RemoteException testing directory: " + e, false);
      }
   }
}