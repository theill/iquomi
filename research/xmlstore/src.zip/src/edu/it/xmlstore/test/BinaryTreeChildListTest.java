package edu.it.xmlstore.test;

import junit.framework.*;
import java.io.*;
import edu.it.xmlstore.xml.*;
import edu.it.xmlstore.*;
import java.util.LinkedList;

public class BinaryTreeChildListTest extends TestCase {

   public BinaryTreeChildListTest(String name) {
      super(name);
   }

   public static Test suite() {
      TestSuite suite = new TestSuite(BinaryTreeChildListTest.class);
      return suite;
   }

   public static void main(String[] args) {
      junit.textui.TestRunner.run(BinaryTreeChildListTest.class);
   }

   public void testAppendGet() {
      Node elt0 = CharData.createCharData("0");
      Node elt1 = CharData.createCharData("1");
      Node elt2 = CharData.createCharData("2");
      Node elt3 = CharData.createCharData("3");

      ChildList cl = new BinaryTreeChildList(new Node[]{elt0, elt1});
      ChildList cl1 = cl.append(elt2);
      ChildList cl2 = cl1.append(elt3);

      assertTrue(cl.get(0) == elt0);
      assertTrue(cl.get(1) == elt1);

      assertTrue(cl1.get(0) == elt0);
      assertTrue(cl1.get(1) == elt1);
      assertTrue(cl1.get(2) == elt2);

      assertTrue(cl2.get(0) == elt0);
      assertTrue(cl2.get(1) == elt1);
      assertTrue(cl2.get(2) == elt2);
      assertTrue(cl2.get(3) == elt3);
   }

   public void testInsert() {
      Node elt0 = CharData.createCharData("0");
      Node elt1 = Element.createElement("1", new Node[]{});
      Node elt2 = Element.createElement("2", new Node[]{});
      Node elt3 = CharData.createCharData("3");
      Node elt4 = CharData.createCharData("4");
      Node elt5 = CharData.createCharData("5");

      ChildList cl = new BinaryTreeChildList(new Node[]{elt1, elt2, elt3, 
                                             elt5});
      ChildList cl1 = cl.insert(elt4, 3);
      ChildList cl2 = cl1.insert(elt0, 0);

      assertTrue("1:Size is wrong", cl.size() == 4);
      assertTrue(cl.get(0) == elt1);
      assertTrue(cl.get(1) == elt2);
      assertTrue(cl.get(2) == elt3);
      assertTrue(cl.get(3) == elt5);

      assertTrue("2:Size is wrong", cl1.size() == 5);
      assertTrue(cl1.get(0) == elt1);
      assertTrue(cl1.get(1) == elt2);
      assertTrue(cl1.get(2) == elt3);
      assertTrue(cl1.get(3) == elt4);
      assertTrue(cl1.get(4) == elt5);

      assertTrue("3:Size is wrong", cl2.size() == 6);
      assertTrue(cl2.get(0) == elt0);
      assertTrue(cl2.get(1) == elt1);
      assertTrue(cl2.get(2) == elt2);
      assertTrue(cl2.get(3) == elt3);
      assertTrue(cl2.get(4) == elt4);
      assertTrue(cl2.get(5) == elt5);
   }

   public void testConstructor() {
      Node elt0 = CharData.createCharData("0");
      Node elt1 = Element.createElement("1", new Node[]{});
      Node elt2 = Element.createElement("2", new Node[]{});
      Node elt3 = CharData.createCharData("3");
      Node elt4 = CharData.createCharData("4");
      Node elt5 = CharData.createCharData("5");
      Node elt6 = CharData.createCharData("6");
      Node elt7 = CharData.createCharData("7");
      Node elt8 = CharData.createCharData("8");

      ChildList cl = new BinaryTreeChildList(
             new Node[]{elt0, elt1, elt2, elt3, elt4, elt5, elt6, elt7, elt8});
   }

   public void testDelete() {
      Node elt0 = CharData.createCharData("0");
      Node elt1 = Element.createElement("1", new Node[]{});
      Node elt2 = Element.createElement("2", new Node[]{});
      Node elt3 = CharData.createCharData("3");
      Node elt4 = CharData.createCharData("4");
      Node elt5 = CharData.createCharData("5");
      Node elt6 = CharData.createCharData("6");

      ChildList cl = new BinaryTreeChildList(
                     new Node[]{elt0, elt1, elt2, elt3, elt4, elt5, elt6});

      ChildList cl1 = cl.delete(5);

      assertTrue(cl1.get(0) == elt0);
      assertTrue(cl1.get(1) == elt1);
      assertTrue(cl1.get(2) == elt2);
      assertTrue(cl1.get(3) == elt3);
      assertTrue(cl1.get(4) == elt4);
      assertTrue(cl1.get(5) == elt6);

      ChildList cl2 = cl1.delete(3);
      assertTrue(cl2.get(0) == elt0);
      assertTrue(cl2.get(1) == elt1);
      assertTrue(cl2.get(2) == elt2);
      assertTrue(cl2.get(3) == elt4);
      assertTrue(cl2.get(4) == elt6);

      ChildList cl3 = cl.delete(0);
      assertTrue(cl3.get(0) == elt1);
      assertTrue(cl3.get(1) == elt2);
      assertTrue(cl3.get(2) == elt3);
      assertTrue(cl3.get(3) == elt4);
      assertTrue(cl3.get(4) == elt5);
      assertTrue(cl3.get(5) == elt6);

      cl = new BinaryTreeChildList(
                              new Node[]{elt0, elt1, elt2, elt3, elt4, elt5});
      cl = cl.delete(5);
      
      assertTrue(cl.get(0) == elt0);
      assertTrue(cl.get(1) == elt1);
      assertTrue(cl.get(2) == elt2);
      assertTrue(cl.get(3) == elt3);
      assertTrue(cl.get(4) == elt4);
   }
}