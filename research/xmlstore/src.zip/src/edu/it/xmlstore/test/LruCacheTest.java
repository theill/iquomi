package edu.it.xmlstore.test;

import junit.framework.*;
import edu.it.xmlstore.storage.*;
import edu.it.xmlstore.chord.*;
import edu.it.xmlstore.ValueReference;

public class LruCacheTest extends TestCase {

   public LruCacheTest(String name) {
      super(name);
   }

   public static Test suite() {
      TestSuite suite = new TestSuite(LruCacheTest.class);
      return suite;
   }

   public static void main(String[] args) {
      junit.textui.TestRunner.run(LruCacheTest.class);
   }

   public void testPutContains() {
      Cache cache = new LruCache(3);

      byte[] val1 = {1, 15, 127};
      byte[] val2 = {2, 9, 127};
      byte[] val3 = {3, 8, 127};
      byte[] val4 = {4, 65, 127};

      ValueReference key1 = new ChordIdImpl(1);
      ValueReference key2 = new ChordIdImpl(2);
      ValueReference key3 = new ChordIdImpl(3);
      ValueReference key4 = new ChordIdImpl(4);

      // test basic functionality
      cache.put(val1, key1);
      assertTrue(cache.contains(key1));
      assertTrue(!cache.contains(key2));

      // test that size = 3
      cache.put(val2, key2);
      cache.put(val3, key3);
      assertTrue(cache.contains(key1));
      assertTrue(cache.contains(key2));
      assertTrue(cache.contains(key3));

      // test lru
      cache.put(val4, key4);
      assertTrue(!cache.contains(key1)); // key1 = lru
      assertTrue(cache.contains(key4));

   }

   public void testGet() {
      Cache cache = new LruCache(3);

      byte[] val1 = {1, 15, 127};
      byte[] val2 = {2, 9, 127};
      byte[] val3 = {3, 8, 127};
      byte[] val4 = {4, 65, 127};

      ValueReference key1 = new ChordIdImpl(1);
      ValueReference key2 = new ChordIdImpl(2);
      ValueReference key3 = new ChordIdImpl(3);
      ValueReference key4 = new ChordIdImpl(4);

      // test basic functionality
      cache.put(val1, key1);
      assertTrue(val1 == cache.get(key1));

      // test lru and refresh
      cache.put(val2, key2);
      cache.put(val3, key3);

      cache.get(key1); // make key1 the most recently used

      // insert val4 making val2 dissapear and key 1 stay
      cache.put(val4, key4);
      assertTrue(val1 == cache.get(key1));

      try {
         cache.get(key2); // key2 should be gone and an exception thrown
         assertTrue(false);
      } catch (RuntimeException e) {
         // Ok
      }
      assertTrue(val4 == cache.get(key4));
   }
}