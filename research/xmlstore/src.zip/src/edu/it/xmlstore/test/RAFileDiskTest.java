package edu.it.xmlstore.test;

import junit.framework.*;

import edu.it.xmlstore.storage.*;
import edu.it.xmlstore.XmlStoreServerImpl;
import edu.it.xmlstore.ValueReference;
import edu.it.xmlstore.ValueUtil;

import java.io.File;

public class RAFileDiskTest extends TestCase {

   public RAFileDiskTest(String name) {
      super(name);
   }

   public static Test suite() {
      TestSuite suite = new TestSuite(RAFileDiskTest.class);
      return suite;
   }

   public static void main(String[] args) {
      junit.textui.TestRunner.run(RAFileDiskTest.class);
   }

   public void testSave() {
      try {
         Disk disk = new RAFileDisk(XmlStoreServerImpl.SAVE_DIRECTORY + File.separatorChar + "raftest");

         String value1  = "SAVEFirst value";
         String value1a = "SAVEFirst value";
         String value2  = "SAVESecond value";

         ValueReference ref1  = ValueUtil.getValueReference(value1.getBytes());
         ValueReference ref2  = ValueUtil.getValueReference(value2.getBytes());
         ValueReference ref1a = ValueUtil.getValueReference(value1a.getBytes());

         disk.save(value1.getBytes(), ref1);
         disk.save(value2.getBytes(), ref2);
         disk.save(value1a.getBytes(), ref1a);

         assertTrue(ref1.equals(ref1a));
         assertTrue(!ref2.equals(ref1));
      } catch (java.io.IOException e) {
         assertTrue("IOException", false);
      }
   }

   public void testLoad() {
      try {
         Disk disk = new RAFileDisk(XmlStoreServerImpl.SAVE_DIRECTORY + File.separatorChar + "raftest");

         String value1  = "LOADFirst value";
         String value1a = "LOADFirst value";
         String value2  = "LOADSecond value";

         ValueReference ref1  = ValueUtil.getValueReference(value1.getBytes());
         ValueReference ref2  = ValueUtil.getValueReference(value2.getBytes());
         ValueReference ref1a = ValueUtil.getValueReference(value1a.getBytes());

         disk.save(value1.getBytes(), ref1);
         disk.save(value2.getBytes(), ref2);
         disk.save(value1a.getBytes(), ref1a);

         String lvalue1  = new String( disk.load(ref1) );
         String lvalue1a = new String( disk.load(ref1a) );
         String lvalue2  = new String( disk.load(ref2) );

         assertTrue(value1.equals(lvalue1));
         assertTrue(value1.equals(lvalue1a));
         assertTrue(!value2.equals(lvalue1));
      } catch (java.io.IOException e) {
         assertTrue("IOException", false);
      }
   }

   public void testDelete() {
      Disk disk = null;
      String value1  = "DELFirst value";
      String value1a = "DELFirst value";
      String value2  = "DELSecond value";
      
      ValueReference ref1  = ValueUtil.getValueReference(value1.getBytes());
      ValueReference ref2  = ValueUtil.getValueReference(value2.getBytes());
      ValueReference ref1a = ValueUtil.getValueReference(value1a.getBytes());


      try {
	 disk = new RAFileDisk(XmlStoreServerImpl.SAVE_DIRECTORY + File.separatorChar + "raftest");

         disk.save(value1.getBytes(), ref1);
         disk.save(value2.getBytes(), ref2);
         disk.save(value1a.getBytes(), ref1a);

         disk.delete(ref1);
      } catch (java.io.IOException e) {
         assertTrue("IOException", false);
      }

      // make sure ref1 is not in the store
      try {
         disk.load(ref1);
         assertTrue(false);
      } catch(java.io.IOException e) {
         // everything works
      }
   }

   public void testReload() {
      RAFileDisk disk = null;
      String value1  = "RELOADFirst value";
      String value1a = "RELOADFirst value";
      String value2  = "RELOADSecond value";
      
      ValueReference ref1  = ValueUtil.getValueReference(value1.getBytes());
      ValueReference ref2  = ValueUtil.getValueReference(value2.getBytes());
      ValueReference ref1a = ValueUtil.getValueReference(value1a.getBytes());


      try {
	 // Save some values and close the disk
	 disk = new RAFileDisk(XmlStoreServerImpl.SAVE_DIRECTORY + File.separatorChar + "raftest");

         disk.save(value1.getBytes(), ref1);
         disk.save(value2.getBytes(), ref2);
         disk.save(value1a.getBytes(), ref1a);
	 disk.close();

	 // Reopen disk and make sure values are still there
	 disk = new RAFileDisk(XmlStoreServerImpl.SAVE_DIRECTORY + File.separatorChar + "raftest");
         String lvalue1  = new String( disk.load(ref1) );
         String lvalue1a = new String( disk.load(ref1a) );
         String lvalue2  = new String( disk.load(ref2) );
         assertTrue(value1.equals(lvalue1));
         assertTrue(value1.equals(lvalue1a));
         assertTrue(!value2.equals(lvalue1));	 

      } catch (java.io.IOException e) {
         assertTrue("IOException: " + e.getMessage(), false);
      }
   }
}
