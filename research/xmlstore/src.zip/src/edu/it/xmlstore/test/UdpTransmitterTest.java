package edu.it.xmlstore.test;

import junit.framework.*;

import edu.it.xmlstore.rpc.udp.*;
import edu.it.xmlstore.rpc.*;
import edu.it.xmlstore.chord.*;
import edu.it.xmlstore.*;

import java.net.DatagramSocket;
import java.net.DatagramPacket;
import java.net.SocketAddress;
import java.net.InetSocketAddress;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Arrays;

public class UdpTransmitterTest extends TestCase {

   // Receives messages and responds in various erroneous ways
   private TestReceiver testReceiver; 

   // Socket for sending and receiving.
   private static final int RECEIVER_PORT = 10890;
   private static final InetSocketAddress RECEIVER_ADDRESS = new InetSocketAddress(RECEIVER_PORT);   
   private DatagramSocket socket = null;

   // Initialize transmitter.
   private static final int TRANSMITTER_PORT = 10887;
   private static UdpTransmitter udpTransmitter = null;
   
   // Initialize dispatcher.
   ValueReference id21 = new ChordIdImpl(21);
   FakeXmlStoreServer s21 = new FakeXmlStoreServer(id21, TRANSMITTER_PORT);
   MessageDispatcher dispatcher = new XmlStoreMessageDispatcher(s21);

   public UdpTransmitterTest(String name) {
      super(name);

      // Initialize UdpTransmitter
      if (udpTransmitter == null)
	 try {
	    udpTransmitter = new UdpTransmitter(TRANSMITTER_PORT, dispatcher);
	 } 
	 catch (IOException e) {
	    e.printStackTrace(System.out);
	    throw new RuntimeException("Error in UdpTransmitterTest: " + e);
	 }
   }

   public static Test suite() {
      TestSuite suite = new TestSuite(UdpTransmitterTest.class);
      return suite;
   }

   public static void main(String[] args) {
      junit.textui.TestRunner.run(UdpTransmitterTest.class);
   }

   public void setUp() {
      // Initialize socket
      try {
	 socket = new DatagramSocket(RECEIVER_ADDRESS);    
	 socket.setReceiveBufferSize(MessageFragment.MAX_DATAGRAM_SIZE);
      } catch (IOException e) {
	 e.printStackTrace(System.out);
	 throw new RuntimeException("Error in UdpTransmitterTest: " + e);
      }

      // Start listening for messages using a TestReceiver.
      testReceiver = new TestReceiver();
      testReceiver.start();
   }

   public void tearDown() {
      testReceiver.interrupt();
      socket.close();
   }

   // Nice random message content
   private static byte[] randomBytes(int length) {
      byte[] result = new byte[length];
      for (int i = 0; i < result.length; i++)
	 result[i] = (byte) (Math.random() * Byte.MAX_VALUE);
      return result;
   }



   // Test that we can retransmit part of a message
   // First package will be asked for again and stored in TestReceiver.receivedFragment
   private static final int TEST_REQUEST_FRAGMENT = 5;

   public void testRequestFragment() {
      // Create message spanning three fragments
      byte[] messageContent = randomBytes(MessageFragment.MAX_MESSAGE_SIZE * 2 + 100);
      OutgoingMessage message = new OutgoingUdpMessage(TEST_REQUEST_FRAGMENT, messageContent.length, MessageFragment.TYPE_REQUEST);
      message.putByteArray(messageContent);
      
      // ...send it, and check that first fragment was retransmitted
      try {
	 udpTransmitter.send(message, RECEIVER_ADDRESS);
	 assertTrue(testReceiver.receivedFragment.getId() == TEST_REQUEST_FRAGMENT);
	 assertTrue(testReceiver.receivedFragment.getNumber() == 1);
	 assertTrue(testReceiver.receivedFragment.getTotal() == 3);
	 assertTrue(testReceiver.receivedFragment.getType() == MessageFragment.TYPE_REQUEST);
      }
      catch (RemoteException e) {
	 assertTrue("Exception in test: " + e, false);
      }
   }


   // Tests sending a message without problems.
   private static final int TEST_SEND = 1;

   public void testSend() {
      try { 
	 // Create message... 
	 byte[] messageContent = new byte[]{0, 1, 2, 3, 4, 5, 6, 7};
	 OutgoingMessage message = new OutgoingUdpMessage(TEST_SEND, messageContent.length, MessageFragment.TYPE_REQUEST);
	 message.putByteArray(messageContent);
	 // ... and send it
	 IncomingMessage reply = udpTransmitter.send(message, RECEIVER_ADDRESS);
 
	 // Check that message arrived and reply is correct. 
	 assertTrue(Arrays.equals(messageContent, 
				  testReceiver.receivedMessage.getByteArray(messageContent.length)));
	 assertTrue(Arrays.equals(reply.getByteArray(testReceiver.response.length), 
				  testReceiver.response));
      } catch (RemoteException e) {
	 e.printStackTrace(System.out);
	 assertTrue("Error in UdpTransmitterTest: " + e, false);
      }
   }

   // Test that we can handle only receiving parts of a reply
   // Reply is sent, but not until *after* a retransmission request 
   private static final int TEST_SEND_FRAGMENTED_REPLY = 3;
   
   public void testSendFragmentedReply() {
      // Create message... 
      byte[] messageContent = new String("Is there anybody out there?").getBytes();
      OutgoingMessage message = new OutgoingUdpMessage(TEST_SEND_FRAGMENTED_REPLY, 
						       messageContent.length, 
						       MessageFragment.TYPE_REQUEST);
      message.putByteArray(messageContent);
      
      // ...send it, and check that we got the correct content in all fragments
      try {
	 IncomingMessage reply = udpTransmitter.send(message, RECEIVER_ADDRESS);	 	 
	 assertTrue(Arrays.equals(reply.getByteArray(testReceiver.response.length), testReceiver.response));
      }
      catch (RemoteException e) {
	 assertTrue("Exception in test: " + e, false);
      }
   }
   
   // Status running is sent to UDPTransmitter to avoid timing out
   private static final int TEST_STATUS_RUNNING = 6;

   public void testStatusRunning() {
      // Create message
      byte[] messageContent = new String("The Running Man").getBytes();
      OutgoingMessage message = new OutgoingUdpMessage(TEST_STATUS_RUNNING, messageContent.length, MessageFragment.TYPE_REQUEST);
      message.putByteArray(messageContent);
      
      // ...send it, and check that first fragment was retransmitted
      try {
	 IncomingMessage reply = udpTransmitter.send(message, RECEIVER_ADDRESS);
	 assertTrue(Arrays.equals(reply.getByteArray(testReceiver.response.length), testReceiver.response));
      }
      catch (RemoteException e) {
	 assertTrue("Exception in test: " + e, false);
      }
   }

   // Tests sending a message with no reply at all
   private static final int TEST_SEND_NO_REPLY = 2;

   public void testSendNoReply() {
      // Create message... 
      byte[] messageContent = new String("Is there anybody out there?").getBytes();
      OutgoingMessage message = new OutgoingUdpMessage(TEST_SEND_NO_REPLY, messageContent.length, MessageFragment.TYPE_REQUEST);
      message.putByteArray(messageContent);
      
      // ...send it, but as we do not send any reply we expect an exception
      try { 
	 IncomingMessage reply = udpTransmitter.send(message, RECEIVER_ADDRESS);
	 assertTrue("Expected RemoteException", false);
      } catch (RemoteException e) {
	 // All ok
      }
   }


   // Class for receiving messages and replying in various ways
   private class TestReceiver extends Thread {

      // Fields containing the sender, message and fragment last received and response given
      public byte[] response;
      public IncomingUdpMessage receivedMessage;      
      public MessageFragment receivedFragment;
      public SocketAddress sender;


      public TestReceiver() {}

      public void run() {
	 try {	      
	    doTest();   
	 }
	 catch(IOException e) {
	    throw new RuntimeException("Error in TestReceiver: " + e);
	 }
      }
      

      private void doTest() throws IOException {
	 // All tests start with something being received from transmitter
	 // Which behaviour is performed is determined from the id of the message.
	 receivedMessage = receive();
	 OutgoingUdpMessage reply;
	 
	 switch(receivedMessage.getId()) {

	    // Send correct reply
	 case TEST_SEND:
	    response = new byte[]{7, 6, 5, 4, 3, 2, 1, 0};
	    reply = new OutgoingUdpMessage(receivedMessage.getId(), response.length, MessageFragment.TYPE_REPLY);
	    reply.putByteArray(response);
	    send(reply.iterator().next());
	    break;

	    // Don't send any reply
	 case TEST_SEND_NO_REPLY:
	    // Do not respond!
	    break;

	    // Send partial reply 
	    // wait for retransmission request
	    // retransmit
	 case TEST_SEND_FRAGMENTED_REPLY:
	    // Create reply spanning three fragments but only transmit two...
	    reply = new OutgoingUdpMessage(receivedMessage.getId(), MessageFragment.MAX_MESSAGE_SIZE * 3, MessageFragment.TYPE_REPLY);
	    response = randomBytes(MessageFragment.MAX_MESSAGE_SIZE * 3);
	    reply.putByteArray(response);
	    FragmentList.Iterator fragments = reply.iterator();
	    send(fragments.next());
	    MessageFragment missing = fragments.next();
	    send(fragments.next());

	    // receive request for retransmission
	    do {
	       receivedFragment = receiveFragment();
	    } while (receivedFragment.getType() != MessageFragment.TYPE_RETRANSMIT_REPLY);
	    send(missing);	    
	    break;

	    // Ask for retransmission of one package in request
	 case TEST_REQUEST_FRAGMENT:    
	    // Request first packet once again
	    MessageFragment reqFrag = new MessageFragment(receivedMessage.getId(), 
							  NetworkUtil.INT_LENGTH, 
							  MessageFragment.TYPE_RETRANSMIT_REQUEST,
							  (short)1,
							  (short)1);
	    // Store the package number to be retransmitted
	    reqFrag.putInt(0, 1);
	    send(reqFrag);
	    // Receive fragment 1 again
	    MessageFragment again = receiveFragment();
	 
	    // Send standard response
	    response = new byte[]{7, 6, 5, 4, 3, 2, 1, 0};
	    reply = new OutgoingUdpMessage(receivedMessage.getId(), response.length, MessageFragment.TYPE_REPLY);
	    reply.putByteArray(response);
	    send(reply.iterator().next());	

	    break;

	    // Send status=running to transmitter to avoid time out
	 case TEST_STATUS_RUNNING:
	    // Message: Status=running 
	    MessageFragment running = new MessageFragment(receivedMessage.getId(), 
							  1, 
							  MessageFragment.TYPE_STATUS,
							  (short)1,
							  (short)1);
	    running.putByte(0, MessageFragment.STATUS_RUNNING);
	    
	    // receive request for status twice and acknowledge that we are running
	    receivedMessage = receive();    
	    
	    if (receivedMessage.iterator().next().getType() == MessageFragment.TYPE_STATUS_REQUEST)
	       send(running);
	    
	    receivedMessage = receive();
	    if (receivedMessage.iterator().next().getType() == MessageFragment.TYPE_STATUS_REQUEST)
	       send(running);
	    
	    // Send standard response
	    response = new byte[]{7, 6, 5, 4, 3, 2, 1, 0};
	    reply = new OutgoingUdpMessage(receivedMessage.getId(), response.length, MessageFragment.TYPE_REPLY);
	    reply.putByteArray(response);
	    send(reply.iterator().next());	 
	    break;
	 default:
	    throw new RuntimeException("Error in TestReceiver.doTest(), wrong testcase: " + receivedMessage.getId());
	 }	 
      }

      private MessageFragment receiveFragment() throws IOException {
	 // Read bytes from datagram socket	 
	 byte[] buffer = new byte[MessageFragment.MAX_DATAGRAM_SIZE];
	 DatagramPacket incomingPacket = new DatagramPacket(buffer, MessageFragment.MAX_DATAGRAM_SIZE);
	 socket.receive(incomingPacket);

	 //System.out.println( "TEST: Received packet from " + incomingPacket.getSocketAddress() );
	 // Note sender and return received fragment
	 sender = incomingPacket.getSocketAddress();
	 receivedFragment = new MessageFragment(buffer);
	 return receivedFragment;
      }

      private IncomingUdpMessage receive() throws IOException {
	 // Read first fragment and determine whether more are coming
	 IncomingUdpMessage message = null;
	 MessageFragment fragment = null;

	 do {	    
	    fragment = receiveFragment();
	    if (message == null)
	       message = new IncomingUdpMessage(fragment.getId());
	    message.addFragment(fragment);
	 } while (!message.isComplete());
	 
	 return message;
      }
      
      private void send(MessageFragment fragment) throws IOException {
	 socket.send(new DatagramPacket(fragment.asArray(), 
					fragment.asArray().length, 
					sender));
      }
   }
}
