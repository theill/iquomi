package edu.it.xmlstore.test;

import junit.framework.*;
import java.io.*;
import java.util.Arrays;
import edu.it.xmlstore.chord.*;
import edu.it.xmlstore.storage.*;
import edu.it.xmlstore.xml.*;
import edu.it.xmlstore.*;

public class XmlStoreServerTest extends TestCase {

   public XmlStoreServerTest(String name) {
      super(name);
   }

   public static Test suite() {
      TestSuite suite = new TestSuite(XmlStoreServerTest.class);
      return suite;
   }

   public static void main(String[] args) {
      junit.textui.TestRunner.run(XmlStoreServerTest.class);
   }

    // Test ids used in most tests
   ValueReference id0 = new ChordIdImpl(0);
   ValueReference id1 = new ChordIdImpl(1);
   ValueReference id2 = new ChordIdImpl(2);
   ValueReference id3 = new ChordIdImpl(3);
   ValueReference id4 = new ChordIdImpl(4);
   ValueReference id5 = new ChordIdImpl(5);
   ValueReference id6 = new ChordIdImpl(6);
   ValueReference id7 = new ChordIdImpl(7);
   ValueReference id70 = new ChordIdImpl(70);
   ValueReference id80 = new ChordIdImpl(80);
   ValueReference id90 = new ChordIdImpl(90);
   ValueReference id71 = new ChordIdImpl(71);
   ValueReference id81 = new ChordIdImpl(81);
   ValueReference id91 = new ChordIdImpl(91);

   public void testLeave() {
      try {
         // Create test servers
         XmlStoreServerImpl s70 = new XmlStoreServerImpl(id70);
         XmlStoreServerImpl s80 = new XmlStoreServerImpl(id80);
         XmlStoreServerImpl s90 = new XmlStoreServerImpl(id90);

         // Set up CHORD ring
         s70.join(null);
         s80.join(s70);
         s90.join(s70);

         // Insert values
         String val1 = "Nummer 1";
         String val2 = "Nummer 2";
         String val85 = "Nummer 85";

         ValueReference ref1 = ValueUtil.getTestValueReference(1);
         ValueReference ref2 = ValueUtil.getTestValueReference(2);
         ValueReference ref85 = ValueUtil.getTestValueReference(85);

         s70.saveValue(val1.getBytes(), ref1);
         s70.saveValue(val2.getBytes(), ref2);
         s70.saveValue(val85.getBytes(), ref85);

         // leaving...
         s70.leave();

         // Testing...
         assertTrue( s80.containsKeyOnDisk(ref1) );
         assertTrue( s80.containsKeyOnDisk(ref2) );
         assertTrue( s90.containsKeyOnDisk(ref85) );

         // Leaving..
         s80.leave();

         // Testing...
         assertTrue( s90.containsKeyOnDisk(ref1) );
         assertTrue( s90.containsKeyOnDisk(ref2) );
         assertTrue( s90.containsKeyOnDisk(ref85) );

         // Leaving..
         s90.leave();
      }
      catch (Exception e) {
         assert false : "Exception checking testLeave: " + e;
      }
   }

   public void testLoadValue() {
      try {
         // Create test servers
         XmlStoreServerImpl s0 = new XmlStoreServerImpl(id0);
         XmlStoreServerImpl s1 = new XmlStoreServerImpl(id1);
         XmlStoreServerImpl s3 = new XmlStoreServerImpl(id3);
         XmlStoreServerImpl s6 = new XmlStoreServerImpl(id6);
         XmlStoreServerImpl s70 = new XmlStoreServerImpl(id70);
         XmlStoreServerImpl s80 = new XmlStoreServerImpl(id80);
         XmlStoreServerImpl s90 = new XmlStoreServerImpl(id90);

         // Set up CHORD ring
         s0.join(null);
         s1.join(s0);
         s3.join(s1);
         s6.join(s3);
         s70.join(s3);
         s80.join(s3);
         s90.join(s3);

         // Insert values
         String val1 = "Nummer 1";
         String val2 = "Nummer 2";
         String val85 = "Nummer 85";

         ValueReference ref1 = ValueUtil.getTestValueReference(1);
         ValueReference ref2 = ValueUtil.getTestValueReference(2);
         ValueReference ref85 = ValueUtil.getTestValueReference(85);


         s0.saveValue(val1.getBytes(), ref1);
         s0.saveValue(val2.getBytes(), ref2);
         s0.saveValue(val85.getBytes(), ref85);

         byte[] result1 = null;
         byte[] result2 = null;
         byte[] result85 = null;

         result1 = s3.loadValue(ref1);
         result2 = s6.loadValue(ref2);
         result85 = s1.loadValue(ref85);

         // Testing
         assertTrue( Arrays.equals(result1, val1.getBytes()) );
         assertTrue( Arrays.equals(result2, val2.getBytes()) );
         assertTrue( Arrays.equals(result85, val85.getBytes()) );

	 // remember to leave properly
         s0.leave();
         s1.leave();
         s3.leave();
         s6.leave();
         s70.leave();
         s80.leave();
         s90.leave();

      }
      catch (Exception e) {
         assert false : "Exception checking testLoadValuer: " + e;
      }
   }

   public void testSaveValue() {
      try {
         // Create test servers
         XmlStoreServerImpl s0 = new XmlStoreServerImpl(id0);
         XmlStoreServerImpl s1 = new XmlStoreServerImpl(id1);
         XmlStoreServerImpl s3 = new XmlStoreServerImpl(id3);
         XmlStoreServerImpl s6 = new XmlStoreServerImpl(id6);
         XmlStoreServerImpl s70 = new XmlStoreServerImpl(id70);
         XmlStoreServerImpl s80 = new XmlStoreServerImpl(id80);
         XmlStoreServerImpl s90 = new XmlStoreServerImpl(id90);

         // Set up CHORD ring
         s0.join(null);
         s1.join(s0);
         s3.join(s1);
         s6.join(s3);
         s70.join(s3);
         s80.join(s3);
         s90.join(s3);

         // Insert values
         String val65 = "Nummer 65";
         String val72 = "Nummer 72";
         String val84 = "Nummer 84";

         ValueReference ref65 = ValueUtil.getTestValueReference(65);
         ValueReference ref72 = ValueUtil.getTestValueReference(72);
         ValueReference ref84 = ValueUtil.getTestValueReference(84);


         s0.saveValue(val65.getBytes(), ref65);
         s0.saveValue(val72.getBytes(), ref72);
         s0.saveValue(val84.getBytes(), ref84);

         // Testing
         assertTrue( s70.containsKeyOnDisk(ref65) );
         assertTrue( s80.containsKeyOnDisk(ref72) );
         assertTrue( s90.containsKeyOnDisk(ref84) );

	 // remember to leave properly
         s0.leave();
         s1.leave();
         s3.leave();
         s6.leave();
         s70.leave();
         s80.leave();
         s90.leave();
      }
      catch (Exception e) {
         assert false : "Exception checking testSaveValue: " + e;
      }
   }

   public void testSaveLoad() {
      try {
         // Simple XML document
         Node text1 = CharData.createCharData("Text1");
         Node text2 = CharData.createCharData("Text2");
	 Node text3 = CharData.createCharData("Text3");
	 Node text4 = CharData.createCharData("Text4");
         Node para1 = Element.createElement("paragraph", new Node[]{text1});
         Node para2 = Element.createElement("paragraph", new Node[] {text2});
         Node para3 = Element.createElement("paragraph", new Node[]{text3});
         Node para4 = Element.createElement("paragraph", new Node[] {text4});
         Node page1 = Element.createElement("page", new Node[] {para1});
         Node page2 = Element.createElement("page", new Node[]{para2, para3});
         Node page3 = Element.createElement("page", new Node[] {para4});
         Node ch1   = Element.createElement("chapter", new Node[]
                                            {page1, page2});
         Node ch2   = Element.createElement("chapter", new Node[] {page3});
         Element book  = Element.createElement("book", new Node[] {ch1, ch2});

         XmlStoreServer s0 = new XmlStoreServerImpl(id0);
         XmlStoreServer s1 = new XmlStoreServerImpl(id1);
         XmlStoreServer s3 = new XmlStoreServerImpl(id3);
         XmlStoreServer s6 = new XmlStoreServerImpl(id6);
         XmlStoreServer s70 = new XmlStoreServerImpl(id70);
         XmlStoreServer s80 = new XmlStoreServerImpl(id80);
         XmlStoreServer s90 = new XmlStoreServerImpl(id90);

         // Set up CHORD ring
         s0.join(null);
         s1.join(s0);
         s3.join(s1);
         s6.join(s3);
         s70.join(s3);
         s80.join(s3);
         s90.join(s3);

         // save document, load it and make sure it's the same.
         ValueReference ref = s3.save(book);
         Node result = s3.load(ref);

         assertTrue(result.equals(book));
         Node firstChild = (Node)result.getChildNodes().get(0);
         assertTrue(firstChild.equals(ch1));

	 // remember to leave properly
         s0.leave();
         s1.leave();
         s3.leave();
         s6.leave();
         s70.leave();
         s80.leave();
         s90.leave();
      }
      catch (Exception e) {
         e.printStackTrace();
         assert false : "Exception checking testSaveLoad: " + e;
      }
   }


   public void testMoveKeys() {
      try {
         // Create test servers
         XmlStoreServerImpl s71 = new XmlStoreServerImpl(id71);
         XmlStoreServerImpl s81 = new XmlStoreServerImpl(id81);
         XmlStoreServerImpl s91 = new XmlStoreServerImpl(id91);

         // Set up CHORD ring
         s71.join(null);

         // Insert values
         String val66 = "Nummer 66";
         String val73 = "Nummer 73";
         String val85 = "Nummer 85";

         ValueReference ref66 = ValueUtil.getTestValueReference(66);
         ValueReference ref73 = ValueUtil.getTestValueReference(73);
         ValueReference ref85 = ValueUtil.getTestValueReference(85);

         s71.saveValue(val66.getBytes(), ref66);
         s71.saveValue(val73.getBytes(), ref73);
         s71.saveValue(val85.getBytes(), ref85);

         assertTrue( s71.containsKeyOnDisk(ref66) );
         assertTrue( s71.containsKeyOnDisk(ref73) );
         assertTrue( s71.containsKeyOnDisk(ref85) );

         s81.join(s71);

         assertTrue( s71.containsKeyOnDisk(ref66) );
         assertTrue( s81.containsKeyOnDisk(ref73) );
         assertTrue( s71.containsKeyOnDisk(ref85) );

         s91.join(s71);

         assertTrue( s71.containsKeyOnDisk(ref66) );
         assertTrue( s81.containsKeyOnDisk(ref73) );
         assertTrue( s91.containsKeyOnDisk(ref85) );

	 // remember to leave properly
	 s71.leave();
	 s81.leave();
	 s91.leave();
      }
      catch (Exception e) {
         assert false : "Exception checking testMoveKeys: " + e;
      }
   }


   /*
   public void testCache() {
      try {
         // Create test servers
         XmlStoreServerImpl s0 = new XmlStoreServerImpl(id0);
         XmlStoreServerImpl s1 = new XmlStoreServerImpl(id1);
         XmlStoreServerImpl s3 = new XmlStoreServerImpl(id3);
         XmlStoreServerImpl s6 = new XmlStoreServerImpl(id6);
         XmlStoreServerImpl s70 = new XmlStoreServerImpl(id70);
         XmlStoreServerImpl s80 = new XmlStoreServerImpl(id80);
         XmlStoreServerImpl s90 = new XmlStoreServerImpl(id90);

         // Set up CHORD ring
         s0.join(null);
         s1.join(s0);
         s3.join(s1);
         s6.join(s3);
         s70.join(s3);
         s80.join(s3);
         s90.join(s3);

         // Insert values
         String val65 = "Nummer 65";
         String val72 = "Nummer 72";
         String val84 = "Nummer 84";

         ValueReference ref65 = ValueUtil.getTestValueReference(65);
         ValueReference ref72 = ValueUtil.getTestValueReference(72);
         ValueReference ref84 = ValueUtil.getTestValueReference(84);

         s0.saveValue(val65.getBytes(), ref65);
         s0.saveValue(val72.getBytes(), ref72);
         s0.saveValue(val84.getBytes(), ref84);

         byte[] result65 = s0.loadValue(ref65);
         byte[] result72 = s0.loadValue(ref72);
         byte[] result84 = s0.loadValue(ref84);

         // Testing
         assertTrue(s6.containsKeyCached(ref65));
         assertTrue(s70.containsKeyCached(ref72));
         assertTrue(s80.containsKeyCached(ref84));
         assertTrue(s70.containsKeyCached(ref72));
      }
      catch (Exception e) {
         assert false : "Exception checking testCache: " + e;
      }
   }
   */
}
