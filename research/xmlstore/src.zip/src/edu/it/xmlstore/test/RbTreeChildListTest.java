package edu.it.xmlstore.test;

import junit.framework.*;
import edu.it.xmlstore.xml.*;
import edu.it.xmlstore.*;

import java.io.*;
import java.util.LinkedList;
import java.util.Random;

public class RbTreeChildListTest extends TestCase {

   public RbTreeChildListTest(String name) {
      super(name);
   }

   public static Test suite() {
      TestSuite suite = new TestSuite(RbTreeChildListTest.class);
      return suite;
   }

   public static void main(String[] args) {
      junit.textui.TestRunner.run(RbTreeChildListTest.class);
   }

   public void testAppendGet() {
      Node elt1 = Element.createElement("1", new Node[]{});
      Node elt2 = Element.createElement("2", new Node[]{});
      Node elt3 = CharData.createCharData("3");
      Node elt4 = CharData.createCharData("4");

      ChildList cl = new RbTreeChildList(new Node[]{elt1, elt2});
      ChildList cl1 = cl.append(elt3);
      ChildList cl2 = cl1.append(elt4);

      assertTrue(cl.get(0) == elt1);
      assertTrue(cl.get(1) == elt2);

      assertTrue(cl1.get(0) == elt1);
      assertTrue(cl1.get(1) == elt2);
      assertTrue(cl1.get(2) == elt3);

      assertTrue(cl2.get(0) == elt1);
      assertTrue(cl2.get(1) == elt2);
      assertTrue(cl2.get(2) == elt3);
      assertTrue(cl2.get(3) == elt4);
   }

   public void testBalanced() {
      ChildList cl = new RbTreeChildList(new Node[]
                         {CharData.createCharData("0")});
      for (int i = 1; i <= 121; i++)
         cl = cl.append(CharData.createCharData(Integer.toString(i)));
      assertTrue(((RbTreeChildList)cl).rbcheck());
   }

   public void testInsert() {
      Node elt0 = CharData.createCharData("0");
      Node elt1 = Element.createElement("1", new Node[]{});
      Node elt2 = Element.createElement("2", new Node[]{});
      Node elt3 = CharData.createCharData("3");
      Node elt4 = CharData.createCharData("4");
      Node elt5 = CharData.createCharData("5");
      Node elt6 = CharData.createCharData("6");

      Node elt0_5 = CharData.createCharData("0.5");
      Node elt4_5 = CharData.createCharData("4.5");

      ChildList cl = new RbTreeChildList(
                     new Node[]{elt0, elt1, elt2, elt3, elt4, elt5, elt6});


      ChildList cl1 = cl.insert(elt0_5, 1);
      ChildList cl2 = cl1.insert(elt4_5, 6);

      assertTrue("Size", cl1.size() == 8);
      assertTrue(((RbTreeChildList)cl1).rbcheck());
      assertTrue("0", cl1.get(0) == elt0);
      assertTrue("1", cl1.get(1) == elt0_5);
      assertTrue("2", cl1.get(2) == elt1);
      assertTrue("3", cl1.get(3) == elt2);
      assertTrue("4", cl1.get(4) == elt3);
      assertTrue("5", cl1.get(5) == elt4);
      assertTrue("6", cl1.get(6) == elt5);
      assertTrue("7", cl1.get(7) == elt6);

      assertTrue("Size", cl2.size() == 9);
      assertTrue("0", cl2.get(0) == elt0);
      assertTrue("1", cl2.get(1) == elt0_5);
      assertTrue("2", cl2.get(2) == elt1);
      assertTrue("3", cl2.get(3) == elt2);
      assertTrue("4", cl2.get(4) == elt3);
      assertTrue("5", cl2.get(5) == elt4);
      assertTrue("6", cl2.get(6) == elt4_5);
      assertTrue("7", cl2.get(7) == elt5);
      assertTrue("8", cl2.get(8) == elt6);
      assertTrue(((RbTreeChildList)cl2).rbcheck());

      cl = new RbTreeChildList(new Node[]{elt0});
      Random rand = new Random(7913);
      for (int i = 1; i <= 1024; i++) {
         int pos = rand.nextInt(cl.size());
         cl = cl.insert(CharData.createCharData(Integer.toString(pos)), pos);
         assertTrue(((RbTreeChildList)cl).rbcheck());
      }
   }

   public void testDelete() {
      Node elt0 = CharData.createCharData("0");
      Node elt1 = Element.createElement("1", new Node[]{});
      Node elt2 = Element.createElement("2", new Node[]{});
      Node elt3 = CharData.createCharData("3");
      Node elt4 = CharData.createCharData("4");
      Node elt5 = CharData.createCharData("5");
      Node elt6 = CharData.createCharData("6");

      ChildList cl = new RbTreeChildList(
                     new Node[]{elt0, elt1, elt2, elt3, elt4, elt5, elt6});

      ChildList cl1 = cl.delete(5);

      assertTrue(cl1.get(0) == elt0);
      assertTrue(cl1.get(1) == elt1);
      assertTrue(cl1.get(2) == elt2);
      assertTrue(cl1.get(3) == elt3);
      assertTrue(cl1.get(4) == elt4);
      assertTrue(cl1.get(5) == elt6);
      assertTrue(((RbTreeChildList)cl1).rbcheck());

      // delete the root of the tree
      ChildList cl2 = cl1.delete(3);
      assertTrue("0", cl2.get(0) == elt0);
      assertTrue("1", cl2.get(1) == elt1);
      assertTrue("2", cl2.get(2) == elt2);
      assertTrue("3", cl2.get(3) == elt4);
      assertTrue("4", cl2.get(4) == elt6);
      assertTrue(((RbTreeChildList)cl2).rbcheck());

      // delete first element
      ChildList cl3 = cl.delete(0);
      assertTrue(cl3.get(0) == elt1);
      assertTrue(cl3.get(1) == elt2);
      assertTrue(cl3.get(2) == elt3);
      assertTrue(cl3.get(3) == elt4);
      assertTrue(cl3.get(4) == elt5);
      assertTrue(cl3.get(5) == elt6);
      assertTrue(((RbTreeChildList)cl3).rbcheck());

      // delete last element
      cl = new RbTreeChildList(new Node[]{elt0, elt1, elt2, elt3, elt4, elt5});
      cl = cl.delete(5);
      assertTrue(cl.get(0) == elt0);
      assertTrue(cl.get(1) == elt1);
      assertTrue(cl.get(2) == elt2);
      assertTrue(cl.get(3) == elt3);
      assertTrue(cl.get(4) == elt4);
      assertTrue(((RbTreeChildList)cl).rbcheck());

      // delete remaining elements
      for (int i = 0; i < 5; i++)
         cl = cl.delete(0);
      assertTrue(cl.size() == 0);

      // check invariants in a larger example
      cl = new RbTreeChildList(new Node[]{CharData.createCharData("0")});
      for (int i = 1; i <= 121; i++)
         cl = cl.append(CharData.createCharData(Integer.toString(i)));
      Random rand = new Random(7913);
      for (int i = 1; i <= 40; i++)
         cl = cl.delete(rand.nextInt(cl.size()));

      assertTrue(((RbTreeChildList)cl).rbcheck());
  }
}