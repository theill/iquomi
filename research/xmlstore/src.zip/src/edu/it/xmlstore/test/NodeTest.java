package edu.it.xmlstore.test;

import junit.framework.*;
import edu.it.xmlstore.xml.*;
import java.io.IOException;
import java.io.File;

public class NodeTest extends TestCase {

   private static char sep =  File.separatorChar;
   private static String testFile = ".." + sep 
                                    + "files" + sep 
                                    + "xmldocs" + sep
                                    + "nodetest.xml";

   public NodeTest(String name) {
      super(name);
   }

   public static Test suite() {
      TestSuite suite = new TestSuite(NodeTest.class);
      return suite;
   }

   public static void main(String[] args) {
      junit.textui.TestRunner.run(NodeTest.class);
   }

   public void testEquals() {
      Node text1  = CharData.createCharData("Text1");
      Node text1a = CharData.createCharData("Text1");
      Node text2  = CharData.createCharData("Text2");

      Node elt1  = Element.createElement( "Element", new Node[] {text1} );
      Node elt1a = Element.createElement( "Element", new Node[] {text1a} );
      Node otherName = Element.createElement("Another Element",
                                             new Node[] {text1} );
      Node otherChildren = Element.createElement("Element",
                                                 new Node[] {text2} );
      Node moreChildren  = Element.createElement("Element",
                                                 new Node[] {text1, text1a} );

      assertEquals(elt1, elt1);
      assertEquals(elt1, elt1a);

      assertTrue( !elt1.equals(otherName)     );
      assertTrue( !elt1.equals(otherChildren) );
      assertTrue( !elt1.equals(moreChildren)  );
   }

   public void testHashConsing() {
      Node cdata1 = CharData.createCharData("The same");
      Node cdata2 = CharData.createCharData("The same");
      assertSame(cdata1, cdata2);

      Node elt1 = Element.createElement("Same Same", new Node[]{cdata1});
      Node elt2 = Element.createElement("Same Same", new Node[]{cdata2});
      assertSame(elt1, elt2);
   }

   public void testReplaceIllegalChars() {
      CharData cdata = CharData.createCharData("This is <filled> with " +
                                               "<>illegal &<markup & stuff");
      assertEquals(cdata.getValue(), "This is &lt;filled&gt; with " +
                              "&lt;&gt;illegal &amp;&lt;markup &amp; stuff");
   }

   public void testCreateElementFromFile() {
      try {
         Node root = Element.createElementFromFile(testFile);
      }
      catch(IOException e) {
         assertTrue("Error in testCreateElementFromFile", false);
      }
   }

}
