package edu.it.xmlstore.test;

import junit.framework.*;
import java.io.*;
import edu.it.xmlstore.xml.*;
import edu.it.xmlstore.*;
import java.util.LinkedList;

public class ArrayChildListTest extends TestCase {

   public ArrayChildListTest(String name) {
      super(name);
   }

   public static Test suite() {
      TestSuite suite = new TestSuite(ArrayChildListTest.class);
      return suite;
   }

   public static void main(String[] args) {
      junit.textui.TestRunner.run(ArrayChildListTest.class);
   }

   // elements used in all tests
   Node text1 = CharData.createCharData("Text1");
   Node text2 = CharData.createCharData("Text2");
   Element elt  = Element.createElement("Element", new Node[] {text1, text2});
   Element elt2 = Element.createElement("Element Two", new Node[] {text2});
   Element elt3 = Element.createElement("Element Three", new Node[] {text1});



   public void testEquals() {
      ChildList same1 = new ArrayChildList(new Node[] {elt, elt2, elt3});
      ChildList same2 = new ArrayChildList(new Node[] {elt, elt2, elt3});
      ChildList diff = new ArrayChildList(new Node[] {elt, elt3, elt2});

      assertEquals(same1, same2);
      assertTrue(!same1.equals(diff));
   }

   public void testIterator() {
      ChildList list = new ArrayChildList(new Node[] {elt, elt2, elt3});
      ChildList.Iterator iterator = list.iterator();

      assertEquals(elt, iterator.next());
      assertEquals(elt2, iterator.next());
      assertEquals(elt3, iterator.next());
      assertTrue(!iterator.hasNext());
   }

  public void testAppendGet() {
      Node elt1 = Element.createElement("1", new Node[]{});
      Node elt2 = Element.createElement("2", new Node[]{});
      Node elt3 = CharData.createCharData("3");
      Node elt4 = CharData.createCharData("4");

      ChildList cl = new ArrayChildList(new Node[]{elt1, elt2});
      ChildList cl1 = cl.append(elt3);
      ChildList cl2 = cl1.append(elt4);

      assertTrue(cl.get(0) == elt1);
      assertTrue(cl.get(1) == elt2);

      assertTrue(cl1.get(0) == elt1);
      assertTrue(cl1.get(1) == elt2);
      assertTrue(cl1.get(2) == elt3);

      assertTrue(cl2.get(0) == elt1);
      assertTrue(cl2.get(1) == elt2);
      assertTrue(cl2.get(2) == elt3);
      assertTrue(cl2.get(3) == elt4);
   }


   public void testDelete() {
      Node elt0 = CharData.createCharData("0");
      Node elt1 = Element.createElement("1", new Node[]{});
      Node elt2 = Element.createElement("2", new Node[]{});
      Node elt3 = CharData.createCharData("3");
      Node elt4 = CharData.createCharData("4");
      Node elt5 = CharData.createCharData("5");
      Node elt6 = CharData.createCharData("6");

      ChildList cl = new ArrayChildList(
                     new Node[]{elt0, elt1, elt2, elt3, elt4, elt5, elt6});

      ChildList cl1 = cl.delete(5);

      assertTrue(cl1.get(0) == elt0);
      assertTrue(cl1.get(1) == elt1);
      assertTrue(cl1.get(2) == elt2);
      assertTrue(cl1.get(3) == elt3);
      assertTrue(cl1.get(4) == elt4);
      assertTrue(cl1.get(5) == elt6);

      // delete the root of the tree
      ChildList cl2 = cl1.delete(3);
      assertTrue("0", cl2.get(0) == elt0);
      assertTrue("1", cl2.get(1) == elt1);
      assertTrue("2", cl2.get(2) == elt2);
      assertTrue("3", cl2.get(3) == elt4);
      assertTrue("4", cl2.get(4) == elt6);

      // delete first element
      ChildList cl3 = cl.delete(0);
      assertTrue(cl3.get(0) == elt1);
      assertTrue(cl3.get(1) == elt2);
      assertTrue(cl3.get(2) == elt3);
      assertTrue(cl3.get(3) == elt4);
      assertTrue(cl3.get(4) == elt5);
      assertTrue(cl3.get(5) == elt6);

      // delete last element
      cl = new ArrayChildList(new Node[]{elt0, elt1, elt2, elt3, elt4, elt5});
      cl = cl.delete(5);
      assertTrue(cl.get(0) == elt0);
      assertTrue(cl.get(1) == elt1);
      assertTrue(cl.get(2) == elt2);
      assertTrue(cl.get(3) == elt3);
      assertTrue(cl.get(4) == elt4);

      // delete remaining elements
      for (int i = 0; i < 5; i++)
         cl = cl.delete(0);
      assertTrue(cl.size() == 0);
   }

   public void testAppend() {

   }

}