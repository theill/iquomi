
package edu.it.xmlstore.test;

import junit.framework.*;
import edu.it.xmlstore.rpc.udp.*;
import edu.it.xmlstore.rpc.*;
import java.util.Iterator;
import java.util.Arrays;

public class UdpMessageTest extends TestCase {

   public UdpMessageTest(String name) {
      super(name);
   }

   public static Test suite() {
      TestSuite suite = new TestSuite(UdpMessageTest.class);
      return suite;
   }

   public static void main(String[] args) {
      junit.textui.TestRunner.run(UdpMessageTest.class);
   }

   public void testOutgoingMessage() {    
      // Create message spanning one fragment
      OutgoingUdpMessage m = new OutgoingUdpMessage(1, 300, MessageFragment.TYPE_REQUEST);
      assertTrue(m.getId() == 1);
      
      // Check fragment      
      MessageFragment f = m.iterator().next();
      assertTrue(f.length() == (300 + MessageFragment.HEADER_SIZE));
      assertTrue(f.getId() == 1);
      assertTrue(f.getType() == MessageFragment.TYPE_REQUEST);
      assertTrue(f.getNumber() == 1);
      assertTrue(f.getTotal() == 1);

      // Create message of zero length
      m = new OutgoingUdpMessage(1, 0, MessageFragment.TYPE_REQUEST);
      f = m.iterator().next();
      assertTrue(f.length() == MessageFragment.HEADER_SIZE);
      assertTrue(f.getId() == 1);
      assertTrue(f.getType() == MessageFragment.TYPE_REQUEST);
      assertTrue(f.getNumber() == 1);
      assertTrue(f.getTotal() == 1);
      assertTrue(f.asArray().length == MessageFragment.HEADER_SIZE);

      // Create message spanning four fragments
      m = new OutgoingUdpMessage(1, (3*MessageFragment.MAX_MESSAGE_SIZE) + 300, MessageFragment.TYPE_REQUEST);
      assertTrue(m.getId() == 1);
      
      // Check first fragment      
      FragmentList.Iterator i = m.iterator();
      f = i.next();
      assertTrue(f.length() == (MessageFragment.MAX_DATAGRAM_SIZE));
      assertTrue(f.getId() == 1);
      assertTrue(f.getType() == MessageFragment.TYPE_REQUEST);
      assertTrue(f.getNumber() == 1);
      assertTrue(f.getTotal() == 4);

      // Check second fragment      
      f = i.next();
      assertTrue(f.length() == (MessageFragment.MAX_DATAGRAM_SIZE));
      assertTrue(f.getId() == 1);
      assertTrue(f.getType() == MessageFragment.TYPE_REQUEST);
      assertTrue(f.getNumber() == 2);
      assertTrue(f.getTotal() == 4);

      // Check third fragment      
      f = i.next();
      assertTrue(f.length() == (MessageFragment.MAX_DATAGRAM_SIZE));
      assertTrue(f.getId() == 1);
      assertTrue(f.getType() == MessageFragment.TYPE_REQUEST);
      assertTrue(f.getNumber() == 3);
      assertTrue(f.getTotal() == 4);

      // Check fourth fragment      
      f = i.next();
      assertTrue(f.length() == (300 + MessageFragment.HEADER_SIZE));
      assertTrue(f.getId() == 1);
      assertTrue(f.getType() == MessageFragment.TYPE_REQUEST);
      assertTrue(f.getNumber() == 4);
      assertTrue(f.getTotal() == 4);

      // Create message spanning EXACTLY one fragments
      m = new OutgoingUdpMessage(1, MessageFragment.MAX_MESSAGE_SIZE, MessageFragment.TYPE_REQUEST);

      // Make sure there is only one fragment
      i = m.iterator();
      assertTrue(i.hasNext());
      i.next();
      assertTrue(!i.hasNext());

   }


   
   public void testIncomingMessage() {
      // Create message spanning one fragment
      IncomingUdpMessage m = new IncomingUdpMessage(1);
      assertTrue("Checking id", m.getId() == 1);
      
      MessageFragment f1 = new MessageFragment(1, MessageFragment.MAX_MESSAGE_SIZE, MessageFragment.TYPE_REPLY, (short) 1, (short) 3);
      MessageFragment f2 = new MessageFragment(1, MessageFragment.MAX_MESSAGE_SIZE, MessageFragment.TYPE_REPLY, (short) 2, (short) 3);
      MessageFragment f3 = new MessageFragment(1, 400, MessageFragment.TYPE_REPLY, (short) 3, (short) 3);
      MessageFragment fIdError = new MessageFragment(2, 400, MessageFragment.TYPE_REPLY, (short) 1, (short) 3);
      MessageFragment fTotalError = new MessageFragment(1, 400, MessageFragment.TYPE_REPLY, (short) 1, (short) 2);
      
      // Add fragments in correct order.
      assertTrue(!m.isComplete());
      m.addFragment(f1);
      assertTrue(!m.isComplete());
      m.addFragment(f2);
      assertTrue(!m.isComplete());
      m.addFragment(f3);
      assertTrue(m.isComplete());

      // Add fragments more than once 
      m = new IncomingUdpMessage(1);
      m.addFragment(f2);
      assertTrue(!m.isComplete());
      m.addFragment(f2);
      assertTrue(!m.isComplete());
      m.addFragment(f1);
      assertTrue(!m.isComplete());
      m.addFragment(f1);
      assertTrue(!m.isComplete());
      m.addFragment(f2);
      assertTrue(!m.isComplete());
      m.addFragment(f3);
      assertTrue(m.isComplete());


      // Add fragments in wrong order.
      m = new IncomingUdpMessage(1);
      assertTrue(!m.isComplete());
      m.addFragment(f2);
      assertTrue(!m.isComplete());
      m.addFragment(f1);
      assertTrue(!m.isComplete());
      m.addFragment(f3);
      assertTrue(m.isComplete());

      // Add fragments where one fragment has an id error and another has a wrong total.
      m = new IncomingUdpMessage(1);
      assertTrue(!m.isComplete());
      m.addFragment(f3);
      assertTrue(!m.isComplete());
      m.addFragment(f1);
      assertTrue(!m.isComplete());
      try {
	 m.addFragment(fIdError);
	 assertTrue("Expected Exception", false);
      }
      catch (RuntimeException e) {
	 // All ok 
      }

      try {
	 m.addFragment(fTotalError);
      	 assertTrue("Expected Exception", false);
      }
      catch(RuntimeException e) {
      	 // All ok 
      }
   }

   public void testOutgoingPutAndGet() {      
      // Test unfragmented put and get
      TestOutgoingUdpMessage m = new TestOutgoingUdpMessage(1, 15, MessageFragment.TYPE_REQUEST);

      // Different types of content
      byte b = (byte)7;
      byte[] ba = new byte[]{0,1,2,3,4,5,6,7,8,9};
      int i = 512;
    
      // Set content:
      m.putByte(b);
      m.putByteArray(ba);
      m.putInt(i);
      
      // Read fragment
      FragmentList frags = m.getFragments();
      assertTrue(b == frags.getByte());
      assertTrue(Arrays.equals(ba, frags.getByteArray(ba.length)));
      assertTrue(i == frags.getInt());

      // Check that fragmented message can handle, byte
      m = new TestOutgoingUdpMessage(1, MessageFragment.MAX_MESSAGE_SIZE + 1, MessageFragment.TYPE_REQUEST);      
      byte[] filler = new byte[MessageFragment.MAX_MESSAGE_SIZE];
      for (int j=0; j< filler.length; j++) // insert data into filler.
	 filler[j] = (byte)j;
      m.putByteArray(filler);
      m.putByte(b);

      // Read fragment
      frags = m.getFragments();
      assertTrue(Arrays.equals(filler, frags.getByteArray(filler.length)));
      assertTrue(b == frags.getByte());
      
      // check that fragmented message can handle int
      m = new TestOutgoingUdpMessage(1, MessageFragment.MAX_MESSAGE_SIZE - 2 + 4, MessageFragment.TYPE_REQUEST);      
      filler = new byte[MessageFragment.MAX_MESSAGE_SIZE - 2];
      for (int j=0; j<filler.length; j++) 
	 filler[j] = (byte)j;
      m.putByteArray(filler);
      m.putInt(i);

      // Read fragment
      frags = m.getFragments();
      assertTrue(Arrays.equals(filler, frags.getByteArray(filler.length)));
      assertTrue(i == frags.getInt());

      // check that fragmented message can handle, byte[]
      m = new TestOutgoingUdpMessage(1, MessageFragment.MAX_MESSAGE_SIZE-1+10, MessageFragment.TYPE_REQUEST);      
      filler = new byte[MessageFragment.MAX_MESSAGE_SIZE - 1];
      for (int j=0; j< filler.length; j++) 
	 filler[j] = (byte)j;
      ba = new byte[10];
      m.putByteArray(filler);
      m.putByteArray(ba);

      // Read fragment
      frags = m.getFragments();
      assertTrue(Arrays.equals(filler, frags.getByteArray(filler.length)));
      assertTrue(Arrays.equals(ba, frags.getByteArray(ba.length)));

      // check that fragmented message can handle byte[] spanning several fragments
      m = new TestOutgoingUdpMessage(1, MessageFragment.MAX_MESSAGE_SIZE*3+7+10, MessageFragment.TYPE_REQUEST);      
      filler = new byte[10];
      for (int j=0; j< filler.length; j++) 
	 filler[j] = (byte)j;
      ba = new byte[MessageFragment.MAX_MESSAGE_SIZE*3+7];
      for (int j=0; j< ba.length; j++) 
	 ba[j] = (byte)(j*Math.random());
      m.putByteArray(filler);
      m.putByteArray(ba);
      
      // Read fragment
      frags = m.getFragments();
      assertTrue(Arrays.equals(filler, frags.getByteArray(filler.length)));
      assertTrue(Arrays.equals(ba, frags.getByteArray(ba.length)));
   }
   
   private static class TestOutgoingUdpMessage extends OutgoingUdpMessage {
      public TestOutgoingUdpMessage(int id, int length, byte type) {
	 super(id, length, type);
      }

      public FragmentList getFragments() {
	 fragments.reset();
	 return fragments;
      }
   }
}
