package edu.it.xmlstore.test;

import edu.it.xmlstore.rpc.*;
import edu.it.xmlstore.rpc.udp.UdpTransmitter;
import edu.it.xmlstore.*;
import edu.it.xmlstore.xml.*;
import edu.it.xmlstore.chord.*;
import java.net.InetSocketAddress;
import java.io.IOException;
import java.util.Arrays;
import java.net.InetAddress;
import java.math.BigInteger;
import junit.framework.*;

public class XmlStoreMessageDispatcherTest extends TestCase {
   
   public XmlStoreMessageDispatcherTest(String name) {
      super(name);
   }

   public static Test suite() {
      TestSuite suite = new TestSuite(XmlStoreMessageDispatcherTest.class);
      return suite;
   }

   public static void main(String[] args) {
      junit.textui.TestRunner.run(XmlStoreMessageDispatcherTest.class);
   }
 
   public static final int PORT70 = 8170;
   public static final int PORT80 = 8180;
            
   public void testMethods() {
      try {
	 String val65 = "Number 65";
	 String val72 = "Number 72";
	 String val84 = "Number 84";
	 ValueReference ref65 = ValueUtil.getTestValueReference(65);
	 ValueReference ref72 = ValueUtil.getTestValueReference(72);
	 ValueReference ref84 = ValueUtil.getTestValueReference(84);

	 InetSocketAddress address70 = new InetSocketAddress(InetAddress.getLocalHost(), PORT70);
	 ValueReference id70 = new ChordIdImpl(70);
	 FakeXmlStoreServer s70 = new FakeXmlStoreServer(id70, PORT70);
	 XmlStoreMessageDispatcher d70 = new XmlStoreMessageDispatcher(s70);
	 Transmitter t70 = new UdpTransmitter(PORT70, d70);
	 d70.setTransmitter(t70);

	 ValueReference id80 = new ChordIdImpl(80);
	 InetSocketAddress address80 = new InetSocketAddress(InetAddress.getLocalHost(), PORT80);
	 FakeXmlStoreServer s80 = new FakeXmlStoreServer(id80, PORT80);
	 XmlStoreMessageDispatcher d80 = new XmlStoreMessageDispatcher(s80);
	 Transmitter t80 = new UdpTransmitter(PORT80, d80);
	 d80.setTransmitter(t80);
      
	 XmlStoreServerProxy proxy80at70 = new XmlStoreServerProxy(id80, address80, t70);

	 // Make sure that we do not lookup connectedServers in XmlStoreHome.
	 NetworkUtil.testing(null);
	 
	 // SaveToDisk
	 proxy80at70.saveToDisk(val65.getBytes(), ref65);
	 assertTrue("SaveToDisk", s80.saveToDiskCalled);
	 
	 // SaveValue
	 proxy80at70.saveValue(val65.getBytes(), ref65);
	 assertTrue("SaveValue", s80.saveValueCalled);
	 
	 // UpdateFingerTable -- NB! Asynchronous call
	 proxy80at70.updateFingerTable(s70, 1);
	 delay(200);
	 assertTrue("UpdateFingerTable", s80.updateFingerTableCalled);

	 // RemoveFromFingerTable -- NB! Asynchronous call
	 proxy80at70.removeFromFingerTable(s70, 1);
	 delay(200);
	 assertTrue("RemoveFingerTable", s80.removeFromFingerTableCalled);

	 // ClosestPrecedingFinger
	 ChordNode s = proxy80at70.closestPrecedingFinger(ChordIdImpl.getRandomId());
	 assertTrue("ClosestPrecedingFinger", s.serverId().equals(s80.returnXmlStore.serverId()));

	 
	 // FindPredecessor
	 s = proxy80at70.findPredecessor(ChordIdImpl.getRandomId());
	 assertTrue("FindPrecedessor", s.serverId().equals(s80.returnXmlStore.serverId()));

	 // FindSuccesor
	 s = proxy80at70.findSuccessor(ChordIdImpl.getRandomId());
	 assertTrue("FindSuccessor", s.serverId().equals(s80.returnXmlStore.serverId()));
	 
	 // SetPredecessor
	 proxy80at70.setPredecessor(s70);
	 assertTrue("SetPrecessor", s80.setPredecessorCalled);

	 // SetSuccessor
	 proxy80at70.setSuccessor(s70);
	 assertTrue("SetSuccessor", s80.setSuccessorCalled);

	 // Notify
	 proxy80at70.notify(s70);
	 assertTrue("Notify", s80.notifyCalled);

	 // LoadValue
	 byte[] b = proxy80at70.loadValue(id70);
	 assertTrue("LoadValue", Arrays.equals(b, s80.returnByteArray));
	 
	 // MoveKeys
	 proxy80at70.moveKeys(s70);
	 assertTrue("MoveKeys", s80.moveKeysCalled);

	 // MoveAllKeys
	 proxy80at70.moveAllKeys(s70);
	 assertTrue("MoveAllKeys", s80.moveAllKeysCalled);
	 
	 // Successor
	 s = proxy80at70.successor();
	 assertTrue("Successor", s.serverId().equals(s80.returnXmlStore.serverId()));

	 // Predecessor
	 s = proxy80at70.predecessor();
	 assertTrue("Precessor", s.serverId().equals(s80.returnXmlStore.serverId()));
	 

      }
      catch (Throwable e) {
	 e.printStackTrace(System.out);
	assert false : "Exception checking methods in XmlStoreMessageDispatcherTest: " + e;
      }
   }

   private static void delay(int time) {
      try {
	 Thread.sleep(time);
      } catch(InterruptedException e) {
	 // ok, ok, we'll get on with it...
      };
   }
}

