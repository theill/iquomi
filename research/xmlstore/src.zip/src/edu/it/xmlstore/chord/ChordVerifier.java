package edu.it.xmlstore.chord;

import edu.it.xmlstore.rpc.RemoteException;

/**
 * Class used for testing of the Chord protocol.
 */
public class ChordVerifier {

   // Test method that checks whether the Chord-ring is in a correct state
   public static int checkChordRing(ChordNode current, int expectedServers) {
      int errors = 0;
      int servers = 0;
      boolean wrappedAround = false;
      try {
         ChordNode n = current;
         do {
            // Check that ids only rise. Can only wrap around once
            if ( n.serverId().greaterThan(n.successor().serverId()) ) {
               assert !wrappedAround : "Wrap around detected twice";
               wrappedAround = true;
            }

            if ( n.serverId().equals(n.successor().serverId()) )
               assert n == n.predecessor() : "Loop in Chord ring at " +
               n.serverId();

            // Check predecessor property
            assert n.serverId().equals(n.successor().predecessor().serverId()) :
                            "Predecessor at node " + n.successor().serverId() +
                            " should be " + n.serverId() + ", but is " +
                            n.successor().predecessor().serverId();

            // Check finger table of each node (not successor though)
            for (int i = 2; i <= ChordId.M; i++)
               if ( !checkFinger(n, i) )
                  errors++;

            servers++;
         } while ((n = n.successor()) != current);

      // Check that the number of servers is ok
      assert servers == expectedServers : "Wrong number of servers, should be "
                           + expectedServers + ", is " + servers;

      }
      catch (RemoteException e) {
         assert false : "Exception checking chord ring: " + e;
      }

      // report number of errors in finger tables
      return errors;
   }


   // slowly but correctly looks up the node that should be in the finger
   // table of node source at position i.
   public static boolean checkFinger(ChordNode source, int i) {
      boolean flag = false;
      try {
         // Lookup correct finger
         ChordNode n = source;
         while ( !ChordId.isBetweenRightIncl(
               ((ChordNodeImpl) source).finger[i].start,
                n.serverId(), n.successor().serverId()) ) {
            n = n.successor();         // slow lookups O(N)
         }
         // We found predecessor -- get successor
         n = n.successor();

         // Check that node is the right one
         if (((ChordNodeImpl)source).finger[i].node == n)
            flag = true;
         else {
            flag = false;
         }
      }
      catch (RemoteException e) {
         assert false : "Exception checking chord ring: " + e;
      }
      return flag;
   }
}