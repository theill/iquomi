package edu.it.xmlstore.chord;

/**
 * Exception thrown when an ChordNode is not responding because of network
 * failures or because the node has left the network.
 */
public class NodeNotRespondingException extends Exception {
   public NodeNotRespondingException(String message) {
      super(message);
   }
}