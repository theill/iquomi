package edu.it.xmlstore.chord;

import java.util.Hashtable;
import java.util.Set;
import java.util.Iterator;
import java.util.Random;
import java.util.LinkedList;
import edu.it.xmlstore.rpc.RemoteException;

/**
 * Implements the ChordNode interface that represents a chord node in the
 * Chord protocol.
 * Used by XmlStoreServerImpl to lookup the XmlStore responsible for a value.
 */
public class ChordNodeImpl implements ChordNode {

   /** The id of this XmlStoreServer.*/
   private final ChordId serverId;

   /** The predecessor on the CHORD ring */
   private ChordNode predecessor;

   /** Finger table */
   public FingerEntry[] finger;

   public int chordJumps;

   /** Constructor */
   public ChordNodeImpl(ChordId serverId) {
      this.serverId = serverId;

      // Initialize finger table by calculating intervals
      finger = new FingerEntry[ChordId.M+1];
      for (int i = 1; i <= ChordId.M; i++) {
         finger[i] = new FingerEntry();
         finger[i].start = finger[i].intervalFrom
	    = serverId.add(new ChordIdImpl(2).pow(i-1));
         finger[i].intervalTo = serverId.add(new ChordIdImpl(2).pow(i));
      }
   }


   public ChordNode predecessor() {
      return predecessor;
   }


   public ChordId serverId() {
      return serverId;
   }


   public void setPredecessor(ChordNode predecessor) {
      this.predecessor = predecessor;
   }


   /**
    * Gives access to the successor of the ChordNode.
    * @return the successor of this ChordNode on the CHORD ring
    * (= the first entry in the finger table)
    */
   public ChordNode successor() throws RemoteException {
      return finger[1].node;
   }


   /**
    * Mutator for the successor of the ChordNode (= the first entry in the
    * finger table).
    * @param n the new successor
    */
   public void setSuccessor(ChordNode n) throws RemoteException {
      finger[1].node = n;
      //insertSuccessor(n, 0);
   }


   /**
    * Looks up a ChordNode responsible for a given key from the system
    * (not necessarily this node).
    * @param key
    * @returns the ChordNode responsible for the key
    */
   public ChordNode lookup(ChordId key) throws RemoteException {
      return findSuccessor(key);
   }


   /**
    * Finds the server that succeeds a given id.
    * A value with a given id should be stored at the successor of the id.
    *
    * @param id the identifier
    * @returns the server that succeeds the id
    */
   public ChordNode findSuccessor(ChordId id) throws RemoteException {
      ChordNode n = findPredecessor(id);

      return n.successor();
   }


   /**
    * Finds the server that precedes a given id.
    * This method is the main workhorse of the Chord protocol.
    *
    * @param id the identifier
    * @returns the server that preceeds the id
    */
   public ChordNode findPredecessor(ChordId id) throws RemoteException {
      if ( serverId().equals(successor().serverId()) )
         return this;
      // Run through nodes in CHORD circle until predecessor is found
      ChordNode n = this;
      
      while ( !ChordId.isBetweenRightIncl(id, n.serverId(),
					  n.successor().serverId()) ) {
         //n = n.successor();              // slow lookups O(N)
         n = n.closestPrecedingFinger(id); // Fast lookups O(log N),
	 // N = the number of servers in the system
      }
      return n;
   }


   /**
    * Find the server most closely preceding id in the finger table.
    */
   public ChordNode closestPrecedingFinger(ChordId id) throws RemoteException {
      for (int i = ChordId.M; i >= 1; i--) {
         if (finger[i].node != null) {
            if ( ChordId.isBetween(finger[i].node.serverId(), serverId, id) ) {
               return finger[i].node;
            }
         }
      }
      throw new RuntimeException("Overshot! Could not find any " +
                                 "preceding fingers.");
   }


   /**
    * Joins this ChordNode to the CHORD ring.
    * @param n an arbitrary ChordNode that is already in the system
    */
   public void join(ChordNode n) throws RemoteException {
      for(int i = 1; i <= ChordId.M; i++)
	 finger[i].node = this;

      if (n == null) {
         // We are the first server in the system.
         // -> simple initialization
         predecessor = this;
      }
      else {
         ChordNode s = n.findPredecessor(serverId);
         ChordNode p;
	 
         // Find our place in the identifier circle between
         // the successor s and the predecessor p
         do {
            p = s;
            s = p.successor();
         } while ( !ChordId.isBetweenRightIncl(serverId, p.serverId(),
					       s.serverId()) );

         // initialize successor and predecessor fields
         //successors = s.getSuccessorList();
         setSuccessor(s);
         predecessor = p;

         // notify predecessor and successor of existence
         p.notify(this);
         s.notify(this);

         // notify nodes that might have this node in their finger table
         // - not the successor and predecessor though
         updateOthers(successor());

         //let this node send queries to fill in its own finger table
         initializeFingerTable(s);

         // stabilize my position in ring - just to check
         stabilize();
      }
   }


   /** Makes this XmlStoreServer leave the CHORD ring. */
   public void leave() throws RemoteException {
      if (successor().serverId().equals(serverId())){
         // Chord node has left the building...
      }
      else {
         predecessor.setSuccessor( successor() );
         successor().setPredecessor(predecessor);
         removeFromOthers();
         //predecessor.updateSuccessorsOnLeave(this, 0);

         //invalidate this server (not in the ring anymore)
         setSuccessor(null);
         predecessor = null;
      }
   }


   /**
    * Find the other ChordNodes that should have this ChordNode in their finger
    * tables, and notify them of its presence.
    */
   public void updateOthers(ChordNode n) throws RemoteException {
      for (int i = 2; i <= ChordId.M; i++) {
         // find last node p whose ith finger might be me
         ChordId id = serverId.subtract( new ChordIdImpl(2).pow(i-1) );
         ChordNode p = n.findPredecessor(id);
         p.updateFingerTable(this, i);
      }
   }


   /**
    * Update the finger table of one of my predeccessors.
    * The finger table is only updated if s is between my id and finger[i]s id.
    * @param s the ChordNode that should be placed in the finger table
    * @param i the position in the finger table that the server should be
    * placed in.
    */
   public void updateFingerTable(ChordNode s, int i) throws RemoteException {
      if ( serverId.equals(s.serverId()) )
	 return;
      if ( ChordId.isBetweenLeftIncl(s.serverId(), serverId,
				     finger[i].node.serverId()) ) { 
         finger[i].node = s;
         predecessor.updateFingerTable(s,i);
      }
   }


   /**
    * Find the other ChordNodes that have this ChordNode in their finger
    * tables, and notify them that it's leaving.
    */
   public void removeFromOthers() throws RemoteException {
      for (int i = 2; i <= ChordId.M; i++) {
         // find last node p whose ith finger might be n
         ChordId id = serverId.subtract( new ChordIdImpl(2).pow(i-1) );
         ChordNode p = findPredecessor(id);

         // if we found ourself, we are looking for the successor CHECK!
         if (p.serverId().equals(serverId())) {
            p = p.successor();
         }
         p.removeFromFingerTable(this, i);
      }
   }


   /**
    * Remove node s from the finger table of one of it's predecessors.
    * The finger table is only updated if s is in the finger table.
    *
    * @param s the server that should be removed from the finger table
    * @param i the position in the finger table that the server should be
    * removed from.
    */
   public void removeFromFingerTable(ChordNode s, int i) throws RemoteException {
      if (serverId().equals(s.serverId())) return;

      if ( finger[i].node == s ) {
         finger[i].node = s.successor();

         // Check that predecessors are updated
         predecessor.removeFromFingerTable(s,i);
      }
   }


   /**
    * Notifies this node of the existence of a new node n.
    * Updates predecessor, successor and finger table.
    */
   public void notify(ChordNode n) throws RemoteException {
      if ( ChordId.isBetween(n.serverId(), serverId, successor().serverId()) ) {
         setSuccessor(n);
      }

      if ( ChordId.isBetween(n.serverId(), predecessor.serverId(), serverId) ) {
         predecessor = n;
      }
   }


   /**
    * Update finger table using server n to perform lookups
    */
   public void initializeFingerTable(ChordNode n) throws RemoteException {

      for (int i = 1; i <= ChordId.M - 1; i++) {
	    
         // Check whether the i'th finger is also the correct i+1'th finger
         if (ChordId.isBetweenLeftIncl
	     (finger[i+1].start, serverId(), finger[i].node.serverId())) {
            finger[i+1].node = finger[i].node;
	 }

         // .. else look it up
	 else {
	    ChordNode p = n.findSuccessor(finger[i+1].start);
	    ChordNode s;

            // make sure we found the right place and that we
            // are not fooled by incorrect state due to concurrent join/leave
            
	    do {
               s = p;
               p = p.predecessor();
            } while ( p.serverId().greaterThanEqual(finger[i+1].start)
                      && p.serverId().lessThan(s.serverId()) );
	    
	    finger[i+1].node = s;
	    
	 }
      }
   }


   /**
    * Verify n's immediate successor and predecessor
    * (Called periodically)
    *
    */
   public void stabilize() throws RemoteException {
      ChordNode x = predecessor.successor();
      if( ChordId.isBetween(x.serverId(), predecessor.serverId(), serverId) ) {
	 predecessor = x;
      }

      ChordNode successor = successor();
      x = successor.predecessor();
      if( ChordId.isBetween(x.serverId(), serverId, successor.serverId()) ) {
	 setSuccessor(x);
      }
   }


   /**
    * Periodically refresh finger table entries
    *
    */
   private Random rand = new Random();
   public void fixFingers() throws RemoteException {
      if (finger != null) {
	 // find random finger to fix
	 int i = rand.nextInt(ChordId.M) + 1;
	 finger[i].node = findSuccessor(finger[i].start);
      }
   }


   /**
    *  Simple toString()
    */
   public String toString() {
      String s = "ChordNode #" + serverId;
      return s;
   }


   /**
    * Simple helper class holding an entry of the finger table
    */
   public static class FingerEntry {
      public ChordId start, intervalFrom, intervalTo;
      public ChordNode node;
      public String toString() {
	 String s = node == null ? "null" : node.serverId().toString();
	 return "\tstart:" + start + ", [" + intervalFrom + ", " + intervalTo +
	    "), node: " + s + "\n";
      }
   } // end inner class
}
