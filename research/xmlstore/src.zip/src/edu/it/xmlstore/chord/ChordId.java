package edu.it.xmlstore.chord;

import java.io.Serializable;
import java.math.BigInteger;
import edu.it.xmlstore.ValueReference;

/**
 * Represents both a key identifier and a node identifer in the Chord protocol.
 */
public abstract class ChordId implements Comparable, Serializable,
					             ValueReference {

  // The number of bits used to represent keys
   public static final int M = 160;
   // The number of keys in the identifier space
   public static final BigInteger KEYS = new BigInteger("2").pow(M);
   // the maximum value the ChordId can have (2^160-1)
   public final static BigInteger MAX_VALUE =
                                  KEYS.subtract(new BigInteger("1"));

   // the minimum value the ChordId can have (0, zero)
   public final static BigInteger MIN_VALUE = new BigInteger("0");

   public final static int BASE_TEN_RADIX = 10;
   public final static int MAX_RADIX = Character.MAX_RADIX;
   //public final static int CHORD_RADIX = BASE_TEN_RADIX;
   public final static int CHORD_RADIX =  MAX_RADIX;

   // The external 20 byte representation
   abstract public byte[] toBytes();

   // --- Comparison Operators ---
   // Compare to other ChordId
   abstract public int compareTo(Object that);


   // ==
   public boolean equals(Object that) {
      return that instanceof ChordId && this.compareTo(that) == 0;
   }


   // <
   public boolean lessThan(Object that) {
      return this.compareTo(that) < 0;
   }


   // <=
   public boolean lessThanEqual(Object that) {
      return this.compareTo(that) <= 0;
   }


   // >
   public boolean greaterThan(Object that) {
      return this.compareTo(that) > 0;
   }


   // >=
   public boolean greaterThanEqual(Object that) {
      return this.compareTo(that) >= 0;
   }

   // --- Mathematical Operators ---
   // + operator
   abstract public ChordId add(ChordId other);
   // - operator
   abstract public ChordId subtract(ChordId other);
   // ^ operator
   abstract public ChordId pow(int exponent);

   // Human-readable
   public String toString() {
      return new BigInteger(toBytes()).toString(CHORD_RADIX);
   }

   // --- Static  ---
   /**
    * Checks if id is between (from and to), ( = exclusive, ) = exclusive
    * That is from &lt; id &lt; to
    * Handles wrap around situations
    * @param id
    * @param from
    * @param to
    */
   public static boolean isBetween (ChordId id, ChordId from, ChordId to) {
     boolean r;
     if (from.equals(to)) {
       r = !id.equals(from);   // n is the only node not in the interval (id,id)
     } else if (from.lessThan(to)) {
       r = id.greaterThan(from) && id.lessThan(to);
     } else {
       r = id.greaterThan(from) || id.lessThan(to);
     }
     return r;
   }


   /**
    * Checks if id is between [from and to). [ = inclusive, ) = exclusive
    * That is from &lt;= id &lt; to
    * Handles wrap around situations
    * @param id
    * @param from
    * @param to
    */
   public static boolean isBetweenLeftIncl (ChordId id, ChordId from,
                                            ChordId to) {
     boolean r;
     if (from.equals(to) && id.equals(from)) {
       r = true;
     } else if (from.lessThan(to)) {
       r = id.greaterThanEqual(from) && id.lessThan(to);
     } else {
       r = id.greaterThanEqual(from) || id.lessThan(to);
     }
     return r;
   }


   /**
    * Checks if id is between (from and to]. ( = exclusive, ] = inclusive
    * That is from &lt; id &lt;= to
    * Handles wrap around situations
    * @param id
    * @param from
    * @param to
    */
   public static boolean isBetweenRightIncl (ChordId id, ChordId from,
                                             ChordId to) {
     boolean r;
     if (from.equals(to) && id.equals(from)) {
       r = true;
     } else if (from.lessThan(to)) {
       r = id.greaterThan(from) && id.lessThanEqual(to);
     } else {
       r = id.greaterThan(from) || id.lessThanEqual(to);
     }
     return r;
   }
}
