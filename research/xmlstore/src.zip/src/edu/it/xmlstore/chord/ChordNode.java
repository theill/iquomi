package edu.it.xmlstore.chord;

import edu.it.xmlstore.rpc.RemoteException;
 
/**
 * Represents a chord node in the Chord protocol.
 */
public interface ChordNode {
   public ChordId serverId();
   public ChordNode predecessor() throws RemoteException;
   public void setPredecessor(ChordNode predecessor) throws RemoteException;
   public ChordNode successor() throws RemoteException;
   public void setSuccessor(ChordNode n) throws RemoteException;
   public ChordNode lookup(ChordId key) throws RemoteException;
   public ChordNode findSuccessor(ChordId id) throws RemoteException;
   public ChordNode findPredecessor(ChordId id) throws RemoteException;
   public ChordNode closestPrecedingFinger(ChordId id) throws RemoteException;
   public void join(ChordNode n) throws RemoteException;
   public void leave() throws RemoteException;
   public void updateOthers(ChordNode n) throws RemoteException;
   public void updateFingerTable(ChordNode s, int i) throws RemoteException;
   public void removeFromOthers() throws RemoteException;
   public void removeFromFingerTable(ChordNode s, int i) throws RemoteException;
   public void notify(ChordNode n) throws RemoteException;
   public void stabilize() throws RemoteException;
}
