package edu.it.xmlstore.chord;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Random;

/**
 * An implementation of the ChordId interface, which represent both a key id
 * and a node id in the Chord protocol. It stores the identifier in a
 * BigInteger.
 */
public class ChordIdImpl extends ChordId implements Comparable, Serializable {

   /**
    * Big integer to delegate to. The class stores its value in this field.
    */
   private BigInteger value;

   // --- Constructors ---
   // Simple constructor
   public ChordIdImpl(BigInteger value) {
      // Check the value: If it is below zero
      // wrap around so it is within identifier space.
      // If it is above max value then modulate so it
      // stays within identifier space.
      if (value.compareTo(MIN_VALUE) < 0)       // value < MIN_VALUE
         this.value = MAX_VALUE.add(value);
      else if (value.compareTo(MAX_VALUE) > 0)  // value > MAX_VALUE
         this.value = value.mod(KEYS);
      else
         this.value = value;
   }


   public ChordIdImpl(long i) {
      this(new BigInteger(Long.toString(i)));
   }


   public ChordIdImpl(String i) {
      this(new BigInteger(i));
   }


   // Accessor
   public BigInteger getValue() {
      return value;
   }


   // The external 20 byte representation
   public byte[] toBytes() {
      return value.toByteArray();
   }


   // Compare to other ChordId
   public int compareTo(Object o) {
      ChordIdImpl other = (ChordIdImpl)o;
      return value.compareTo( other.getValue() );
   }


   // --- Mathematical operators ---
   // + operator
   public ChordId add(ChordId cid) {
      ChordIdImpl other = (ChordIdImpl)cid;
      return new ChordIdImpl( value.add(other.getValue()) );
   }


   // - operator
   public ChordId subtract(ChordId cid) {
      ChordIdImpl other = (ChordIdImpl)cid;
      return new ChordIdImpl( value.subtract(other.getValue()) );
   }


   // ^ operator
   public ChordId pow(int exponent) {
      return new ChordIdImpl( value.pow(exponent) );
   }


   // HashCode
   public int hashCode() {
      return value.hashCode();
   }


   // Generate random id
   private static Random rand = new Random();
   public static ChordId getRandomId() {
      return new ChordIdImpl(new BigInteger(M, rand));
   }
}