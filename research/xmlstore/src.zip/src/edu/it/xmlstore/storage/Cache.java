package edu.it.xmlstore.storage;

import edu.it.xmlstore.ValueReference;
import edu.it.xmlstore.ValueReference;

/**
 * Simple interface for a cache.
 */
public interface Cache {
   public void put(byte[] value, ValueReference ref);
   public byte[] get(ValueReference ref);
   public boolean contains(ValueReference ref);
}