package edu.it.xmlstore.storage;

import edu.it.xmlstore.ValueReference;
import edu.it.xmlstore.ValueUtil;

import java.io.IOException;
import java.io.File;
import java.io.RandomAccessFile;
import java.io.FileNotFoundException;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.Serializable;

import java.util.HashMap;
import java.util.Set;

/**
 * An implementation of Disk that saves a values
 * in one large random access file.
 *
 */
public class RAFileDisk implements Disk {
   /** The directory where the files are stored */
   private File directory;
   private static final String FILE_NAME = "store.txt";
   private static final String INDEX_NAME = "index";

   // Use two file handles: One for writing, one for reading
   private final RAFile diskw;
   private final RAFile diskr;
   
   // Maps value references to locators
   private HashMap values;
   
   /**
    * Constructor: Creates a MultiFileDisk
    * @param directory the directory which values are saved
    */
   public RAFileDisk(String directory) throws IOException {
      // initialize hashmap to remember stored values
      values = new HashMap();

      // Note the place the files should be stored
      // and initialize it
      this.directory = new File(directory);
      initializeDirectory();

      // Initialize disk instances
      this.diskw = new RAFile(this.directory, FILE_NAME, "rwd"); 
      this.diskr = new RAFile(this.directory, FILE_NAME, "r"); // readonly disk
      diskw.seekTo(diskw.size());              // allways append
   }


   /**
    * Initialize the directory in which the values are stored.
    * 1. Make sure it exists
    * 2. If it exists make sure the values inside are loaded
    */
   private void initializeDirectory() {
      // make sure the directory exists
      if (!directory.exists()) {
         directory.mkdirs();
      }
      else {
         // Check that index exists
	 File index = new File(directory, INDEX_NAME);
	 if (index.exists())
	    try {
	       ObjectInputStream ois = new ObjectInputStream(new FileInputStream(index));
	       values = (HashMap)ois.readObject();	    
	       ois.close();
            } 
	    catch (IOException e) {
	       System.out.println("IO Exception: Could not restore index on disk, " + e.getMessage());
	    }
	    catch (ClassNotFoundException e) {
	       System.out.println("Class not found: " + e.getMessage());
	    }	    
      }      
   }


   /**
    * Saves a value (an array of bytes)
    * @param value the value that is to be saved
    * @returns the value reference
    */
   public void save(byte[] value, ValueReference ref) throws IOException {

      // Store the value if it is not already stored on disk
      if (!values.containsKey(ref)) {
	 Locator locator = diskw.write(value);
         values.put(ref, locator);
      }
   }


   /**
    * Loads a value given a value reference
    * @param ref
    * @returns the value
    */
   public byte[] load(ValueReference ref) throws IOException {
      // Load the value if it is stored on the disk
      if (values.containsKey(ref)) {
         Locator locator = (Locator)values.get(ref);
	 return diskr.read(locator);	 
      }
      else 
         throw new IOException("Could not load value " + ref + " in " +
                               directory);     
   }

   


   /**
    * Deletes a value given its value reference
    * @param ref
    */
   public boolean delete(ValueReference ref) {
      boolean deleted = false;
      if (values.containsKey(ref)) {
         Locator locator = (Locator)values.remove(ref);
	 deleted = true;
	 // Note: We don't actually delete value on disk
	 // This is a job for a garbage collector
      }
      return deleted;      
   }


   public boolean contains(ValueReference ref) {
      return values.containsKey(ref);
   }


   public Set getKeySet() {
      return values.keySet();
   }

   
   // Make sure index is stored and disks are closed
   private boolean closed = false;
   public void close() throws IOException {
      if (!closed) {
	 closed = true;
	 ObjectOutputStream oos = null;
	 try {
	    oos = new ObjectOutputStream(new FileOutputStream(new File(directory, INDEX_NAME)));
	    oos.writeObject(values);
	 } 
	 catch(IOException e) {
	    System.out.println("Error in disk.close(): " + e.getMessage());
	 }
	 finally {
	    if (oos != null)
	       oos.close();      
	    diskw.close();
	    diskr.close();
	 }
      }
   }

   protected void finalize() throws Throwable {
      super.finalize();
      close();
   }


   private static class Locator implements Serializable {
      public final int offset;
      public final int length;
      public Locator(int offset, int length) {
	 this.offset = offset;
	 this.length = length;
      }
   }


   private static class RAFile {
      private RandomAccessFile file;

      RAFile(File dir, String name, String mode) throws IOException {
	 file = new RandomAccessFile(new File(dir, name), mode);
      }

      private void seekTo(int newPos) throws IOException {
	 if (newPos < 0) {
	    throw new IllegalArgumentException("newPos not positive");
	 }

	 file.seek(newPos);
      }


      public synchronized Locator write(byte[] b) throws IOException {
	 if (b == null) {
	    throw new NullPointerException("b == null");
	 }
	 int offset = size();
	 seekTo(offset);
	 file.write(b);

	 return new Locator(offset, b.length);
      }

      public synchronized byte[] read(Locator locator) throws IOException {
	 seekTo(locator.offset);
	 byte[] b = new byte[locator.length];
	 file.read(b);
	 return b;
      }

      public int size() throws IOException {
	 return (int) file.length();
      }

      public void close() throws IOException {
	 file.close();
      }
   }
}
