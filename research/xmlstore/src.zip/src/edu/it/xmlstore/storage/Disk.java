package edu.it.xmlstore.storage;

import java.io.IOException;
import java.util.Set;
import edu.it.xmlstore.ValueReference;

/**
 * A simple definition of a storage area that saves values and
 * retrieves them. Clients have no control over where or how the value
 * is stored and can only retrieve it using a similar ValueReference.
 * Values are byte arrays
 */
public interface Disk {
   public void save(byte[] value, ValueReference ref) throws IOException;
   public byte[] load(ValueReference ref) throws IOException;
   public boolean delete(ValueReference ref);
   public boolean contains(ValueReference ref);
   public Set getKeySet();
   public void close() throws IOException;
}
