package edu.it.xmlstore.storage;

import edu.it.xmlstore.ValueReference;
import edu.it.xmlstore.ValueUtil;
import java.io.IOException;
import java.io.File;
import java.io.BufferedOutputStream;
import java.io.BufferedInputStream;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FilenameFilter;
import java.util.HashMap;
import java.util.Set;
import edu.it.xmlstore.ValueReference;

/**
 * A simple implementation of Disk that saves a value
 * in a file of its own. Not very efficient but very simple.
 *
 */
public class MultiFileDisk implements Disk {
   /** The directory where the files are stored */
   private File directory;

   // Maps value references to file names (the file where the value is stored).
   private HashMap values;

   /** file handling attributes */
   private static String FILE_PREFIX = "xml";
   private static String FILE_SUFFIX = "fragment.txt";
   private FilenameFilter filter =
                     new FilenameFilter () {
                        public boolean accept(File dir, String name) {
                           return dir.equals(directory) &&
                                  name.startsWith(FILE_PREFIX) &&
                                  name.endsWith(FILE_SUFFIX);
                        }
                     };


   /**
    * Constructor: Creates a MultiFileDisk
    * @param directory the directory which values are saved
    */
   public MultiFileDisk(String directory) {
      // initialize hashmap to remember stored values
      values = new HashMap();

      // Note the place the files should be stored
      // and initialize it
      this.directory = new File(directory);
      initializeDirectory();
   }


   /**
    * Initialize the directory in which the values are stored.
    * 1. Make sure it exists
    * 2. If it exists make sure the values inside are loaded
    */
   private void initializeDirectory() {
      // make sure the directory exists
      if (!directory.exists()) {
         directory.mkdirs();
      }
      else {
         // Check the directory for previously stored values
         File[] files = directory.listFiles(filter);
         byte[] value = null;

         for (int i = 0; i < files.length; i++) {
            try {
               value = loadFile(files[i]);
            } catch (IOException e) {
               // skip this file if it could not load
               continue;
            }
            ValueReference ref = ValueUtil.getValueReference(value);

            if (!values.containsKey(ref))
               values.put(ref, files[i]);
         }
      }
   }


   /**
    * Saves a value (an array of bytes)
    * @param value the value that is to be saved
    * @returns the value reference
    */
   public void save(byte[] value, ValueReference ref) throws IOException {
      // Store the value if it is not already stored on disk
      if (!values.containsKey(ref)) {
         File file;
         try {
            file = File.createTempFile(FILE_PREFIX, FILE_SUFFIX, directory);
            BufferedOutputStream out = new BufferedOutputStream(
                                                   new FileOutputStream(file));
            out.write(value);
            out.close();
         }
         catch (FileNotFoundException e) {
            throw new IOException("Could not find file: " + e);
         }
         catch (IOException e) {
            throw new IOException("Could not open file: " + e);
         }

         values.put(ref, file);
      }
   }


   /**
    * Loads a value given a value reference
    * @param ref
    * @returns the value
    */
   public byte[] load(ValueReference ref) throws IOException {
      // Load the value if it is stored on the disk
      if (!values.containsKey(ref))
         throw new IOException("Could not load value " + ref + " in " +
                               directory);
      else {
         File file = (File)values.get(ref);
         return loadFile(file);
      }
   }


   /**
    * Loads the contents of a given file as a byte array
    */
   private byte[] loadFile(File file) throws IOException {
      byte[] buf = null;
      try {
         buf = new byte[(int)file.length()];
         BufferedInputStream in = new BufferedInputStream(
                                       new FileInputStream(file));
         in.read(buf);
         in.close();
      }
      catch (FileNotFoundException e) {
         throw new IOException("Could not find file: " + file);
      }
      catch (IOException e) {
         throw new IOException("Could not open file: " + file);
      }
      return buf;
   }


   /**
    * Deletes a value given its value reference
    * @param ref
    */
   public boolean delete(ValueReference ref) {
      boolean deleted = false;
      if (values.containsKey(ref)) {
         File file = (File)values.remove(ref);
         deleted = file.delete();
      }
      return deleted;
   }


   public boolean contains(ValueReference ref) {
      return values.containsKey(ref);
   }

   public Set getKeySet() {
      return values.keySet();
   }

   public void close() {
      // we don't need to do anything...
   }
}
