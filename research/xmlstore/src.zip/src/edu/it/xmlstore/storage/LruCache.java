package edu.it.xmlstore.storage;

import edu.it.xmlstore.ValueReference;
import java.util.HashMap;
import java.util.LinkedList;
import edu.it.xmlstore.ValueReference;

/**
 * Simple implementation of the Cache interface.
 * Uses LRU strategy to determine which values should
 * be deleted when cache is filing up.
 */
public class LruCache implements Cache {

   // Helper class
   private static class CacheEntry {
      final byte[] value;
      final ValueReference ref;

      CacheEntry(ValueReference ref, byte[] value) {
         this.value = value;
         this.ref = ref;
      }
   }

   /**
    * We need to datastructures: One to keep entries sorted by time
    * and one to keep track of the cached entries
    */
   private LinkedList timeline; // sorted by time
   private HashMap entries; // indexed by value ref
   private int maxsize;


   /**
    * Constructor: Creates a LruCache
    * @param directory the directory which values are saved
    */
   public LruCache(int maxsize) {
      if (maxsize <= 0)
         throw new RuntimeException("Size must be greater than zero");

      this.maxsize = maxsize;
      timeline = new LinkedList();
      entries = new HashMap(maxsize);
   }


   public void put(byte[] value, ValueReference ref) {
      // only add value once
      if ( !entries.containsKey(ref) )
         addEntry(new CacheEntry(ref, value));
   }


   private void addEntry(CacheEntry entry) {
      // add new entry to both data structures
      entries.put(entry.ref, entry);
      timeline.addFirst(entry);

      // make sure cache is the right size
      if (timeline.size() > maxsize) {
         // Remove entry from both structures
         CacheEntry old = (CacheEntry)timeline.removeLast();
         entries.remove(old.ref);
      }
   }


   public byte[] get(ValueReference ref) {
      if( entries.containsKey(ref) ) {
         CacheEntry entry = (CacheEntry)entries.get(ref);
         refresh(entry);
         return entry.value;
      } else
         throw new RuntimeException("Value is not in cache");
   }


   // note that entry is the most recently used by moving it to the front
   // of the list.
   private void refresh(CacheEntry entry) {
      timeline.remove(entry); // this is an expensive operation O(n)!
      timeline.addFirst(entry);
   }


   public boolean contains(ValueReference ref) {
      return entries.containsKey(ref);
   }
}
