package edu.it.xmlstore;

public class PushBackTokenizer extends java.util.StringTokenizer {
   private boolean _pushBack = false; // are we pushed back?

   private String _currentToken = null;

   /**
   * Create a new StringTokenizer that allows for push back.
   */
   public PushBackTokenizer(String s, String tokens, boolean return_tokens) {
      super(s, tokens, return_tokens);
   }

   /**
   * The next token to be read will
   * be the current token
   */

   public synchronized void pushBack() {
      _pushBack = true;
   }

   /**
   * Does this tokenizer contain any more
   * tokens?
   */
   public synchronized boolean hasMoreTokens() {
      if (_pushBack) {
         return true;
      }
      else {
         return super.hasMoreTokens();
      }
   }

   /**
   * Does this tokenizer have any more elements?
   */
   public synchronized boolean hasMoreElements() {
      if (_pushBack) {
         return true;
      }
      else {
         return super.hasMoreElements();
      }
   }

   /**
   * Retrieve the next token from this
   * tokenizer.
   */
   public synchronized String nextToken() {
      if (_pushBack) {
         _pushBack = false;
         return _currentToken;
      }
      else {
         _currentToken = super.nextToken();

         return _currentToken;
      }
   }
}