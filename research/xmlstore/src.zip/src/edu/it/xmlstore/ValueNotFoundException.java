package edu.it.xmlstore;

import edu.it.xmlstore.rpc.RemoteException;

public class ValueNotFoundException extends RemoteException {
   public ValueNotFoundException(String message) {
      super(message);
   }
}