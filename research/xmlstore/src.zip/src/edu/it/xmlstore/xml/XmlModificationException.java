package edu.it.xmlstore.xml;

/**
 * Exception thrown when an error occurs during manipulation of an XML tree.
 * Typical causes are syntax error in the XPath expression.
 */
public class XmlModificationException extends Exception {
   public XmlModificationException(String message) {
      super(message);
   }
}
   