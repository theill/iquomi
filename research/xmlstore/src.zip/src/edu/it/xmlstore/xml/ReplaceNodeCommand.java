package edu.it.xmlstore.xml;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * Helper class for the method addNode in the utility class XmlHome.
 * Implements the command design pattern.
 */
public class ReplaceNodeCommand implements ModifyCommand {

   /** The node that will be added.*/
   private Node newChild;

   /** the node that will be replaced with the newChild.*/
   private Node oldChild;

   /** Constructor */
   public ReplaceNodeCommand(Node oldChild, Node newChild) {
      this.oldChild = oldChild;
      this.newChild = newChild;
   }

   /**
    * Replaces the child node oldChild with newChild in the list of children.
    * newChild will replace every occurrence of refChild.
    * @param element the parent node.
    * @returns a new tree where new oldChild is replaced by newChild.
    */
   public Node execute(Node element) {
      int index = element.getChildNodes().indexOf(oldChild);
      if (index > -1)
         return Element.createElement(element.getValue(),
                  element.getChildNodes().replaceChild(newChild, oldChild));
      else
         return element;
   }
}