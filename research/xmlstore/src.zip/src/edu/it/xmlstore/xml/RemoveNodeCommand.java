package edu.it.xmlstore.xml;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * Helper class for the method addNode in the utility class XmlHome.
 * Implements the command design pattern.
 */
public class RemoveNodeCommand implements ModifyCommand {

   /** The node that will be removed.*/
   private Node oldChild;

   /** Constructor */
   public RemoveNodeCommand(Node oldChild) {
      this.oldChild = oldChild;
   }

   /**
    * Removes a child node from a node. If oldChild is not in the list of
    * children then the node itself is returned, so that it can be shared.
    * The method compares references. This means that all children equal to
    * oldChild will be removed from the list of children.
    * @param element the node will have one of its children removed.
    * @returns a new tree where oldChild is missing.
    */
   public Node execute(Node element) {
      int index = element.getChildNodes().indexOf(oldChild);
      if (index > -1)
         return Element.createElement(element.getValue(),
               element.getChildNodes().delete(oldChild));
      else
         return element;
   }
}