package edu.it.xmlstore.xml;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * Helper class for the method addNode in the utility class XmlHome.
 * Implements the command design pattern.
 */
public class AddNodeCommand implements ModifyCommand {

   /** The node that will be added.*/
   private Node newChild;

   /** Constructor */
   public AddNodeCommand(Node newChild) {
      this.newChild = newChild;
   }


   /**
    * Adds a node to the end of the list of children of an element.
    * @param element the element that will get a new child.
    * @returns a new element where newChild is added.
    */
   public Node execute(Node element) {
      return Element.createElement(
                     element.getValue(),
                     element.getChildNodes().append(newChild));
   }
}