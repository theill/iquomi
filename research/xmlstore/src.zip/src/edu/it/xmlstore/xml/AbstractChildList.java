package edu.it.xmlstore.xml;

import edu.it.xmlstore.ValueReference;

/**
 * Abstract class that implements the methods that are independent of the
 * data struture of the Child List.
 */
public abstract class AbstractChildList implements ChildList {

   public abstract int size();
   public abstract Node get(int index);
   public abstract ValueReference getValueReference(int index);

   public abstract ChildList delete(int i);
   public abstract ChildList insert(Node n, int i);

   public int indexOf(Node n) {
      Iterator it = iterator();
      int result = -1;
      int pos = 0;
      while (it.hasNext()) {
         if (it.next().equals(n))
            result = pos;
         pos++;
      }
      return result;
   }


   public ChildList append(Node n) {
      return insert(n, size());
   }


   public ChildList insertBefore(Node newChild, Node refChild) {
      return insert(newChild, indexOf(refChild));
   }


   public ChildList replaceChild(Node newChild, Node oldChild) {
      int index = indexOf(oldChild);
      if (!(index > -1)) throw new RuntimeException("Element not found " +
                                                    "while replacing");
      return delete(index).insert(newChild, index);
   }


   public ChildList delete(Node n) {
      int index = indexOf(n);
      return index > -1 ? delete(index) : this;
   }


   public ChildList.Iterator iterator() {
      return new ChildList.Iterator() {
         private int i = 0;
         public boolean hasNext() {return i < size();}
         public Node next() {return get(i++);}
      };
   }


   public boolean equals(Object other) {
      if (other instanceof ChildList) {
         ChildList that = (ChildList)other;
         if (this.size() == that.size()) {
            for (int i = 0; i < this.size(); i++)
               if ( !this.getValueReference(i).equals(
                     that.getValueReference(i)) )
                  return false;

            return true; // if we are here everyting is fine...
         }
      }
      return false;
   }

   public boolean equalsContents(ChildList other) {
      ChildList that = (ChildList)other;
      if (this.size() == that.size()) {
         for (int i = 0; i < this.size(); i++)
            if ( !this.get(i).equalsContents(
                  that.get(i)) )
               return false;

         return true; // if we are here everyting is fine...
      }
      else
         return false;
      
   }


   // return a string representation of this element.
   public String getValue() {
      StringBuffer result = new StringBuffer();
      Iterator it = iterator();
      boolean hasNext;
      while (hasNext = it.hasNext()) {
         result.append(it.next().getValue());
         if (hasNext)
            result.append("\n");
      }
      return result.toString();
   }


   public static ChildList create(Node[] nodes) {
      return new RbTreeChildList(nodes);
   }


   // make it easy to use Collection api to collect children
   public static ChildList create(java.util.Collection c) {
      Node[] nodes = new Node[c.size()];
      java.util.Iterator iterator = c.iterator();
      int i = 0;

      while(iterator.hasNext()) {
         Object o = iterator.next();
         // *** This is a typed list ***
         // -- we have to make sure things have the correct type!
         try {
            nodes[i++] = (Node)o;
         }
         catch (ClassCastException e) {
            throw new RuntimeException("Only objects of Class Node are " +
                                       "valid children, not Class " +
                                       o.getClass());
         }
      }
      return create(nodes);
   }
}