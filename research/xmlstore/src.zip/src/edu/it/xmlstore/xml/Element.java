package edu.it.xmlstore.xml;

import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.WeakHashMap;
import java.util.Map;
import java.util.Arrays;
import java.io.IOException;
import java.lang.ref.SoftReference;

import edu.it.xmlstore.storage.*;
import edu.it.xmlstore.ValueReference;
import edu.it.xmlstore.ValueUtil;
import edu.it.xmlstore.rpc.RemoteException;
import edu.it.xmlstore.XmlStoreHome;
import edu.it.xmlstore.XmlStoreServer;
import edu.it.xmlstore.xml.FileLoader;

/**
 * Class representing an XML element, that is a tag possibly with children
 * in the form of other tags and character data
 */
public class Element implements Node {

   // ==== Static fields and methods ====
   static private Map values = new WeakHashMap(128);

   public static Element createElement(String name, Node[] children) {
      return createElement(name, AbstractChildList.create(children));
   }

   public static Element createElement(String name, ChildList children) {
      // Convert element to byte representation
      byte[] bytes = elementToBytes(name, children);
      ValueReference ref = ValueUtil.getValueReference(bytes);
      Element elt;
      if (values.containsKey(ref))
         elt = (Element)values.get(ref);
      else {
         elt = new Element(name, ref, children, bytes);
         values.put(ref, elt);
      }
      return elt;      
   }


   public static Element createElementFromFile(String filename)
                                                           throws IOException {
      return ( (Element) new FileLoader().parse(filename) );
   }


   private static byte[] elementToBytes(String name, ChildList childList) {
      // build byte[] representation of element
      int defaultSize = 1024;
      StringBuffer elementAsString = new StringBuffer(defaultSize);
      elementAsString.append('<')
                     .append(String.valueOf(ELEMENT))
                     .append('>')
                     .append(name);

      // recurse through children
      ChildList.Iterator children = childList.iterator();
      while(children.hasNext()) {
	 Node child = children.next();
	 byte[] bytes = child.getBytes();

	 // If child is very small then inline it...
	 if (bytes.length <= MINIMUM_NODE_SIZE)
	    elementAsString.append('<').append(new String(bytes)).append('>');
	 // ... otherwise include a reference to it
	 else	  
	    elementAsString.append('<').append(child.getValueReference()).append('>');
      }

      return elementAsString.toString().getBytes();
   }


   // ==== Dynamic fields and methods ====
   private final String name;
   private ChildList children;
   private final ValueReference valueRef;
   private boolean isSaved;
   private SoftReference asBytes; // Make sure byte representation can be gc'ed

   private Element(String name, ValueReference valueRef, ChildList children, byte[] b) {
      this.name = name;
      this.valueRef = valueRef;
      this.children = children;
      this.asBytes = new SoftReference(b);
      isSaved = false;
   }

   public short getType() {
      return ELEMENT;
   }

   public String getValue() {
      return name;
   }

   public ChildList getChildNodes() {
      return children;
   }

   public boolean equals(Object that) {
      return that instanceof Node
             && getValueReference().equals( ((Node)that).getValueReference() );
   }

   public boolean equalsContents(Object other) {
      boolean result = false;
      if (other instanceof Element) {
         // Check name
         Element that = (Element)other;
         result = this.name.equals(that.getValue());

         // Check children
         if(!result)         
            result = this.children.equalsContents(that.getChildNodes());

      }
      return result;
   }

   public ValueReference getValueReference() {
      return valueRef;
   }

   public void accept(NodeVisitor visitor) {
      visitor.visitElement(this);
   }

   // byte rep might have been gc'ed
   public byte[] getBytes() {
      Object o = asBytes.get();
      if (o != null)
	 return (byte[]) o;
      else
	 return elementToBytes(name, children);
   }

   public boolean isSaved() {
      return isSaved;
   }

   public void markAsSaved() {
      isSaved = true;
   }

   public String asString() {
      return asString(0);
   }

   public String asString(int tab) {
      StringBuffer element = new StringBuffer();
      StringBuffer tabs = new StringBuffer();
      for(int i = 0; i < tab; i++)
         tabs.append("\t");
      element.append(tabs).append("<").append(name).append(">");

      for(int i = 0; i < children.size(); i++)
         element.append("\n").append( children.get(i).asString(tab+1));

      element.append("\n").append(tabs).append("</").append(name).append(">");

      return element.toString();
   }
}
