package edu.it.xmlstore.xml;

import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.regex.Pattern;
import java.lang.ref.SoftReference;

import edu.it.xmlstore.storage.*;
import edu.it.xmlstore.ValueReference;
import edu.it.xmlstore.ValueUtil;
import edu.it.xmlstore.rpc.RemoteException;

/**
 * Class representing character data contained in an XML element.
 */
public class CharData implements Node {
   // ==== Static fields and methods ====
   // this 'dummy' empty list is returned as children upon request.
   private static final ChildList noChildren =
      new AbstractChildList() {
         public Node get(int index)
               {throw new RuntimeException("No children in CharData");}
         public ValueReference getValueReference(int index)
               {throw new RuntimeException("No children in CharData");}
         public ChildList delete(int i)
               {throw new RuntimeException("No children in CharData");}
         public ChildList insert(Node n, int i)
               {throw new RuntimeException("No children in CharData");}
         public int size() {return 0;}
         public Iterator iterator(){
            return new Iterator() {
               public boolean hasNext(){return false;}
               public Node next(){throw new RuntimeException("No children in" +
                                                             "CharData");}
            };
         }
      };

   // this Map keeps track of already created instances.
   static private Map values = new WeakHashMap(128);

   public static CharData createCharData(String data) {
      data = replaceIllegalChars(data);
      byte[] b = charDataToBytes(data);
      ValueReference ref = ValueUtil.getValueReference(b);
      CharData result;
      if (values.containsKey(ref))
         result = (CharData)values.get(ref);
      else {
         result = new CharData(data, ref, b);
         values.put(ref, result);
      }
      return result;
   }

   private static byte[] charDataToBytes(String data) {
      // build byte[] representation of CharData
      int size = data.length() + 3; // 3 = '<2>'
      StringBuffer dataAsString = new StringBuffer(size);
      dataAsString.append('<')
                  .append(String.valueOf(Node.CHARDATA))
                  .append('>')
                  .append(data);
      return dataAsString.toString().getBytes();
   }

   // Regular expressions for escaping illegal markup in XML char data sections
   private static Pattern lessThan = Pattern.compile("<");
   private static Pattern greaterThan = Pattern.compile(">");
   private static Pattern ampersand = Pattern.compile("&");

   private static String replaceIllegalChars(String s) {
      // remember to start with & -- otherwise it will mess up
      // previous replacements.
      s = ampersand.matcher(s).replaceAll("&amp;");
      s = lessThan.matcher(s).replaceAll("&lt;");
      s = greaterThan.matcher(s).replaceAll("&gt;");
      return s;
   }

   // Dynamic methods and data
   private final String data;
   private ValueReference valueRef;
   private boolean isSaved;
   private SoftReference asBytes; // Make sure byte representation can be gc'ed

   private CharData(String data, ValueReference valueRef, byte[] b) {
      this.valueRef = valueRef;
      this.data = data;
      this.asBytes = new SoftReference(b);
      isSaved = false;
   }

   public String getValue() {
      return data;
   }

   public short getType() {
      return CHARDATA;
   }

   public boolean equals(Object that) {
      return that instanceof Node
             && getValueReference().equals( ((Node)that).getValueReference() );
   }

   public boolean equalsContents(Object that) {
      return that instanceof CharData &&
             data.equals( ((CharData)that).getValue() );
   }

   public ChildList getChildNodes() {
      return noChildren;
   }

   public ValueReference getValueReference() {
      return valueRef;
   }

   // byte rep might have been gc'ed
   public byte[] getBytes() {
      Object o = asBytes.get();
      if (o != null)
	 return (byte[]) o;
      else
	 return charDataToBytes(data);
   }

   public void accept(NodeVisitor visitor) {
      visitor.visitCharData(this);
   }

   public boolean isSaved() {
      return isSaved;
   }

   public void markAsSaved() {
      isSaved = true;
   }

   public String asString() {
      return asString(0);
   }

   public String asString(int tab) {
      StringBuffer charData = new StringBuffer();
      for(int i = 0; i < tab; i++)
         charData.append("\t");
      charData.append(data);
      return charData.toString();
   }
}
