package edu.it.xmlstore.xml;

import edu.it.xmlstore.ValueReference;
import edu.it.xmlstore.rpc.RemoteException;
import edu.it.xmlstore.XmlStoreServer;
import edu.it.xmlstore.XmlStoreHome;
import java.util.Arrays;
import java.util.Collection;

/**
  A child list represented as a red/black tree.
 */
public class RbTreeChildList extends AbstractChildList {

   private final TreeNode root;


   private RbTreeChildList() {
      root = TreeNode.LEAF;
   }


   public RbTreeChildList(Node[] children) {
      root = TreeNode.buildFromList(children, 0, children.length);
   }


   public RbTreeChildList(TreeNode root) {
      this.root = root;
   }


   public Node get(int index) {
      assert index >= 0 && index < size() : "Index out of bounds: ["
                                            + index + "].";
      // remember to add one to index
      // (order statistics selects from 1..n, we index from 0..n-1)
      return TreeNode.select(root, index + 1).node;
   }


   public ValueReference getValueReference(int index) {
      assert index >= 0 && index < size() : "Index out of bounds: ["
                                            + index + "].";
      // remember to add one to index
      // (order statistics selects from 1..n, we index from 0..n-1
      return TreeNode.select(root, index + 1).node.getValueReference();
   }


   public int size() {
      return root.size;
   }


   public ChildList.Iterator iterator() {
      // FIXME: consider making this more efficient
      // by inorder traversing the tree using a stack to remember
      // parents...
      return new ChildList.Iterator() {
         private int i = 0;
         public boolean hasNext() {return i < size();}
         public Node next() {return get(i++);}
      };
   }


   public ChildList delete(int index) {
      assert index >= 0 && index < size() : "Index out of bounds: [" +
                                            index + "].";
      // remember to add one to index
      // (order statistics selects from 1..n, we index from 0..n-1
      return new RbTreeChildList(TreeNode.delete(root, index + 1));
   }


   public ChildList insert(Node newNode, int index) {
      assert index >= 0 && index <= size() : "Index out of bounds: [" +
                                             index + "].";
      // remember to add one to index
      // (order statistics selects from 1..n, we index from 0..n-1
      return new RbTreeChildList(TreeNode.insert(root, newNode, index + 1));
   }


   public boolean rbcheck() {
      boolean result = true;
      try {
         TreeNode.rbcheck(root);
      }
      catch (RuntimeException e) {
         result = false;
         System.err.println("Error in RbChildList: " + e);
         System.err.println("\n" + toString());
      }
      return result;
   }


   public String toString() {
      return root.toString();
   }


   // ********************************************************************

   // Inner class representing a child as a node in a red/black tree.
   private static class TreeNode {
      // size represents the size of both subtrees and myself
      // used to support order statistic operations (to find the i'th node)
      // CLR chapter 15
      public final int size;
      public final TreeNode left;
      public final TreeNode right;
      public final Node node;
      public final boolean color;

      public static final boolean RED = true;
      public static final boolean BLACK = false;

      // LEAF is a sentinel node
      private final static TreeNode LEAF = new TreeNode();


      // this constructor is *only* to create LEAF
      private TreeNode() {
         size = 0;
         left = this;
         right = this;
         node = null;
         color = BLACK;
      }


      private TreeNode(Node node, boolean color, TreeNode left,
                       TreeNode right) {
         this.size = left.size + right.size + 1;
         this.node = node;
         this.color = color;
         this.left = left;
         this.right = right;
      }


      public static TreeNode create(Node node, boolean color, TreeNode left,
                                    TreeNode right) {
         return new TreeNode(node, color, left, right);
      }


      public static TreeNode buildFromList(Node[] children, int from, int to) {
         TreeNode temp = LEAF;
         for (int i = 0; i < children.length; i++)
            temp = TreeNode.insert(temp, children[i], i+1);

         return temp;
      }


      // We always use the third clause in C. Okasaki '93, because we know that
      // the element is to be appended at the end and as such is "larger" than
      // all other elements in the tree
      private static TreeNode app(TreeNode n, Node newNode) {
         if (n == LEAF) {
            return create(newNode, RED, LEAF, LEAF);
         } else {
            return balance( create(n.node, n.color, n.left,
                            app(n.right, newNode)) );
         }
      }


      private static TreeNode makeBlack(TreeNode t) {
         return t.color == BLACK ? t : create(t.node, BLACK, t.left, t.right);
      }


      // The following methods have been adapted from code by P. Sestoft.
      public static void rbcheck(TreeNode root) { // check rb invariants
         if (root.color == RED)
	         throw new RuntimeException("root is not black");
         else
	         if (rbchk(root.left, false) != rbchk(root.right, false))
	            throw new RuntimeException("black-depth invariant violated");
      }


      // return black-depth
      private static int rbchk(TreeNode t, boolean redparent) {
         if (t == LEAF)
            return 1;
         else if (t.color == RED && redparent)
            throw new RuntimeException("red node has red parent");
         else {
            int ldepth = rbchk(t.left, t.color == RED);
            int rdepth = rbchk(t.right, t.color == RED);
            if (ldepth == rdepth)
               return t.color == RED ? ldepth : 1 + ldepth;
            else
               throw new RuntimeException("black-depth invariant violated");
         }
      }
      // end code by P. Sestoft


      // The balance method is inspired by C. Okasaki, 1993
      // -- "RB Trees in a Functional Setting"
      // except for ugly non-pattern-matching syntax.
      private static TreeNode balance(TreeNode t) {

         if (t.color == BLACK) {
            if (t.left.color == RED && t.left.left.color == RED)
               return
                  create(t.left.node, RED,
                    create(t.left.left.node, BLACK, t.left.left.left,
                           t.left.left.right),
                    create(t.node, BLACK, t.left.right, t.right));

            else if (t.left.color == RED && t.left.right.color == RED)
               return
                  create(t.left.right.node, RED,
                    create(t.left.node, BLACK, t.left.left, t.left.right.left),
                    create(t.node, BLACK, t.left.right.right, t.right));
            else if (t.right.color == RED && t.right.left.color == RED)
               return
                  create(t.right.left.node, RED,
                    create(t.node, BLACK, t.left, t.right.left.left),
                    create(t.right.node, BLACK, t.right.left.right,
                           t.right.right));

            else if (t.right.color == RED && t.right.right.color == RED)
               return
                  create(t.right.node, RED,
                    create(t.node, BLACK, t.left, t.right.left),
                    create(t.right.right.node, BLACK, t.right.right.left,
                                                         t.right.right.right));

         }
         // otherwise just return t
         return t;
      }


      // Find the i'th node in the tree with root x
      // Based on CLR page 282, OS-Select(x, i), OS ="order statistic"
      public static TreeNode select(TreeNode x, int i) {
         int r = x.left.size + 1;
         if (i == r) return x;
         else
            if (i < r) return select(x.left, i);
            else       return select(x.right, i-r);
      }


      // Insert node newNode at position i in the tree with root x
      // Based on CLR page 282, OS-Select(x, i), OS ="order statistic"
      // and C. Okasaki, 1993 "Red Black Trees in a Functional Setting"
      public static TreeNode insert(TreeNode x, Node newNode, int i) {
         return makeBlack(ins(x, newNode, i));
      }


      private static TreeNode ins(TreeNode t, Node x, int i) {
         if (t == LEAF) return create(x, RED, LEAF, LEAF);
         else {
            int r = t.left.size + 1;
            if (i == r) // we found the place to insert
               return balance(create(t.node, t.color, app(t.left, x), 
                              t.right));
            else
               if (i < r)
                  return balance(create(t.node, t.color,
                                 ins(t.left, x, i), t.right));
               else
                  return balance(create(t.node, t.color, t.left,
                                 ins(t.right, x, i-r)));
         }
      }


      // delete and associated methods are based on Stefan M. Kahrs functional
      // red-black tree delete operation
      public static TreeNode delete(TreeNode t, int i) {
         return makeBlack(del(t, i));
      }


      private static TreeNode del(TreeNode t, int i) {
         if (t == LEAF) return LEAF;
         int r = t.left.size + 1;
         if (i == r) return appendTree(t.left, t.right);
         else
            if (i < r) return delFormLeft(t, i);
            else       return delFormRight(t, i-r);
      }


      private static TreeNode delFormRight(TreeNode t, int i) {
         if (t.right.color == BLACK)
            return balRight( t.left, t.node, del(t.right, i));
         else
            return create( t.node, RED, t.left, del(t.right,i));
      }


      private static TreeNode delFormLeft(TreeNode t, int i) {
         if (t.left.color == BLACK)
            return balLeft( del(t.left, i), t.node, t.right);
         else
            return create( t.node, RED, del(t.left, i), t.right);
      }


      private static TreeNode balLeft(TreeNode x, Node n, TreeNode y) {
         if (x.color == RED)
            return create(n, RED, create(x.node, BLACK, x.left, x.right), y);
         else if (y.color == BLACK)
            return balance(create(n, BLACK, x, create(y.node, RED, y.left,
                                  y.right)));
         else if (y.color == RED && y.left.color == BLACK)
            return create(y.left.node, RED,
                     // left child
                     create(n, BLACK, x, y.left.left),
                     // right child: BLACK as above
                     balance(create(y.node, BLACK, y.left.right,
                             sub1(y.right))));
         else
           throw new RuntimeException("balLeft failed miserably");
      }


      private static TreeNode balRight(TreeNode x, Node n, TreeNode y) {
         if (y.color == RED)
            return create(n, RED, x, create(y.node, BLACK, y.left, y.right));
         else if (x.color == BLACK)
            return balance(create(n, BLACK, create(x.node, RED, x.left,
                                  x.right), y));
         else if (x.color == RED && y.right.color == BLACK)
            return create(x.right.node, RED,
                     // left child: BLACK as above
                     balance(create(x.node, BLACK, sub1(x.left), 
                                    x.right.left)),
                     // right child
                     create(n, BLACK, x.right.right, y));
         else
           throw new RuntimeException("balRight failed miserably");
      }


      private static TreeNode appendTree(TreeNode x, TreeNode y) {
         if (x == LEAF) return y;
         else if (y == LEAF) return x;
         else {
            // case 1
            if (x.color == RED && y.color == RED) {
               TreeNode result = appendTree(x.right, y.left);
               if (result.color == RED)
                  return create(result.node, RED,
                           create(x.node, RED, x.left, result.right),
                           create(y.node, RED, result.left, y.right));
               else
                  return create(x.node, RED, x.left,
                           create(y.node, RED, result, y.right));
            }
            // case 2
            else if (x.color == BLACK && y.color == BLACK) {
               TreeNode result = appendTree(x.right, y.left);
               if (result.color == RED)
                  return create(result.node, RED,
                           create(x.node, BLACK, x.left, result.right),
                           create(y.node, BLACK, result.left, y.right));
               else
                  return balLeft(x.left, x.node, create(y.node, BLACK, result,
                                                        y.right));
            }
            // case 3
            else if (y.color == RED)
               return create(y.node, RED, (appendTree(x, y.left)),y.right);
            // case 4
            else if (x.color == RED)
               return create(x.node, RED, x.left, appendTree(x.right, y));

            else
               throw new RuntimeException("appendTree failed miserably");
         }
      }


      private static TreeNode sub1(TreeNode x) {
         if (x.color == BLACK) return create(x.node, RED, x.left, x.right);
         else throw new RuntimeException("Invariance violation");
      }


      public String toString() {
         String col = color == RED ? "R" : "B";
         String nod = node == null ? "null" : node.getValue();
         if (this == LEAF) return "LEAF";
         else return nod + " " + col + " [" + left + "," + right + "]";
      }
   } // end inner class
}