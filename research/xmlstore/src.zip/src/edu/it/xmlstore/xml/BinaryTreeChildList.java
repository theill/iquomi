package edu.it.xmlstore.xml;

import edu.it.xmlstore.ValueReference;
import edu.it.xmlstore.rpc.RemoteException;
import edu.it.xmlstore.XmlStoreServer;
import edu.it.xmlstore.XmlStoreHome;
import java.util.Arrays;
import java.util.Collection;

/**
 * A child list represented as a binary tree.
 */
public class BinaryTreeChildList extends AbstractChildList {

   private final TreeNode root;

   private BinaryTreeChildList() {
      root = TreeNode.LEAF;
   }


   public BinaryTreeChildList(Node[] children) {
      root = TreeNode.buildFromList(children, 0, children.length);
   }


   public BinaryTreeChildList(TreeNode root) {
      this.root = root;
   }


   public Node get(int index) {
      assert index >= 0 && index < size() : "Index out of bounds: [" +
                                            index + "].";
      // remember to add one to index
      // (order statistics selects from 1..n, we index from 0..n-1
      return TreeNode.select(root, index + 1).node;
   }


   public ValueReference getValueReference(int index) {
      assert index >= 0 && index < size() : "Index out of bounds: [" +
                                            index + "].";
      // remember to add one to index
      // (order statistics selects from 1..n, we index from 0..n-1
      return TreeNode.select(root, index + 1).node.getValueReference();
   }


   public int size() {
      return root.size;
   }


   public ChildList.Iterator iterator() {
      return new ChildList.Iterator() {
         private int i = 0;
         public boolean hasNext() {return i < size();}
         public Node next() {return get(i++);}
      };
   }


   public ChildList delete(int i) {
      // remember to add one to index
      // (order statistics selects from 1..n, we index from 0..n-1
      return new BinaryTreeChildList(TreeNode.delete(root, i + 1));
   }


   public ChildList insert(Node newNode, int index) {
      // remember to add one to index
      // (order statistics selects from 1..n, we index from 0..n-1
      return new BinaryTreeChildList(TreeNode.insert(root, newNode, index + 1));
   }


   public String toString() {
      return root.toString();
   }


   private static class TreeNode {
      // size represents the size of both subtrees and myself.
      // used to support order statistic operations
      // (to find the i'th node in the tree).
      // see CLR chapter 15.
      public final int size;
      public final TreeNode left;
      public final TreeNode right;
      public final Node node;

      // LEAF is a sentinel node
      private final static TreeNode LEAF = new TreeNode();

      // this constructor is used *only* for creating LEAF
      private TreeNode() {
         size = 0;
         left = this;
         right = this;
         node = null;
      }


      private TreeNode(Node node, TreeNode left, TreeNode right) {
         this.size = left.size + right.size + 1;
         this.node = node;
         this.left = left;
         this.right = right;
      }


      public static TreeNode create(Node node, TreeNode left, TreeNode right) {
         // FIXME: Use hashed consing perhaps?
         return new TreeNode(node, left, right);
      }


      // standard divide and conquer algorithm to build balanced tree
      public static TreeNode buildFromList(Node[] children, int from, int to) {
         if (from < to) {
            int pivot = (from + to) / 2;
            return create( children[pivot],
                           buildFromList(children, from, pivot),
                           buildFromList(children, pivot + 1, to) );
         }
         else
            return LEAF;
      }


      // Find the i'th node in the tree with root x
      // Based on CLR page 282, OS-Select(x, i), OS ="order statistic"
      public static TreeNode select(TreeNode x, int i) {
         int r = x.left.size + 1;
         if (i == r) return x;
         else
            if (i < r) return select(x.left, i);
            else       return select(x.right, i-r);
      }


      // Insert node newNode at position i in the tree with root x
      // Based on CLR page 282, OS-Select(x, i), OS ="order statistic"
      public static TreeNode insert(TreeNode x, Node newNode, int i) {
         int r = x.left.size + 1;
         if (x == LEAF)
            return create(newNode, LEAF, LEAF);
         else if (i == r)
            return create( newNode, x.left, create(x.node, LEAF, x.right) );
         else
            if (i < r) return create(x.node, insert(x.left, newNode, i),
                                     x.right);
            else return create(x.node, x.left, insert(x.right, newNode, i-r));
      }


      // Delete node at position i in the tree with root x
      // Based on CLR page 282, OS-Select(x, i), OS ="order statistic"
      public static TreeNode delete(TreeNode x, int i) {
         int r = x.left.size + 1;
         if (i == r)
            if (x.right == LEAF)
               return x.left;
            else {
               TreeNode smallestRightChild = select(x.right, 1);
               return create( smallestRightChild.node, x.left,
                              delete(x.right, 1) );
            }
         else
            if (i < r) return create(x.node, delete(x.left, i), x.right);
            else       return create(x.node, x.left, delete(x.right, i-r));
      }


      public String toString() {
         String nod = node == null ? "null" : node.getValue();
         if (this == LEAF) return "LEAF";
         else return "'" + nod + "'[" + left + "," + right + "]";
      }
   } // end inner class
}