package edu.it.xmlstore.xml;

import javax.xml.parsers.SAXParserFactory;
import javax.xml.parsers.SAXParser;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.SAXException;
import org.xml.sax.Attributes;
import java.util.Stack;
import java.util.Vector;
import java.io.StringReader;
import java.io.IOException;
import java.io.File;
import edu.it.xmlstore.xml.*;

 /**
 * Used for converting an XML document stored in a text file
 * to an abstract tree-representation.
 * DefaultHandler extends ContentHandler in SAX and is used to avoid
 * implementing all methods in ContentHandler.
 */
public class FileLoader extends DefaultHandler {

  // private Locator locator;
   private Stack stack;

   /**
    * Parses a file using a SAX parser. When the parser encounters relevant
    * tokens (start/end of elements/document) the corresponding callback
    * methods are called.
    */
   public Node parse(String filename) throws IOException {
      try {
         SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();
         SAXParser parser = saxParserFactory.newSAXParser();
         parser.parse(new File(filename), this);
         return(Node)stack.pop();
      }
      catch (Exception e) {
         throw new IOException("Error in FileLoadVisitor.parse: " + e);
      }
   }


   /**
   * Callback method that is called when the SAX parser encounters
   * the start of the document.
   */
   public void startDocument() {
      stack = new Stack();
   }


   /**
   * Callback method that is called when the SAX parser encounters
   * the beginning of an element, ie. an XML tag
   * @param uri
   * @param localName
   * @param qName
   * @param attributes
   */
   public void startElement(String uri, String localName,
                            String qName, Attributes attributes) {
      stack.push(qName);
   }


   /**
   * Callback method that is called when the SAX parser encounters
   * the end of an element, ie. an XML tag
   * @param uri
   * @param localName
   * @param qName
   * @param attributes
   */
   public void endElement(String namespaceURI, String localName, String qName) {
      Object o = null;
      Vector nestedElements = new Vector();
      for(o = stack.pop(); !o.equals(qName); o = stack.pop())
         nestedElements.add(o);

      // Generate children
      Node[] children = new Node[nestedElements.size()];
      for(int i = 0; i < nestedElements.size(); i++)
         children[i] =
                  (Node)nestedElements.elementAt(nestedElements.size()-i-1);

      stack.push( Element.createElement(qName, children) );
   }


   /**
   * Callback method that is called when the SAX parser encounters
   * character data
   * @param ch
   * @param start
   * @param length
   */
   public void characters(char[] ch, int start, int length) {
      String s = new String(ch, start, length);
      // If the character are not just white spaces.
      if (! s.trim().equals(""))
         stack.push( CharData.createCharData(s.trim()) );
   }

}  