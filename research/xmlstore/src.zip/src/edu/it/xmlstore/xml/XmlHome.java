package edu.it.xmlstore.xml;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import java.util.StringTokenizer;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 * Utility methods for manipulation of an entire XML document. All methods use
 * an abbreviated version of XPath to specify the nodes that should be 
 * modified.
 */
public class XmlHome {

   /** Pattern that specifies a valid XPath expression.*/
   private static Pattern pattern =
      Pattern.compile("((([a-zA-Z]\\w*(\\[[1-9]\\d*\\])?)|\\*)" +
                      "((/[a-zA-Z]\\w*(\\[[1-9]\\d*\\])?)|(/\\*))*)*");

    /**
    * Validates a subset of the XPath specification. The path should match the
    * following pattern:
    * ((([a-zA-Z]\w*(\[[1-9]\d*\])?)|(/\*)))((/[a-zA-Z]\w*(\[[1-9]\d*\])?)|
    * (/\*))*)*
    * @param path the string that is validated against the pattern.
    * @returns true if the path matches the pattern, otherwise false.
    */
   private static boolean checkPath(String path) {
    //return Pattern.matches("((([a-zA-Z]\\w*(\\[[1-9]\\d*\\])?)|\\*)" +
    //                  "((/[a-zA-Z]\\w*(\\[[1-9]\\d*\\])?)|(/\\*))*)*", path);
      Matcher m = pattern.matcher(path);
      return m.matches();
   }


   /**
    * Build a new tree where the node oldChild is missing from the element
    * specified by the path. It builds the tree by recursively traversing the
    * tree, just like tree operations in functional languages.
    * @param root the root of the old tree.
    * @param path the Xpath to the parent of the element that will be removed.
    * @param oldNode the node that will be missing in the new tree.
    * @returns a new tree given by the root of the tree.
    */
   public static Node remove(Node root, String path, Node oldNode)
                                            throws XmlModificationException {
      // Check that the root is an element.
      if (root.getType() != Node.ELEMENT)
         throw new XmlModificationException("The root of the tree must " +
                                            "be of type ELEMENT");
      // Check that the path is valid.
      if (! checkPath(path))
         throw new XmlModificationException("Syntax error in path");

      ModifyCommand removeCommand = new RemoveNodeCommand(oldNode);
      return modify(root, path, removeCommand);
   }


   /**
    * Build a new tree with the new node newChild added to the end of the list
    * of children of the element specified by the path. It builds the tree by
    * recursively traversing the tree, just like tree operations in functional
    * languages.
    * @param root the root of the old tree.
    * @param path the Xpath to the parent of the element that will be removed.
    * @param newNode the node that will be added to the end of the list of
    * children of element.
    * @returns a new tree given by the root of the tree.
    */
   public static Node append(Node root, String path, Node newNode)
                                             throws XmlModificationException {
      // Check that the root is an element.
      if (root.getType() != Node.ELEMENT)
         throw new XmlModificationException("The root of the tree must be of" +
                                            "type ELEMENT");
      // Check that the path is valid.
      if (! checkPath(path))
         throw new XmlModificationException("Syntax error in path");

      ModifyCommand addCommand = new AddNodeCommand(newNode);
      return modify(root, path, addCommand);
   }


   /**
    * Build a new tree with the new node newChild inserted before refNode in
    * the list of children of the element specified by the path. newChild will
    * be inserted before every occurrence of refChild.
    * @param root the root of the old tree.
    * @param path the Xpath to the parent of the element that will be removed.
    * @param refNode the new node will be inserted before this node.
    * @param newNode the node that will be added to the list of children of
    * element.
    * @returns a new tree given by the root of the tree.
    */
   public static Node insertBefore(Node root, String path, Node refNode,
                                Node newNode) throws XmlModificationException {
      // Check that the root is an element.
      if (root.getType() != Node.ELEMENT)
         throw new XmlModificationException("The root of the tree must be of" +
                                            "type ELEMENT");
      // Check that the path is valid.
      if (! checkPath(path))
         throw new XmlModificationException("Syntax error in path");

      ModifyCommand insertNodeCommand =
                              new InsertNodeBeforeCommand(refNode, newNode);
      return modify(root, path, insertNodeCommand);
   }


   /**
    * Build a new tree with the node oldChild replaced by newChild in the list
    * of children of the element specified by the path. newChild will replace
    * every occurrence of refChild.
    * @param element the root of the old tree.
    * @param path the Xpath to the parent of the element that will be removed.
    * @param oldNode the node that will be replaced.
    * @param newNode The new node that will replace the old node.
    * @returns a new tree given by the root of the tree.
    */
   public static Node replace(Node root, String path, Node oldNode,
                                Node newNode) throws XmlModificationException {
      // Check that the root is an element.
      if (root.getType() != Node.ELEMENT)
         throw new XmlModificationException("The root of the tree must be of" +
                                            "type ELEMENT");
      // Check that the path is valid.
      if (! checkPath(path))
         throw new XmlModificationException("Syntax error in path");

      ModifyCommand replaceCommand = new ReplaceNodeCommand(oldNode, newNode);
      return modify(root, path, replaceCommand);
   }


   /**
    * Traverses recursively the tree where element is root and finds the nodes
    * specified by path. When the nodes are found, they are modified by 
    * command.
    * @param element the root of the tree.
    * @param path the XPath to the elements that should be modified.
    * @param command an object that can modify a node.
    */
   private static Node modify(Node element, String path,
                              ModifyCommand command) {
      String tagName, restOfPath;
      int i, indexOfSlash;
      StringTokenizer tokenizer = new StringTokenizer(path,"/[]", true);
      int index = -1; // Default, -1 means that no index is specified.
      ChildList children;

      // Have we reached the end of the path?
      if (path.equals("")) {
         return command.execute(element);
      }
      else {
         // We have not reached the end of the path.
         indexOfSlash = path.indexOf("/");

         // Is there more than one tag name in path.
         if (indexOfSlash != -1) {
            tagName = tokenizer.nextToken();
            // Does the tag name have an index?
            if (tokenizer.nextToken().equals("[")) {
               index = Integer.parseInt(tokenizer.nextToken());
               assert index > 0 : "The position in a node-set starts at one.";
               index--;       // The index in an array start at zero.
            }
            restOfPath = path.substring(indexOfSlash + 1, path.length());
         }
         else {
            // There is only one tag name left in path.
            tagName = tokenizer.nextToken();
             // Does the tag name have an index?
            if (tokenizer.hasMoreTokens()) {
               tokenizer.nextToken(); // This token must be a "[".
               index = Integer.parseInt(tokenizer.nextToken());
               assert index > 0 : "The position in a node-set starts at one.";
               index--;       // The index in an array start at zero.
            }
            restOfPath = "";
         }

         children = element.getChildNodes();
         Node[] newChildren = new Node[children.size()];
         int counter = 0;
         Node tempNode;

         //Create the new list of children.
         for (i = 0; i < children.size(); i++) {
            tempNode = (Node) children.get(i);

            if (tempNode.getType() == Node.CHARDATA)
               newChildren[i] = tempNode;
            else {
               // The node is an element.
               if (tagName.equals("*"))
                  // The * character matches all elements.
                  newChildren[i] = modify(tempNode, restOfPath, command);
               else {
                  if (index == -1) {
                     // The element has no index.
                     if (tempNode.getValue().equals(tagName))
                        // The element matches the path.
                        newChildren[i] = modify(tempNode, restOfPath, command);
                     else
                        newChildren[i] = tempNode;
                  }
                  else {
                     // The element has an index.
                     if (tempNode.getValue().equals(tagName))
                        // The element matches the path.
                        if (counter == index) {
                           newChildren[i] = modify(tempNode, restOfPath,
                                                   command);
                           counter++;
                        }
                        else {
                           // Same tagname but not the right index.
                           newChildren[i] = tempNode;
                           counter++;
                        }
                     else
                        // The element does not match the path.
                        newChildren[i] = tempNode;
                  } // Element has index.
               }  // Tag name != *.
            }  // The node is an element.
         }  // The for-loop.

         return Element.createElement(element.getValue(), newChildren);
      }
   }


   /**
    * Returns the list of elements in a tree where "element" is root that
    * matches the path specified by parameter "path". If no node match the 
    * path, the result set is empty.
    * @param root the root of the XML tree.
    * @path the path that locates the elements.
    * @returns a list of elements that matches the path.
    */
   public static ChildList lookup(Node root, String path)
                                             throws XmlModificationException {
      // Check that the root is an element.
      if (root.getType() != Node.ELEMENT)
         throw new XmlModificationException("The root of the tree must be of" +
                                            "type ELEMENT");
      // Check that the path is valid.
      if (! checkPath(path))
         throw new XmlModificationException("Syntax error in path");

      if (path.equals(""))
         return root.getChildNodes();
      else {
         List result = new ArrayList();
         lookup(root, path, result); // Collect matching elements in result.
         return AbstractChildList.create(result);
      }
   }


   /**
    * Traverses recursively down the tree that has parameter "element" as root.
    * It follows the path specified by the parameter "path" and collects the
    * result in parameter "result. We need to have result as input paramter
    * since we use recursion to traverse the tree.
    * @param element the root of the tree.
    * @param path the path that locates the wanted elements.
    * @param result the list where the result are collected.
    */
   private static void lookup(Node element, String path, List result){
      String tagName, restOfPath;
      int i, indexOfSlash;
      StringTokenizer tokenizer = new StringTokenizer(path,"/[]", true);
      int index = -1; // Default, -1 means that no index is specified.
      ArrayList children;

      indexOfSlash = path.indexOf("/");

      if (indexOfSlash != -1) {
         // The path consists of more than one tag name.
         tagName = tokenizer.nextToken();
         if (tokenizer.nextToken().equals("[")) {
            index = Integer.parseInt(tokenizer.nextToken());
            assert index > 0 : "The position in a node-set starts at one.";
            index--;       // The index in an array start at zero.
         }
         restOfPath = path.substring(indexOfSlash + 1,path.length());

         // Find children that match the tagname in the path.
         children = findChildren(element, tagName, index);

         // Traverse recursively down the tree.
         for (i = 0; i < children.size(); i++)
            lookup((Node)children.get(i), restOfPath, result);
      }
      else {
         // Only one tag name in path. Stop traversing the tree
         // and insert elements in result set.
         tagName = tokenizer.nextToken();
         if (tokenizer.hasMoreTokens()) {
            tokenizer.nextToken(); // This token must be a "[";
            index = Integer.parseInt(tokenizer.nextToken());
            assert index > 0 : "The position in a node-set starts at one.";
            index--;       // The index in an array start at zero.
         }

         // Find children that match the tagname in the path.
         children = findChildren(element, tagName, index);

         //Insert the found elements in the result set.
         for (i = 0; i < children.size(); i++)
             result.add((Node) children.get(i));
      }
   }


   /**
    * Finds the children of node element with tag name tagName. It only looks
    * on children of type Element and ignores nodes of type CharData.
    * @param element the parent node.
    * @param tagName the pattern.
    * @param index the index of the wanted node. If index is -1 then all
    * children with the right tag name is returned.
    * @returns a list of children with tag name equal to tagName.
    */
   private static ArrayList findChildren(Node element, String tagName,
                                         int index) {
      ArrayList children = new ArrayList();
      Node tempNode;
      ChildList.Iterator iterator = element.getChildNodes().iterator();

      if (tagName.equals("*")) {
         // The * character matches all elements.
         // Insert all children in result set.
         while(iterator.hasNext()) {
            tempNode = (Node)iterator.next();
            if (tempNode.getType() == Node.ELEMENT)
               children.add((Node) tempNode);
         }
      }
      else {
         // Tag name is not *.
         if (index == -1) {
            // Tag name without index.
            while(iterator.hasNext()) {
               tempNode = (Node)iterator.next();
               if ( (tempNode.getType() == Node.ELEMENT) &&
                    (tempNode.getValue().equals(tagName)))
                  children.add(tempNode);
            }
         }
         else {
            // Tag name with index.
            int counter = 0;
            while(iterator.hasNext()) {
               tempNode = (Node)iterator.next();
               if ( (tempNode.getType() == Node.ELEMENT) &&
                    (tempNode.getValue().equals(tagName) )) {
                  if (counter == index){
                     children.add(tempNode);
                     break;   // We have found the wanted node.
                  }
                  else
                     counter++;
               }
            }
         }
      }

      return children;
   }
}
