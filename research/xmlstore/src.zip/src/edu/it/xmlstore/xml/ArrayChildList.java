package edu.it.xmlstore.xml;

import edu.it.xmlstore.ValueReference;
import java.util.Arrays;
import java.util.Collection;

/**
  A child list represented as an array.
 */
public class ArrayChildList extends AbstractChildList {
   private Node[] children;
   private int size;

   private ArrayChildList (int size) {
      this.size = size;
      children = new Node[size];
   }


   public ArrayChildList(Node[] children) {
      this(children.length);
      // Copy the array -- it's the only way to make sure the array is not
      // altered later on from the outside
      System.arraycopy(children, 0, this.children, 0, children.length);
   }


   public Node get(int index) {
      assert index >= 0 && index < size : "Index out of bounds: [" +
                                          index + "].";
      return children[index];
   }


   public ValueReference getValueReference(int index) {
      assert index >= 0 && index < size : "Index out of bounds: [" +
                                          index + "].";
      return children[index].getValueReference();
   }


   public int size() {
      return size;
   }


   public ChildList delete(int target) {
      Node[] newList = new Node[size() - 1];
      // i is in children, j is in newList
      for (int i = 0, j = 0; i < children.length; i++)
         if (i != target)
            newList[j++] = children[i];

      return new ArrayChildList(newList);
   }


   public ChildList insert(Node newNode, int target) {
      Node[] newList = new Node[size() + 1];
      // i is in children, j is in newList
      for (int i = 0, j = 0; j < size() + 1; j++)
         if (i == target)
            newList[j] = newNode;
         else
            newList[j] = children[i++];

      return new ArrayChildList(newList);
   }
}