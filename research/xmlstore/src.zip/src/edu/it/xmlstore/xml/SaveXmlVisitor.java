package edu.it.xmlstore.xml;

import edu.it.xmlstore.*;
import edu.it.xmlstore.rpc.RemoteException;
/**
 * Visitor class for saving an XML document.
 */
public class SaveXmlVisitor implements Node.NodeVisitor {
   private XmlStoreServer server;
   private ValueReference result = null;

   public SaveXmlVisitor(XmlStoreServer server) {
      this.server = server;
   }

   public ValueReference getResult() {
      assert result != null : "SaveXmlVisitor has no result";
      return result;
   }

   public void visitElement(Element element) {
      // If the element is already saved we do not have to continue.
      if (element.isSaved()) {
         if (result == null) result = element.getValueReference();
      }
      else {
         // save byte representation in system and update result pointer if
         // this is the first node we have saved (first node = the root
         // of the subtree)
         try {
            server.saveValue(element.getBytes(), element.getValueReference());
            if (result == null) result = element.getValueReference();
         }
         catch (RemoteException e) {
            throw new RuntimeException("Error in SaveXmlVisitor" +
                                       ".visitElement: " + e.toString());
         }
         // save children recursively
         ChildList.Iterator children = element.getChildNodes().iterator();
         while(children.hasNext()) {
            Node node = (Node)children.next();
            node.accept(this);
         }
         element.markAsSaved();
      }
   }

   public void visitCharData(CharData charData) {
      // If the chardata is not already saved we continue.
      if (! charData.isSaved()) {
         try {
            server.saveValue(charData.getBytes(), 
                             charData.getValueReference());
            charData.markAsSaved();
         }
         catch (RemoteException e) {
            throw new RuntimeException("Error in SaveXmlVisitor" +
                                       ".visitCharData: " + e.toString());
         }
      }
   }
} 