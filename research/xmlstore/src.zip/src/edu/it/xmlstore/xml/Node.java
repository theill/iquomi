package edu.it.xmlstore.xml;

import java.util.List;
import java.io.Serializable;
import edu.it.xmlstore.ValueReference;
import edu.it.xmlstore.rpc.RemoteException;

/**
 * Interface for the nodes in an XML document.
 */
public interface Node {
   public static final short ELEMENT = 1;
   public static final short CHARDATA = 2;

   /** The size of an XML element before it is inlined */
   //public static final short MINIMUM_NODE_SIZE = 31;
   public static final short MINIMUM_NODE_SIZE = 250;

   public String getValue();
   public ChildList getChildNodes();
   public short getType();
   public ValueReference getValueReference();
   public byte[] getBytes();

   public void accept(NodeVisitor visitor);
   public String asString();
   public String asString(int tab);

   public static interface NodeVisitor {
      public void visitElement(Element element);
      public void visitCharData(CharData charData);
   }
   
   public void markAsSaved();   
   public boolean isSaved();   
   public boolean equalsContents(Object other);
}
