package edu.it.xmlstore.xml;

import java.lang.ref.SoftReference;

import edu.it.xmlstore.ValueReference;
import edu.it.xmlstore.XmlStoreServer;
import edu.it.xmlstore.XmlStoreHome;
import edu.it.xmlstore.rpc.RemoteException;

/**
 * Proxy for an actual node. A proxy node only contains a value reference and
 * the actual node is not loaded until a method is called on the node.
 */
public class ProxyNode implements Node {

   private SoftReference nodeRef;
   private final ValueReference ref;

   public ProxyNode(ValueReference ref) {
      this.nodeRef = null;
      this.ref = ref;
   }

   public ValueReference getValueReference() {
      return ref;
   }

   private Node getActual() {
      // if not has not been loaded or it has been gc'ed then load it
      if (nodeRef == null || nodeRef.get() == null) {
         XmlStoreServer server = XmlStoreHome.getConnectedServer(); 
         try {
            nodeRef = new SoftReference(server.load(ref));
         }
         catch (RemoteException e) {
	    e.printStackTrace(System.out);
            throw new RuntimeException("ProxyNode could not load actual child: " + ref);
         }
      }

      return (Node)nodeRef.get();
   }

   public String getValue() {      
      return getActual().getValue();
   }

   public byte[] getBytes() {
      return getActual().getBytes();
   }

   public ChildList getChildNodes() {
      return getActual().getChildNodes();
   }

   public short getType() {
      return getActual().getType();
   }

   public void accept(NodeVisitor visitor) {
      getActual().accept(visitor);
   }

   public String asString() {
      return getActual().asString();
   }

   public String asString(int tab) {
      return getActual().asString(tab);
   }

   public boolean equals(Object that) {
      return that instanceof Node
             && getValueReference().equals( ((Node)that).getValueReference() );
   }
   
   public boolean isSaved() {
      return true;
   }

   public void markAsSaved() {
      ; // do nothing  
   }   
   
   public boolean equalsContents(Object other) {
      return getActual().equalsContents(other);
   }
}
