package edu.it.xmlstore.xml;

import edu.it.xmlstore.ValueReference;

/**
 * Interface for childlists.
 */
public interface ChildList {
   public int size();
   public String getValue();

   public Node get(int index);
   public ValueReference getValueReference(int index);

   // primitive operations.
   public ChildList delete(int i);
   public ChildList insert(Node n, int i);
   public int indexOf(Node n);

   // derived operations.
   public ChildList append(Node n);
   public ChildList insertBefore(Node newChild, Node refChild);
   public ChildList replaceChild(Node newChild, Node oldChild);
   public ChildList delete(Node n);

   public Iterator iterator();

   public static interface Iterator {
      public Node next();
      public boolean hasNext();
   }
   
   public boolean equalsContents(ChildList other);
}