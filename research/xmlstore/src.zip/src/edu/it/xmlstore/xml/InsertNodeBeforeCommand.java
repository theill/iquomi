package edu.it.xmlstore.xml;

/**
 * Helper class for the method addNode in the utility class XmlHome.
 * Implements the command design pattern.
 */
public class InsertNodeBeforeCommand implements ModifyCommand {

   /** The node that will be added.*/
   private Node newChild;

   /** the new node will be inserted before this node. */
   private Node refChild;

   /** Constructor */
   public InsertNodeBeforeCommand(Node refChild, Node newChild) {
      this.refChild = refChild;
      this.newChild = newChild;
   }


   /**
    * Inserts newChild before refChild in the children list of element -
    * newChild will be inserted before every occurrence of refChild.
    * @param element the parent node.
    * @returns a new element where newChild is added.
    */
   public Node execute(Node element) {
      int index = element.getChildNodes().indexOf(refChild);
      if (index > -1)
         return Element.createElement(element.getValue(),
                element.getChildNodes().insert(newChild, index));
      else
         return element;
   }
}