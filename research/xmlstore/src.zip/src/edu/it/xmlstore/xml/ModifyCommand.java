package edu.it.xmlstore.xml;

/**
 * Interface for helper classes to the methods in the utility class XmlHome.
 * Interface for the "command" design pattern.
 */
public interface ModifyCommand {
   public Node execute(Node element);
}
