package edu.it.xmlstore;

public interface ValueReference {
   // The external 20 byte representation
   abstract public byte[] toBytes();

   // ==
   public boolean equals(Object that);
}