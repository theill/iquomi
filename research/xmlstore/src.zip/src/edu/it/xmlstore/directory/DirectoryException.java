package edu.it.xmlstore.directory;

/**
 * An exception thrown when somebody tries to update a name in the directory 
 * but that name has already been updated (optimistic locking, sort of).
 *
 */
public abstract class DirectoryException extends Exception {
   private String name;
     
   public DirectoryException(String name) {
      this.name = name;
   }

   public void setName(String name) {
      this.name = name;
   }
   
   public String toString() {
      if (name == null) 
	 return noname();
      else 
	 return first() + name + second();
   }
   abstract protected String first();
   abstract protected String second();
   abstract protected String noname();
}
