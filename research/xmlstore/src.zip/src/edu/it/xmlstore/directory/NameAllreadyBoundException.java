package edu.it.xmlstore.directory;

/**
 * An exception thrown if a name in the Directory already exists.
 */
public class NameAllreadyBoundException extends DirectoryException {
   private static final String part1 = "The name'";
   private static final String part2 = "' is allready bound";
   private static final String noname = "Name allready bound";
   
   public NameAllreadyBoundException() {
      super(null);
   }
   
   public NameAllreadyBoundException(String name) {
      super(name);
   }

   protected String first()   {return part1;}
   protected String second()  {return part2;}
   protected String noname()  {return noname;}
}
