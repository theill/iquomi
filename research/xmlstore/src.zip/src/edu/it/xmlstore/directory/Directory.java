package edu.it.xmlstore.directory;

import java.util.Map;
import java.util.HashMap;
import java.io.IOException;
import edu.it.xmlstore.ValueReference;
import edu.it.xmlstore.rpc.RemoteException;

/**
 * A simple lookup service that maps humanly readable names to 
 * valuereferences in the XML store.
 */
public interface Directory {
   public void bind(String name, ValueReference ref) 
                         throws NameAllreadyBoundException, RemoteException;
                              
   public ValueReference unbind(String name) 
                         throws NoSuchElementException, RemoteException;
                              
   public ValueReference lookup(String name) 
                         throws NoSuchElementException, RemoteException;  
                              
   public void update(String name, ValueReference newRef, 
                      ValueReference expectedRef) 
                         throws ConcurrentAccessException,
                                NoSuchElementException, RemoteException;
}