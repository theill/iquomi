package edu.it.xmlstore.directory;

/**
 * An exception thrown when somebody tries to update a name in the directory 
 * but that name has already been updated (optimistic locking, sort of).
 *
 */

public class ConcurrentAccessException extends DirectoryException {
   private static final String part1 = "Concurrent Modification: The name '";
   private static final String part2 = "' has allready been updated.";
   private static final String noname = "Concurrent Modification.";
   private String name;
   
   public ConcurrentAccessException() {
      super(null);
   }
   
   public ConcurrentAccessException(String name) {
      super(name);
   }
 
   protected String first()   {return part1;}
   protected String second()  {return part2;}
   protected String noname()  {return noname;}
}
