package edu.it.xmlstore.directory;

import edu.it.xmlstore.rpc.*;
import edu.it.xmlstore.*;
import java.util.Map;
import java.util.HashMap;
import java.io.IOException;

/**
 * A implementation of a simple lookup service that maps humanly readable 
 * names to valuereferences in the XML store.
 *
 */
public class DirectoryImpl implements Directory {

   /** maps names to ValueReferences */
   private Map directory;

   public DirectoryImpl() {
      directory = new HashMap(128);   
   }

   public synchronized void bind(String name, ValueReference ref) 
                                         throws NameAllreadyBoundException {
      if (!directory.containsKey(name)) {
         directory.put(name, ref);      
      }
      else 
         throw new NameAllreadyBoundException(name);
   }


   public synchronized ValueReference unbind(String name) 
                                          throws NoSuchElementException {
      if (directory.containsKey(name))
         return (ValueReference)directory.remove(name);
      else
         throw new NoSuchElementException(name);
   }


   public synchronized ValueReference lookup(String name) 
                                          throws NoSuchElementException {
      if (directory.containsKey(name))
         return (ValueReference)directory.get(name);      
      else
         throw new NoSuchElementException(name);
   }
   
   public synchronized void update(String name, ValueReference newRef, 
                                   ValueReference expectedRef) 
                                   throws ConcurrentAccessException,
                                          NoSuchElementException {
      
      if (directory.containsKey(name)) {
         ValueReference currentRef = (ValueReference)directory.get(name);
         // make sure current entry is what we expect -- otherwise somebody has
         // updated the name since we read.
         if (currentRef.equals(expectedRef)) {
            directory.remove(name);
            directory.put(name, newRef);
         }
         else
            throw new ConcurrentAccessException(name);         
      }
      else
         throw new NoSuchElementException(name);      
   }   
   
   // ------------------------ Main entrance to Directory -------------------
   public static void main(String[] args) throws IOException {

      // read command line options -- processArgs will exit on errors
      for (int i = 0; i < args.length; i++) {
	 processArg(args[i]);
      }

      // if we are here we can start the directory     
      System.out.println("Starting Name Service at port " + getPort());
      
      // Create directory and initialize network communication classes
      Directory dir = new DirectoryImpl();      
      MessageDispatcher messageDispatcher = new DirectoryMessageDispatcher(dir);
      XmlStoreHome.getMessageFactory().initializeTransmitter(getPort(), messageDispatcher);

      // Create listener for receiving incoming multicast lookup requests
      Thread listenThread = new Thread(new ConnectListener(getPort()));
      listenThread.start();

      System.out.println("Name Service started.");  
   }


   /** Command line processing */
   private static final String PORT_NAME = "port";
   private static final String NETWORK_NAME = "network";
   private static final String HELP_NAME = "help";
   private static final String UDP_NAME = "udp";
   private static final String TCP_NAME = "tcp";

   private static HashMap properties = new HashMap();
   static {
      properties.put(PORT_NAME, new Integer(10000));
      properties.put(NETWORK_NAME, UDP_NAME);
   }

   public static int getPort() {
      Integer port = (Integer)properties.get(PORT_NAME);
      return port.intValue();
   }

   
   private static void processArg(String arg) {
      // 'arg'
      if (arg.trim().equalsIgnoreCase(HELP_NAME))
	 printInfo();	 

      // 'property=value'     
      else {
	 // read property and value parts
	 String property = arg;
	 String value = null;
	 int eqIndex = arg.indexOf('='); 	

	 // If there is an '=' find property and value parts
	 if (eqIndex >= 0) {
	    property = arg.substring(0, eqIndex).trim().toLowerCase();	
	    try {
	       value = arg.substring(eqIndex+1, arg.length()).trim().toLowerCase();
	    }
	    catch(IndexOutOfBoundsException e) {
	       printMissingArgument(property); 
	    }
	 }
	 
	 if (value == null || value.trim().equals(""))
	    printMissingArgument(property); 
	 
	 // process argument
	 if (properties.containsKey(property)) {

	    // port
	    if(property.equals(PORT_NAME)) {	       
	       try {
		  Integer port = Integer.decode(value);
		  properties.put(property, port);
	       }
	       catch(NumberFormatException e) {
		  printInvalidArgument(property, value);
	       }
	    }	    

	    // network protocol
	    else if(property.equals(NETWORK_NAME)) {	       

	       // make sure value is either tcp or udp
	       if (value.equals(TCP_NAME) || value.equals(UDP_NAME))
		  properties.put(property, value);
	       else
		  printInvalidArgument(property, value);
	    }	
	 }
	 else
	    printUnknown(property);
      }
   }

   /** Command line output */
   private static void printInfo() {
      String info = "Usage: java edu.it.xmlstore.DirectoryImpl [OPTION]\n" + 
	            "  " + PORT_NAME + "=NUMBER                    the communication port\n" +
                    "  " + NETWORK_NAME + "='tcp'|'udp'            the network protocol to use\n";
      System.out.println(info);
      System.exit(0);
   }
   
   private static void printMissingArgument(String option) {      
      String error = "Directory: option '" + option + "' requires an argument\n"; 
      System.out.println(error);
      printInfo();
   }

   private static void printInvalidArgument(String option, String value) {      
      String error = "Directory: invalid value '" + value + "' for option '" + option + "'\n"; 
      System.out.println(error);
      printInfo();
   }
   
   private static void printUnknown(String option) {
      
      String error = "Directory: unknown option: " + option + "\n"; 
      System.out.println(error);
      printInfo();
   }


}
