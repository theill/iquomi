package edu.it.xmlstore.directory;

/**
 * An exception thrown if s client requests a name 
 * that does not exist in the directory.
 */
public class NoSuchElementException extends DirectoryException {
   private static final String part1 = "No such element: The name '";
   private static final String part2 = "' is not in the directory.";
   private static final String noname = "No such element.";
   
   public NoSuchElementException() {
      super(null);
   }
   
   public NoSuchElementException(String name) {
      super(name);
   }

   protected String first()   {return part1;}
   protected String second()  {return part2;}
   protected String noname()  {return noname;}
}
