package edu.it.xmlstore;

import java.net.MulticastSocket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.DatagramPacket;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;

import java.io.IOException;

import java.util.LinkedList;
import java.util.StringTokenizer;
import java.util.HashMap;
import java.util.Iterator;

import junit.framework.Assert;

import edu.it.xmlstore.rpc.*;
import edu.it.xmlstore.rpc.udp.UdpMessageFactory;
import edu.it.xmlstore.xml.*;
import edu.it.xmlstore.directory.*;
import edu.it.xmlstore.chord.ChordId;
import edu.it.xmlstore.storage.*;

/**
 * Home for the XmlStoreServers on this computer.
 * Connects the servers etc.
 */
public class XmlStoreHome {

   /**
    * Maintain list of local connected servers
    *
    */
   private static LinkedList servers = new LinkedList();

   public static XmlStoreServer getConnectedServer() {
      //System.out.println(servers + " getConnectedServers: " + servers.isEmpty());      
      if (!servers.isEmpty())
         return (XmlStoreServer)servers.getFirst();
      else
         throw new RuntimeException("No servers connected.");
   }

   public static void addConnectedServer(XmlStoreServer s) {
      servers.addLast(s);
      //System.out.println(servers + " Server: " + s + " is added to the connectedServers: " + servers.isEmpty());
   }

   public static void removeConnectedServer(XmlStoreServer s) {
      //System.out.println("Server: " + s + " is removed from the connectedServers");
      servers.remove(s);
   }


   /**
    * Bootstrap: Join the peer to peer network by 
    * finding an external server (lookupExternalServer),
    * and joining it (createAndJoin).
    */
   public static XmlStoreServer bootstrap(int port) throws IOException {
      System.out.println("Bootstrapping...");
      
      // calculate the id of this server
      ChordId id = (ChordId)ValueUtil.getValueReference(("XmlStore://" +
                                                InetAddress.getLocalHost() +
                                                ":" + port).getBytes());
      XmlStoreServer server = null;
      XmlStoreServer extServer = null;

      // Try to locate external XmlStoreServer
      try {	
         extServer = lookupExternalServer(id, port);
         System.out.println("Found server: " + extServer.serverId());
      }
      catch (RemoteException e) {
         System.err.println("Exception while bootstrapping: " + e);
         System.out.println("********************************************");
         System.out.println("WARNING! Could not find any external servers");
         System.out.println("********************************************");
      }

      // Create local XmlStore instance and join the chord ring
      try {	
	 server = createServer(id, port);     
	 System.out.println("Joining the system");
	 server.join(extServer);
	 System.out.println("****** Successful join ***********");
      }
      catch (RemoteException e) {
         System.err.println("Error: " + e);
      }

      System.out.println("Bootstrapping complete!");

      return server;
   }


   // Find an external server by either using multicast or a given IP-address
   public static XmlStoreServer lookupExternalServer(ChordId id, int listenPort)
                                                      throws RemoteException {
      XmlStoreServer server = null;
      try {
	 // Decide whether to use multicast to search for servers 
	 // or contact a server using a given ip address
	 if (properties.get(BOOTSTRAP_NAME).equals(MULTICAST_NAME))
	    server = searchForExternalServer(listenPort);	 
	 else
	    server = contactExternalServer((InetSocketAddress)properties.get(BOOTSTRAP_NAME), listenPort);
      } finally {
	 // If no servers respond an exception is thrown, but we
	 // still need to start discovery service, so finally:
	 startConnectListener(id, listenPort);
      }

      return server;
   }

   // Multicast search for other servers
   private static XmlStoreServer searchForExternalServer(int listenPort) throws RemoteException {
      // Make multicast ip request. If somebody answers note their ip, port, 
      // chordid and create XmlStoreServerProxy      
      try {
         // Construct message specifying where we want to receive
         // incoming acknowledgements
         String message = ConnectListener.XMLSTORE_LOOKUP_PREFIX + ":" +
                          InetAddress.getLocalHost().getHostAddress()+
                          ":" + listenPort;

         String ack = sendMulticast(message, listenPort);

         // parse incoming message
         StringTokenizer incoming = new StringTokenizer(ack,":,");
	 String token = incoming.nextToken();
         assert token.equals(ConnectListener.XMLSTORE_RESPONSE_PREFIX);
         InetAddress host = InetAddress.getByName(incoming.nextToken());
         int port = Integer.parseInt(incoming.nextToken());
         ValueReference ref = ValueUtil.decode(incoming.nextToken());

         return new XmlStoreServerProxy(ref, new InetSocketAddress(host, port));
      }
      catch (IOException e) {
         throw new RemoteException ("Error looking up external server: " + e);
      }
   }

   // Find other server using given IP-address
   private static XmlStoreServer contactExternalServer(InetSocketAddress address, int listenPort) throws RemoteException {
      try {
         String message = ConnectListener.XMLSTORE_LOOKUP_PREFIX + ":" +
                          InetAddress.getLocalHost().getHostAddress()+
                          ":" + listenPort;

         String ack = sendUnicast(message, address, listenPort);

         // parse incoming message
         StringTokenizer incoming = new StringTokenizer(ack,":,");
	 String token = incoming.nextToken();
         assert token.equals(ConnectListener.XMLSTORE_RESPONSE_PREFIX);
         InetAddress host = InetAddress.getByName(incoming.nextToken());
         int port = Integer.parseInt(incoming.nextToken());
         ValueReference ref = ValueUtil.decode(incoming.nextToken());

         return new XmlStoreServerProxy(ref, new InetSocketAddress(host, port));
      }
      catch (IOException e) {
         throw new RemoteException ("Error looking up external server: " + e);
      }
   }

   // Initialize XmlStore Discovery service
   // and start listening...
   // Port is where we want to receive messages.
   private static void startConnectListener(ChordId id, int port) {
      try {
	 ConnectListener listener = new ConnectListener(id, port);
	 new Thread(listener).start();
	 System.out.println("(ConnectListener started)");
      }
      catch(IOException e) {
	 System.out.println("Error: Could not start ConnectListener.");
      }
   }


   public static XmlStoreServer createServer(ChordId id, int port) throws IOException {

      // Initialize XmlStoreServer including RPC layer consisting of
      // MessageDispatcher, MessageReceiver and Proxy.

      // find our address
      InetSocketAddress address =
               new InetSocketAddress(InetAddress.getLocalHost(), port);

      System.out.println("Starting XmlStoreServer at " + address + ".");
      System.out.println("Id: " + id + ".");

      // Create server and initialize network communication classes
      XmlStoreServerImpl server = new XmlStoreServerImpl(id, port);
      MessageDispatcher messageDispatcher = new XmlStoreMessageDispatcher(server);
      getMessageFactory().initializeTransmitter(port, messageDispatcher);

      return server;     
   }


   /**
    * Find nameservice
    *
    */
   public static Directory lookupNameService(int listenPort)
                                                      throws IOException {
      // Construct message specifying where we want to receive
      // incoming acknowledgements
      String message = ConnectListener.NAMESERVICE_LOOKUP_PREFIX + ":" +
                       InetAddress.getLocalHost().getHostAddress()+
                       ":" + listenPort;
      String ack = sendMulticast(message, listenPort);

      // parse incoming message
      StringTokenizer incoming = new StringTokenizer(ack,":,");
      String token = incoming.nextToken();
      assert token.equals(ConnectListener.NAMESERVICE_RESPONSE_PREFIX);
      InetAddress host = InetAddress.getByName(incoming.nextToken());
      int port = Integer.parseInt(incoming.nextToken());

      return new DirectoryProxy(host, port);
   }


   public static Directory getDirectory(int port) {
      try {
         System.out.println("Looking for name service");
         return lookupNameService(port);
      }
      catch (IOException e) {
         System.err.println("Exception while looking for name service: " + e);
         System.out.println("********************************************");
         System.out.println("WARNING! Could not find Name Service");
         System.out.println("********************************************");
         return null;
      }

   }


   /**
    * Send multicast discovery message 
    *
    */
   private static String sendMulticast(String message, int listenPort)
                                                               throws IOException {


      // make multicast ip request
      // and return response
      DatagramSocket socket = null;
      //      MulticastSocket multicastSocket = null;
      try {
         // send message to multicast group
//	 socket = new DatagramSocket(listenPort);
//         multicastSocket = new MulticastSocket(ConnectListener.LISTENING_PORT);
         socket = new DatagramSocket();

         DatagramPacket hi =
               new DatagramPacket(message.getBytes(), 
				  message.length(),
				  InetAddress.getByName(ConnectListener.GROUP_ADDRESS),
				  ConnectListener.LISTENING_PORT);
	 socket.send(hi);
         // receive incoming messages 
         byte[] buf = new byte[1000];
         DatagramPacket recv = new DatagramPacket(buf, buf.length);
         socket.setSoTimeout(5000);
         socket.receive(recv);
         String ack = new String(buf).trim();
         return ack;
      }
      finally {
         //if (multicastSocket != null)
	 //multicastSocket.close();
         if (socket != null)
            socket.close();
      }
   }

   /**
    * Send discovery message directly to a specified receiver
    *
    */
   private static String sendUnicast(String message, InetSocketAddress address, int listenPort) throws IOException {
      DatagramSocket socket = null;
      try {
         // send message
         socket = new DatagramSocket(listenPort);

         DatagramPacket hi =
	    new DatagramPacket(message.getBytes(), 
			       message.length(),
			       address);
         socket.send(hi);

         // receive incoming messages (try for five seconds before giving up)
         byte[] buf = new byte[1000];
         DatagramPacket recv = new DatagramPacket(buf, buf.length);
         socket.setSoTimeout(5000);
         socket.receive(recv);
         String ack = new String(buf).trim();
         return ack;
      }
      finally {
         if (socket != null)
            socket.close();
      }
   }


   /**
    * Message factory handler
    * According to commandline parameter, either tcp or ud
    *
    */
   public static MessageFactory getMessageFactory() {
      String protocol = getNetworkProtocol();
      if (protocol.equals(TCP_NAME))
	 // TODO: return TcpMessageFactory.instance();
	 return null;
      else if (protocol.equals(UDP_NAME))
	 return UdpMessageFactory.instance();
      else
	 throw new RuntimeException("Internal error in XmlStoreHome, protocol=" + protocol);
   }


   // ------------------- Main entry to the program  -----------------------
   public static void main(String[] args) throws IOException {
      if (args.length == 0) printInfo();

      // read command line options -- processArgs will exit on errors
      for (int i = 0; i < args.length; i++) {
	 processArg(args[i]);
      }
      
      try {
	 // if we are here we can start the server
	 XmlStoreServer server = bootstrap(getPort());      
      }
      catch (Throwable e) {
	 System.out.println("Fatal error: " + e);
	 e.printStackTrace(System.out);
      }
   } 


   /**
    * Process command line arguments
    *
    */

   // Properties are held in a hashmap containing the default settings
   private static final String PORT_NAME = "port";
   private static final String NETWORK_NAME = "network";
   private static final String HELP_NAME = "help";
   private static final String UDP_NAME = "udp";
   private static final String TCP_NAME = "tcp";
   private static final String BOOTSTRAP_NAME = "bootstrap";
   private static final String MULTICAST_NAME = "multicast";
   private static final String DISK_NAME = "disk";
   private static final String MULTIFILEDISK_NAME = "multifile";
   private static final String RAFILEDISK_NAME = "rafile";


   private static HashMap properties = new HashMap();
   static {
      properties.put(PORT_NAME, new Integer(8888));
      properties.put(NETWORK_NAME, UDP_NAME);
      properties.put(BOOTSTRAP_NAME, MULTICAST_NAME);
      properties.put(DISK_NAME, RAFILEDISK_NAME);
   }

   private static void processArg(String arg) {
      // There are two kinds of arguments:
      // 'arg' and 'property=value'

      // 'arg'
      if (arg.trim().equalsIgnoreCase(HELP_NAME))
	 printInfo();	 

      // 'property=value'     
      else {
	 // read property and value parts
	 String property = arg;
	 String value = null;
	 int eqIndex = arg.indexOf('='); 	

	 // If there is an '=' find property and value parts
	 if (eqIndex >= 0) {
	    property = arg.substring(0, eqIndex).trim().toLowerCase();	
	    try {
	       value = arg.substring(eqIndex+1, arg.length()).trim().toLowerCase();
	    }
	    catch(IndexOutOfBoundsException e) {
	       printMissingArgument(property); 
	    }
	 }
	 
	 if (value == null || value.trim().equals(""))
	    printMissingArgument(property); 
	 
	 // process argument
	 if (properties.containsKey(property)) {

	    // port
	    if(property.equals(PORT_NAME)) {	       
	       try {
		  Integer port = Integer.decode(value);
		  properties.put(property, port);
	       }
	       catch(NumberFormatException e) {
		  printInvalidArgument(property, value);
	       }

	    }	    

	    // network protocol
	    else if (property.equals(NETWORK_NAME)) {	       

	       // make sure value is either tcp or udp
	       if (value.equals(TCP_NAME) || value.equals(UDP_NAME))
		  properties.put(property, value);
	       else
		  printInvalidArgument(property, value);
	    }	

	    // bootstrap method
	    else if (property.equals(BOOTSTRAP_NAME)) {	       
	       
	       if (value.equals(MULTICAST_NAME))
		  properties.put(property, value);
	       else {
		  // make sure value is an ip address
		  try {
		     InetAddress hostAddress = InetAddress.getByName(value);
		     InetSocketAddress address = new InetSocketAddress(hostAddress, ConnectListener.LISTENING_PORT);
		     properties.put(property, address);
		  }
		  catch(UnknownHostException e) {
		     printInvalidArgument(property, value);
		  }
	       }
	    }
	    else if (property.equals(DISK_NAME)) {
	       if (value.equals(MULTIFILEDISK_NAME) || value.equals(RAFILEDISK_NAME)) 
		  properties.put(property, value);
	       else
		  printInvalidArgument(property, value);

	    }
	 } 
	 else
	    printUnknown(property);
      }
   }

   public static int getPort() {
      Integer port = (Integer)properties.get(PORT_NAME);
      return port.intValue();
   }

   public static Disk getDisk(String directory) throws IOException {
      String diskType = (String)properties.get(DISK_NAME);
      if (diskType.equals(MULTIFILEDISK_NAME))
	 return new MultiFileDisk(directory);
      else {
	 assert diskType.equals(RAFILEDISK_NAME) : "Illegal disk property: " + diskType;
	 return new RAFileDisk(directory);
      }
   }

   public static String getNetworkProtocol() {
      return (String)properties.get(NETWORK_NAME);
   }
   
   public static void setNetworkProtocol(String protocol) {
      protocol = protocol.trim().toLowerCase();
      if (protocol.equals(TCP_NAME) || protocol.equals(UDP_NAME))
	 properties.put(NETWORK_NAME, protocol);
      else
	 throw new RuntimeException("Illeagal protocol: " + protocol);
   }

   /** Command line output */
   private static void printInfo() {
      String info = "Usage: java edu.it.xmlstore.XmlStoreHome [OPTION]\n" + 
	            "  " + PORT_NAME + "=NUMBER\t\t\t\tthe communication port\n" +
                    "  " + NETWORK_NAME + "='" + UDP_NAME  + "'|'" +  TCP_NAME  + "'\t\t\tthe network protocol to use\n" +
	            "  " + BOOTSTRAP_NAME + "='" + MULTICAST_NAME  +  "'|IP\t\tuse multicast or a specifik ip-address\n" +
	            "  " + DISK_NAME + "='" + MULTIFILEDISK_NAME  + "'|'" +  RAFILEDISK_NAME  + "'\t\tthe type of disk to use\n";
      System.out.println(info);
      System.exit(0);
   }

   private static void printMissingArgument(String option) {      
      String error = "XML Store: option '" + option + "' requires an argument\n"; 
      System.out.println(error);
      printInfo();
   }

   private static void printInvalidArgument(String option, String value) {      
      String error = "XML Store: invalid value '" + value + "' for option '" + option + "'\n"; 
      System.out.println(error);
      printInfo();
   }
   
   private static void printUnknown(String option) {
      
      String error = "XML Store: unknown option: " + option + "\n"; 
      System.out.println(error);
      printInfo();
   }
}
