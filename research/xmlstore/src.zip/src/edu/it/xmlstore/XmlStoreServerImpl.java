package edu.it.xmlstore;

import java.util.HashMap;
import java.util.Set;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;
import java.util.LinkedList;
import java.io.IOException;
import java.io.File;
import java.net.InetSocketAddress;
import java.net.InetAddress;
import java.net.UnknownHostException;
import edu.it.xmlstore.chord.*;
import edu.it.xmlstore.storage.*;
import edu.it.xmlstore.xml.*;
import edu.it.xmlstore.rpc.*;

/**
 * Class representing XmlStoreServer.
 * XmlStoreServer is a node in a peer-to-peer network, based on the
 * Chord-protocol.
 */
public class XmlStoreServerImpl extends ChordNodeImpl
                                        implements XmlStoreServer {

   /** Various properties.*/
   // private static final int NO_OF_CACHE_ENTRIES = 100;
   private static final int DEFAULT_PORT = 8080;
   public  static final String SAVE_DIRECTORY = System.getProperty("java.io.tmpdir")
                                              + File.separatorChar + "xmlstore";
   private InetSocketAddress address;
   private int port;

   /** The storage area for locally stored values.*/
   private Disk disk;

   /** The storage area for locally cached values.*/
   //   private Cache cache;

   /** The stabilizer */
   private StabilizeThread stabilizeThread;

   // Fields for concurrent saving of nodes
   private NodeQueue nodes;
   private static final int SAVE_THREADS = 10;
   private SaveThread[] saveThreads;
   private ConcurrencyManager concurrencyManager;


   /**
    * Constructor
    *
    * @param serverId the id of the XmlStoreServer on the CHORD ring
    */
   public XmlStoreServerImpl(ValueReference serverId, int port) {
      super((ChordId)serverId);
      this.port = port;
      try {
	 disk = XmlStoreHome.getDisk(SAVE_DIRECTORY + File.separatorChar + serverId);
	 //cache = new LruCache(NO_OF_CACHE_ENTRIES);
      }
      catch(IOException e) {
	 throw new RuntimeException("Could not initialize disks in XmlStoreServer: " + e);
      }

      // Initialize save threads and queue
      concurrencyManager = new ConcurrencyManager();
      nodes = new NodeQueue();
      saveThreads = new SaveThread[SAVE_THREADS];
      for (int i = 0; i < SAVE_THREADS; i++) {
	 saveThreads[i] = new SaveThread(this, nodes, concurrencyManager);
	 saveThreads[i].start();
      }
   }

   private void beginStabilize() {
      stabilizeThread = new StabilizeThread(this);
      stabilizeThread.start();
   }

   private void stopStabilize() {
      stabilizeThread.interrupt();
   }


   public XmlStoreServerImpl(ValueReference serverId) {
      this(serverId, DEFAULT_PORT);
   }


   public InetSocketAddress getAddress() {
      try {
         if (address == null)
            address = new InetSocketAddress(InetAddress.getLocalHost(), port);
      }
      catch (UnknownHostException e) {
         throw new RuntimeException("Error finding local host: " + e);
      }
      return address;
   }


   /**
    * Stores the XML node and the (sub)document that comprised of its childen
    * in the system (not necessarily this server) and returns the
    * ValueReference.
    * @param element the root of the XML tree
    * @returns the ValueReference of the document that was stored
    */
   private static int nextOperationId = 0;
   public ValueReference save(Element element) throws RemoteException {      
      if (!element.isSaved()) {
	 // Get an id for this save operation
	 int id = nextOperationId++;

	 // Save children first
	 ChildList.Iterator children = element.getChildNodes().iterator();
	 while(children.hasNext()) 
	    saveChild(children.next(), id);
      
	 // Save element and mark it as saved
	 //	 saveValue(element.getBytes(), element.getValueReference());
	 //	 element.markAsSaved();
	 saveConcurrent(element, id, true);

	 // Wait for queue to become empty and throw exception if necessary?
	 concurrencyManager.waitUntilFinished(id);
      }

      return element.getValueReference();
   }
 
   private void saveChild(Node node, int id) throws RemoteException {
      if (!node.isSaved()) {
	 // Save children first
	 ChildList.Iterator children = node.getChildNodes().iterator();
	 while(children.hasNext()) 
	    saveChild(children.next(), id);

	 // If the node is below a certain size it will be inlined
	 // in it's parent
	 byte[] bytes = node.getBytes();     
	 if (bytes.length <= Node.MINIMUM_NODE_SIZE) {
	    // Don't do anything -- the node will be inlined
	    // NB! Do not mark as saved -- maybe the node will be 
	    // stored as root in another context, where it will 
	    // need to be saved
	 }
	 else {
	    // The node will not be inlined -- save it
	    //	    saveValue(bytes, node.getValueReference());
	    //	    node.markAsSaved();
	    saveConcurrent(node, id, false);
	 }
      }
   }

   private void saveConcurrent(Node node, int operationId, boolean lastNode) {
      concurrencyManager.beginPartialOperation(operationId, lastNode);
      nodes.put(node, operationId, lastNode); 
   }

   /**
    * Retrieves the XML (sub)document associated with this ValueReference the system (not necessarily this server).
    *
    * @param ref
    * @returns the root node of the document requested
    */
   public Node load(ValueReference ref) throws RemoteException,
                                               ValueNotFoundException {
      try {
         byte[] data = loadValue(ref);         
         return parseNode(new PushBackTokenizer(new String(data), "<>", true));
      }
      catch (ValueNotFoundException e) {
         throw new ValueNotFoundException("Value cannot be found: " + e);
      }
      catch (RuntimeException e) {
         throw new RemoteException("Value cannot be found: " + e);
      }
   }

   private Node parseNode(PushBackTokenizer input) {      
      // read node type
      String token;
      // '<'
      token = input.nextToken(); 
      assert token.equals("<");           
      // type
      int type = Integer.parseInt(input.nextToken());
      // '>'
      token = input.nextToken(); 
      assert token.equals(">");      
            
      switch(type) {
         
         // Elements
         case Node.ELEMENT:
            List children = new LinkedList();            
            Node child;

            String name = input.nextToken();

            // read children
            while ( input.hasMoreTokens() ) {
               // either '<' for a child or '>' for finished reading an inlined elt
               token = input.nextToken(); 
               if (token.equals(">")) {
                  input.pushBack();
                  break;
               }                   
               
               token = input.nextToken();
               if (token.equals("<")) { // its inlined
                  // push back
                  input.pushBack();
                  child = parseNode(input);                  
               }
               else { // just a normal ref
                  ValueReference childRef = ValueUtil.decode(token);
                  child = new ProxyNode(childRef);
               }               
               children.add(child);               
              
               // end of child
	       token = input.nextToken(); 
               assert token.equals(">");      
            }
         
            Element elt = Element.createElement(name,
                                   AbstractChildList.create(children));
            elt.markAsSaved(); // node is already 'on disk'
            return elt;
         
         // CharData snippets   
         case Node.CHARDATA:
            String charData = input.nextToken();
            CharData cdata = CharData.createCharData(charData);            
            cdata.markAsSaved(); // node is already 'on disk'
            return cdata;
            
         default:
            throw new RuntimeException("Unknown node type when parsing value: " + type);
         
      }
   }


   /**
    * Stores a value (a sequence of bytes) in the system
    * (not necessarily this server) 
    *
    * @param key the identifier of the value
    * @param the value associated with key
    */
   public void saveValue(byte[] value, ValueReference key)
                                    throws RemoteException {
      XmlStoreServer x = (XmlStoreServer)findSuccessor((ChordId)key);
      x.saveToDisk(value, key);
   }


   /**
    * Loads a value associated with key from the XmlStore network.
    */
   public byte[] loadValue(ValueReference key) throws ValueNotFoundException,
                                                      RemoteException {
      // check if we have the value stored ...
      //boolean cached = containsKeyCached(key);
      boolean onDisk = containsKeyOnDisk(key);

      // if(cached) ...

      if(onDisk)
         try {
            return loadFromDisk(key);
         }
         catch(IOException e) {
            throw new RemoteException("Error in loadValue: " + e.toString());
         }

      // ... otherwise keep looking
      else {
         // check whether key is between my predecessor and myself
         if ( ChordId.isBetweenRightIncl(
                          (ChordId)key, predecessor().serverId(), serverId()) )
            throw new ValueNotFoundException("Value not found");
         else {
            // check whether key is between myself and my successor.
            if ( ChordId.isBetweenRightIncl(
                          (ChordId)key, serverId(), successor().serverId()) ) {
               byte[] result = ((XmlStoreServer)successor()).loadValue(key);
               //cache.put(result, key);
               return result;
            }
            else {
               // continues the recursive load...
               byte[] result = ((XmlStoreServer)
                        closestPrecedingFinger((ChordId)key)).loadValue(key);
               //cache.put(result, key);
               return result;
            }
         }
      }
   }


   /**
    * Saves a value with key on this server
    *
    * @param key the identifier of the value
    * @param the value associated with key
    */
   public void saveToDisk(byte[] value, ValueReference ref)
                                    throws RemoteException {
      try {
         disk.save(value, ref);
      }
      catch (IOException e) {
         throw new RemoteException("Error in saveToDisk: " + e.toString());
      }
   }


   /**
    * Loads a value from the local XmlStore. It first looks in the
    * cache and then in disk.
    */
   public byte[] loadFromDisk(ValueReference key) throws IOException {
      //      if (cache.contains(key))
      // return cache.get(key);
      //else
      if (disk.contains(key))
	 return disk.load(key);
      else
	 throw new IOException("Value could not be loaded - " +
                                  "is not on disk. ");
   }


   /**
    * Move the relevant keys to p (that has just been inserted).
    */
   public void moveKeys(XmlStoreServer p) throws RemoteException {
      byte[] val = null;
      List deleteKeys = new ArrayList();
      Iterator i = disk.getKeySet().iterator();
      while ( i.hasNext() ) {
         ChordId key = (ChordId)i.next();
         // Only move the keys that should now be stored at p
         if ( ChordId.isBetweenLeftIncl(p.serverId(), key, serverId()) ){
            try{
               val = disk.load(key);
               p.saveToDisk(val, key);
               deleteKeys.add(key); // Remember the key so we can delete it
            }
            catch(Exception e){
               throw new RemoteException("Error in XmlStoreServerImpl " +
                                         "moveKeys :" + e.toString());
            }
         }
      }
      // Delete keys from disk.
      for (int j = 0; j < deleteKeys.size(); j++)
         disk.delete((ValueReference) deleteKeys.get(j));
   }


   /**
    * Move all key/values to p (we are leaving...).
    */
   public void moveAllKeys(XmlStoreServer p) throws RemoteException {
      byte[] val = null;
      List deleteKeys = new ArrayList();
      Iterator i = disk.getKeySet().iterator();
      while ( i.hasNext() ) {
         ChordId key = (ChordId)i.next();
         try{
            val = disk.load(key);
            p.saveToDisk(val, key);
            deleteKeys.add(key);    // Remember the key so we can delete it.
         }
         catch(IOException e){
            System.out.println("I/O Error while moving all keys: " + e);
         }
      }
      // Delete keys from disk.
      for (int j = 0; j < deleteKeys.size(); j++)
         disk.delete((ValueReference) deleteKeys.get(j));
   }


   /**
    * Makes the XmlStoreServer join the XmlStore network.
    */
   public void join(XmlStoreServer n) throws RemoteException {
      // Tell XmlStoreHome that we are connected
      XmlStoreHome.addConnectedServer(this);

      super.join(n);
      if (n != null)
         ((XmlStoreServer)successor()).moveKeys(this);
      beginStabilize();
   }


   /**
    * Makes this XmlStoreServer leave the XmlStore network.
    */
   public void leave() throws RemoteException {
      // Tell XmlStoreHome that we are no longer connected
      XmlStoreHome.removeConnectedServer(this);

      stopStabilize();
      XmlStoreServer s = (XmlStoreServer)successor();
      super.leave();
      moveAllKeys(s);
   }


   /** Checks whether a key is cached on this XmlStoreServer.*/
   public boolean containsKeyCached(ValueReference key) {
      return false;
      //      return cache.contains(key);
   }


   /** Checks whether a key is stored on disk on this XmlStoreServer.*/
   public boolean containsKeyOnDisk(ValueReference key) {
      return disk.contains(key);
   }


   public String toString() {
      String s = "XmlStore #" + serverId();
      return s;
   }


   //-----------------------------------------------------------------

   private static class StabilizeThread extends Thread {
      private XmlStoreServerImpl xmlstore;
      public StabilizeThread(XmlStoreServerImpl xmlstore) {
	 this.xmlstore = xmlstore;
      }

       // The time between stabilizing operations (half a minute)
      private static final int INTERVAL = 30000;

      // Number of fingers to check at each interval
      private static final int FINGERS = 7;

      public void run() {
         while( !isInterrupted() ) {
            try {       
               Thread.sleep(INTERVAL);   
               xmlstore.stabilize();
	       for (int i = 0; i < FINGERS; i++)
		  xmlstore.fixFingers();
	       //assert checkChordRing() == 0 : "Error in chord ring.";
            }
            catch (InterruptedException e){	       
	       // ok, we have been interrupted...
	    }
            catch (Exception e) {
	       // An error occured
	       // stop stabilizing
	       interrupt();
            }
         }
      }
   } // End inner class


   //-----------------------------------------------------------------
   // Concurrent storing of nodes


   private static class SaveThread extends Thread {
      private XmlStoreServerImpl xmlstore;
      private NodeQueue nodes;
      private ConcurrencyManager cm;


      public SaveThread(XmlStoreServerImpl xmlstore, NodeQueue nodes, ConcurrencyManager cm) {
	 this.xmlstore = xmlstore;
	 this.nodes = nodes;
	 this.cm = cm;
      }
      
      public void run() {
         while( !isInterrupted() ) {
            try {
	       NodeQueue.Entry entry = nodes.get();	       
	       xmlstore.saveValue(entry.node.getBytes(), entry.node.getValueReference());
	       entry.node.markAsSaved();	       
	       // Tell ConcurrencyManager that one save operation has finished
	       cm.endPartialOperation(entry.opId);
	    }
            catch (RemoteException e) {
	       // An error occured!	 
            }
         }
      }
   } // End inner class


   // Synchronized queue for concurrent saving of nodes
   private static class NodeQueue {
      private LinkedList list = new LinkedList();

      private static class Entry {
	 public int opId;
	 public Node node;
	 
	 public Entry(int opId, Node node) {
	    this.opId = opId;
	    this.node = node;
	 }
      }
      
      public synchronized void put(Node node, int opId, boolean lastNode) {
	 list.addFirst(new Entry(opId, node));
	 notifyAll();
      }

      public synchronized Entry get() {
	 try {
	    while ( list.isEmpty() ) {wait();}
	 }
	 catch (InterruptedException e) {
	    // okay, we are terminating the thread
	 }
	 return (Entry) list.removeLast();
      }    
   } // End inner class


   private static class ConcurrencyManager {
      private static class Entry {
	 public int total = 0;
	 public int completed = 0;
	 public boolean last = false;
	 public final boolean isComplete() {
	    return last && total == completed;
	 }
      }

      private HashMap entries = new HashMap();
      public synchronized void beginPartialOperation(int opId, boolean last) {
	 // Lookup opId -- if there is no record of opId so far, create a new one
	 Integer id = new Integer(opId);
	 Entry entry = (Entry)entries.get(id);
	 if ( entry == null ) {
	    entry = new Entry();
	    entries.put(id, entry);
	 }

	 // If this is the last node in this series, note it
	 assert !entry.last : "Operation marked as last twice.";
	 if (last)
	    entry.last = last;
	 
	 // Update total
	 entry.total++;	 
      }

      public synchronized void endPartialOperation(int opId) {
	 // If there is no record of opId so far, throw exception
	 Integer id = new Integer(opId);
	 Entry entry = (Entry)entries.get(id);

	 if (entry == null)
	    throw new RuntimeException("Error in CompletionCounter during concurrent save.");
	 
	 entry.completed++;

	 // If operation is complete notify waiting threads
	 if (isComplete(opId))
	    notifyAll();
	 
      }

      public synchronized boolean isComplete(int opId) {
	 Integer id = new Integer(opId);
	 Entry entry = (Entry)entries.get(id);
	 return entry != null && entry.isComplete();
      }

      // Logic for handling when a 
      public synchronized void waitUntilFinished(int opId) {
	 try {
	    while (! isComplete(opId) ) 
	       wait();
   	    // Remove entry
	    entries.remove(new Integer(opId));
	 }
	 catch (InterruptedException e) {
	    // Not much to do...
	    assert isComplete(opId);
	 }
      }
   } // End inner class


   //*** Test method for accessing the chord rings correctness  ***
   private int checkChordRing() {
      int errors = 0;
      int servers = 0;
      boolean wrappedAround = false;
      try {
         ChordNode n = this;
         do {
            // Check that ids only rise. Can only wrap around once.
            if ( n.serverId().greaterThan(n.successor().serverId()) ) {
               assert !wrappedAround : "Wrap around detected twice";
               wrappedAround = true;
            }

            if ( n.serverId().equals(n.successor().serverId()) )
               assert n == n.predecessor() : "Loop in Chord ring at " +
               n.serverId();

            // Check predecessor property
            assert n.serverId().equals(n.successor().predecessor().serverId()) :
                            "Predecessor at node " + n.successor().serverId() +
                            " should be " + n.serverId() + ", but is " +
                            n.successor().predecessor().serverId();
         } while ((n = n.successor()) != this);
      }
      catch (RemoteException e) {
         assert false : "Exception checking chord ring: " + e;
      }

      // report number of errors in finger tables
      return errors;
   }
}
