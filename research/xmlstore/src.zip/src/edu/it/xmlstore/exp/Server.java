package edu.it.xmlstore.exp;

import java.io.*;
import java.net.*;

public class Server extends Thread {
   private static int port = 7070;
   private ServerSocket serverSocket;

   public static void main(String[] args) {
      Server server = new Server();
      server.start();
      System.out.println("Server started at port " + port);   
   }
   

   public Server() {
      try {
         serverSocket = new ServerSocket(port);
      }
      catch (IOException e) {
         System.err.println("Could not create ServerSocket:" + e.toString());
         System.exit(0);
      }
   }


   public void serve() {
		ClientThread clientThread = null;
		try {
         clientThread = new ClientThread(serverSocket.accept());
         clientThread.start();
      }
      catch(IOException e) {
	      System.err.println("Could not start Server: " + e);
	      System.exit(0);
	   }
	}


   public void run() {
      while(true)
	      serve();
   }


   // Inner class that handles communication with the client.
   private class ClientThread extends Thread {
   	Socket clientSocket;
   	DataInputStream in;

   	ClientThread(Socket clientSocket) throws IOException {
   		this.clientSocket = clientSocket;
   		in = new DataInputStream(clientSocket.getInputStream());
   	}

   	public void run() {
   	   try {            
            byte[] message = new byte[817];
            in.readFully(message);            
            
            DataOutputStream out =
               new DataOutputStream(
                  new BufferedOutputStream(clientSocket.getOutputStream()));
            
            String reply = "Stanley Kubrick Rules!";      
            out.write(reply.getBytes());
            out.flush();                     
            clientSocket.close();
         }
   	   catch(IOException e) {
   	      System.err.println("Error in Server: " + e);
   	      System.exit(0);
   	   }
   	}
   }
}