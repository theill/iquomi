package edu.it.xmlstore.exp;

import java.io.*;
import java.net.*;

public class Client {
   private InetSocketAddress address = 
                  //new InetSocketAddress("130.226.143.208", 7070);
                  new InetSocketAddress("localhost", 7070);
   public static final int MESSAGES = 1000;
   
   public static void main(String[] args) throws IOException {
      Client client = new Client();
      String message = 
         "All work and no play makes Jack a dull boy " +
         "All work and no play makes Jack a dull boy " +
         "All work and no play makes Jack a dull boy " +
         "All work and no play makes Jack a dull boy " +
         "All work and no play makes Jack a dull boy " +
         "All work and no play makes Jack a dull boy " +
         "All work and no play makes Jack a dull boy " +
         "All work and no play makes Jack a dull boy " +
         "All work and no play makes Jack a dull boy " +
         "All work and no play makes Jack a dull boy " +
         "All work and no play makes Jack a dull boy " +
         "All work and no play makes Jack a dull boy " +
         "All work and no play makes Jack a dull boy " +
         "All work and no play makes Jack a dull boy " +
         "All work and no play makes Jack a dull boy " +
         "All work and no play makes Jack a dull boy " +
         "All work and no play makes Jack a dull boy " +
         "All work and no play makes Jack a dull boy " +
         "All work and no play makes Jack a dull boy.";               
         
      System.out.println("Starting:");
      long start = System.currentTimeMillis();
      for (int i = 1; i <= MESSAGES; i++) {         
         byte[] returnValue = client.sendTestMessage(message.getBytes());         
         System.out.print(".");
      }            
      long stop = System.currentTimeMillis();
      System.out.println("\nDone!");
      System.out.println("" + MESSAGES + " messages in " + (stop - start) + "ms.");
      System.out.println("Average " + (stop - start)/MESSAGES + " messages per second");
   }
     
   private Socket connect() throws IOException {
      Socket socket = new Socket();
      socket.connect(address, 0);
      return socket;      
   }


   private void disconnect(Socket socket) throws IOException {
      socket.close();
   }

   private void sendBytes(byte[] arg, Socket socket) throws IOException {
      DataOutputStream out =
               new DataOutputStream(
                  new BufferedOutputStream(socket.getOutputStream()));
      out.write(arg);
      out.flush();
   }

   private byte[] receiveReturnValue(Socket socket) throws IOException {
      DataInputStream in = new DataInputStream(socket.getInputStream());
      byte[] returnValue = new byte[22];      
      in.readFully(returnValue);
      return returnValue;
   }


   public byte[] sendTestMessage(byte[] value) throws IOException {
      Socket socket = connect();
      sendBytes(value, socket);
      byte[] result = receiveReturnValue(socket);
      disconnect(socket);
      return result;
   }
}