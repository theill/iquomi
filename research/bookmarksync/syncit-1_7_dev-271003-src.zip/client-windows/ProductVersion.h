#ifndef SYNCIT_V_STR
# define SYNCIT_V_STR "1.6.4"
# define SYNCIT_V_MAJOR 1
# define SYNCIT_V_MINOR 6
# define SYNCIT_V_BUGFIX 4
# define SYNCIT_V_BUILD 7
# define SYNCIT_V_INFO_STR "1, 6, 4, 7\0"
# define APP_REG_KEY "Software\\SyncIT"
#endif /* SYNCIT_V_STR */
