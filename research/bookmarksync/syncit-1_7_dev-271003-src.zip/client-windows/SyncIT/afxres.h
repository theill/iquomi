#include "winresrc.h"
#define IDC_STATIC (-1)
