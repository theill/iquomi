// server.dll
//
// This assembly implements the ICalc interface that the
// client wants to program against, and fires the event
// that's being demonstrated by the sample.
//
// Mike Woodring
// http://staff.develop.com/woodring
//
using System;
using System.Runtime.Remoting;

class Server
{
	static void Main()
	{
		RemotingConfiguration.Configure("server.exe.config");
		Console.WriteLine("Host started.  Press ENTER to exit.");
		Console.ReadLine();
	}
}

public class Calc : MarshalByRefObject, ICalc
{
	public int add( int a, int b )
	{
		int sum = a + b;

		if( (sum == 4) && (MagicNumber != null) )
		{
			Console.WriteLine("Firing magic number event.");

			try
			{
				MagicNumber(sum);
			}
			catch( Exception e )
			{
				Console.WriteLine("Failed to fire event.");
				Console.WriteLine(e.Message);
				throw e;
			}
		}

		return(sum);
	}

	public string AppDomainName
	{
		get { return(AppDomain.CurrentDomain.FriendlyName); }
	}

	public event MagicNumberCallback MagicNumber;
}
