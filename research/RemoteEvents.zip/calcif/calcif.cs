// calcif.dll
//
// Contains the interface (ICalc) used between the
// client and server, along with the EventShim
// class that's being demonstrated.
//
// Mike Woodring
// http://staff.develop.com/woodring
//
using System;

public delegate void MagicNumberCallback( int n );

public interface ICalc
{
	string AppDomainName { get; }
	int add( int a, int b );
	event MagicNumberCallback MagicNumber;
}

public class EventShim : MarshalByRefObject
{
	private MagicNumberCallback target;

	private EventShim( MagicNumberCallback target )
	{
		this.target += target;
	}

	public void MagicNumberShim( int n )
	{
		target(n);
	}

	public static MagicNumberCallback Create( MagicNumberCallback target )
	{
		EventShim shim = new EventShim(target);
		return new MagicNumberCallback(shim.MagicNumberShim);
	}
}