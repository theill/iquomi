// client.exe
//
// This sample demonstrates how to setup a server->client callback
// via an event such that the server does not need access to the
// client's assembly at runtime.
//
// When a client registers a delegate with a server via remoting,
// the delegate instance is marshaled by value to the server.
// The delegate itself holds a reference to the client callback
// target.  Assuming the client type extends MarshalByRefObject,
// this means that when the delegate is deserialized on the
// server side of things, a proxy back to the client will be setup.
// In order for this to succeed, the type information for the
// client is needed, which means that the client's assembly needs
// to be present on the server machine and locatable via the
// standard rules of assembly resolution.  This introduces
// an undesirable coupling between the server and all of its
// clients.
//
// The work around is to introduce a shim or forwarder between the
// client and server so that the server need only have access to the
// assembly containing the shim class.  This shim class can be located
// any assembly - as long as both clients and server have access to
// it.
//
// In this sample, there are two apps: client.exe and host.exe.
// Client.exe is the obvious client, and host.exe is just a shell
// app that calls RemotingConfiguration.Configure to parse
// host.exe.config.  This configuration file specifies that the
// Calc type from the server.dll assembly should be made available
// via remoting.  You can substitute host.exe in the diagrams below
// for IIS or any other host process you might be using.
//
// An assembly named calcif.dll contains an interface (ICalc) that
// is implemented in the server assembly and programmed against by
// the client.  This interface includes an event (of type
// MagicNumberCallback) that the client wants to register for.
//
// If the client simply does something like this:
//
// proxyToServer.MagicNumber += new MagicNumberCallback(OnMagicNumber)
//
// the you end up with a picture that looks something like this
// (where || indicates a process/machine boundary):
//
// [client.exe]     [................server.exe.........................]
// ClientObj <-- || <-- ProxyToClient <-- MagicNumberCallback <-- CalcObj
//
// This is the scenario that breaks, since the server needs access to client.exe in order
// to construct proxy to the client.  If, instead, the client instantiates
// the EventShim class from calcif.dll, passing the shim a delegate to the client method;
// and then passes the shim (which extends MBRO), then you get the following picture:
//
// [.................client.exe...................]   [................server.exe.......................]
// ClientObj <-- MagicNumberCallback <-- EventShim || <-- ProxyToShim <-- MagicNumberCallback <-- CalcObj
//
// Given this, the server process now need only have access the EventShim type
// information, which is included in the assembly (calcif.dll in this sample)
// that both the client and server have access to.
//
// The added overhead of the EventShim instance in the client
// process is inconsequential compared to the overhead of crossing
// the process/machine boundary between the client and the server.
//
// You can also change the EventShim class to use the standard EventHandler
// delegate and EventArgs to come up with a more generic solution.  This
// solution allows you to write the EventShim one time and use it for any
// number of situations, although you'll need to define custom EventArgs-derived
// structures to ferry the parameters back and forth as desired.  Just
// choose the approach that's more comfortable for your situation.
//
// To play with this sample, build using 'nmake' from a cmd shell
// situated wherever you've unzipped this code.  The build process
// will create two subdirectories named s (for server) and c (for client),
// and copy only the server or client code to each directory respectively.
// This simulates the failure situation that occurs without using the
// shim approach (because the server directory does not have the client
// assembly in it).
//
// Start host.exe and then run client.exe to perform the test.
//
// To test the cross-machine case, modify the calcURL key in
// client.exe.config to match your networking situation (and optionally
// host.exe.config if you want to select an alternative port for
// the server).
//
// Mike Woodring
// http://staff.develop.com/woodring
//
using System;
using System.Configuration;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Activation;

class Client
{
	static void Main()
	{
		RemotingConfiguration.Configure("client.exe.config");

		ICalc c = (ICalc)
			RemotingServices.Connect(typeof(ICalc), ConfigurationSettings.AppSettings["calcURL"]);

		MagicNumberCallback cb = EventShim.Create(new MagicNumberCallback(OnMagicNumber));
		c.MagicNumber += cb;

		Console.WriteLine("c.AppDomainName (Calc) = {0}", c.AppDomainName);
		Console.WriteLine("2 + 2 (Calc) = {0}", c.add(2, 2));
		Console.WriteLine("4 + 4 (Calc) = {0}", c.add(4, 4));

		c.MagicNumber -= cb;
	}

	static void OnMagicNumber( int n )
	{
		Console.WriteLine("Magic number ({0}) computed!", n);
	}
}
