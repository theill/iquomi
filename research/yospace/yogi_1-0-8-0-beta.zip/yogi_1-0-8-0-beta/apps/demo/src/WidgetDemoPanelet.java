// COPYRIGHT 1999-2002 YOSPACE HOLDINGS PLC. ALL RIGHTS RESERVED.

import com.yospace.yae.pm.Panelet;
import com.yospace.yae.yogi.ActionListener;
import com.yospace.yae.yogi.YogiComponent;
import com.yospace.yae.yogi.YogiButton;
import com.yospace.yae.yogi.YogiContentPane;
import com.yospace.yae.yogi.YogiDropDownMenu;
import com.yospace.yae.yogi.YogiMenu;
import com.yospace.yae.yogi.YogiMenuBar;
import com.yospace.yae.yogi.YogiPopup;
import com.yospace.yae.yogi.YogiPaneletDisplay;
import com.yospace.yae.yogi.YogiProgressBar;

//A Panelet which demostrates some of the widgets available within the core YoGI API.
public class WidgetDemoPanelet extends Panelet
{
	public static final int FILE_MENU_EXIT_INDEX = 4;

	private int itemNumber;

	// Simply sets up the item number
	public WidgetDemoPanelet()
	{
		itemNumber = 6;
	}

	// Gets components from the UI and configures them, wiring up action listeners etc.
	public void start() throws Exception
	{
		// Get the Panelet display, it's title bar and it's content pane
        YogiPaneletDisplay paneletDisplay = getPaneletDisplay();
		YogiMenuBar menuBar = (YogiMenuBar)paneletDisplay.getMenuBar();
		YogiContentPane mainPanel = (YogiContentPane)paneletDisplay.getContentPane();

		// Get the file menu and set up a listener on it
		YogiMenu fileMenu = (YogiMenu)menuBar.getComponent("fileMenu");
		fileMenu.addMenuListener(FILE_MENU_EXIT_INDEX, new FileMenuListener());

		// Set up the button on panel 1 to generate a popup when pressed
		YogiButton yb = (YogiButton)mainPanel.getComponent("helloButton");
		yb.setActionListener(new DialogDisplayer());

		// Populate a model for the drop down menu on panel 1.  Note that if the contents
		// are known at design-time then we can do this in the XML
		YogiDropDownMenu menu = (YogiDropDownMenu)mainPanel.getComponent("ddMenu");
		menu.addItem("option 1");
		menu.addItem("option 2");
		menu.addItem("option 3");
		menu.addItem("option 4");
		menu.addItem("option 5");
		menu.addItem("option 6");

		// Wire up the plus and minus buttons on panel 2 to move the progress bar accordingly
		YogiProgressBar pBar = (YogiProgressBar)mainPanel.getComponent("progressBar");
		YogiButton plusButton = (YogiButton)mainPanel.getComponent("plusButton");
		YogiButton minusButton = (YogiButton)mainPanel.getComponent("minusButton");
		minusButton.setActionListener(new ProgressBarMinuser(pBar));
		plusButton.setActionListener(new ProgressBarPluser(pBar));
	}

	public String getPaneletInfo()
	{
		return "YoGI Demo Panelet";
	}

	/* Private Classes which serve as action listeners. */

	// Listens for when "Exit" is pressed and calls notifyDestroyed()
	private class FileMenuListener implements ActionListener
	{
		// We know the source is the "Exit" menu item in this case
		public void actionPerformed(YogiComponent source)
		{
			notifyDestroyed();
		}
	}

	// Subtracts 1 from the value of the associated progress bar
	private class ProgressBarMinuser implements ActionListener
	{
		private YogiProgressBar pBar;

		// Takes a reference to the progress bar when constructed
		public ProgressBarMinuser(YogiProgressBar pBar)
		{
			this.pBar = pBar;
		}

		// Gets the current value and sets it to be one lower
		public void actionPerformed(YogiComponent source)
		{
			int v = pBar.getValue();
			pBar.setValue(--v);
		}

	}

	// Adds 1 to the value of the associated progress bar
	private class ProgressBarPluser implements ActionListener
	{
		private YogiProgressBar pBar;

		// Takes a reference to the progress bar when constructed
		public ProgressBarPluser(YogiProgressBar pBar)
		{
			this.pBar = pBar;
		}

		// Gets the current value and sets it to be one higher
		public void actionPerformed(YogiComponent source)
		{
			int v = pBar.getValue();
			pBar.setValue(++v);
		}

	}

	// Generates a dialog when an action has been performed on the associated component
	private class DialogDisplayer implements ActionListener
	{
		public void actionPerformed(YogiComponent source)
		{
			// Get the message from the String resources (allows for internationalization)
			String message = getStringResource("en.dialog_message");

			// Show a dialog which simply gets removed when the ok button is pressed
			YogiPopup.showDialog(source, YogiPopup.DIALOG_ALERT, message, null, null);
		}
	}
}