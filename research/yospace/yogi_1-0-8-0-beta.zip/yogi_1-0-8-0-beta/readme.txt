YoGI 1.0 Beta build 8 
=====================


Introduction 
------------

The Yospace Graphical Interface ("YoGI") constitutes an API enabling Java 2
Micro Edition (J2ME) developers to create high- end mobile device
applications with user interfaces that are customised on a per-device
basis. These applications, or 'Panelets', can be provisioned to the mobile
device, perhaps over the wireless network, and can be treated as standalone
applications (in much the same way as MIDlets), or might be collected
together into a suite of Panelets managed by a Yospace Panelet management
framework.


- Customisable look-and-feel

The YoGI Toolkit includes a set of graphical components that have
customisable look-and-feel.  The application writer can customise component
attributes such as background colour.  They can even completely take
control as to how a component is rendered (for example, to force all
buttons to have a certain background image embedded).

Where the application writer does not explicitly change the look-and-feel
of its component, the default look-and-feel will be used.  In a Panelet
managed framework, there is one default look-and-feel for all Panelets.
This look-and-feel will be installed on a user's device based, perhaps, on
the user's preference and factors such as service providers' requirements.


- Fully-customisable placement of components

The developer can also specify absolute positioning of these components,
without having to rely on a layout manager that has to try to cater for
different device screen specifications.  In fact, the layout of a Panelet's
user interface can be completely separated from the Panelet's application
code.  This separation of view and model enables mobile device applications
to support many different user interface layouts across the range of
devices and form factors.  Within YoGI, user interface layout is defined in
XML format, and this XML can easily be modified for different device form
factors.


- What YoGI offers the mobile device application developer

The low-level MIDP user interface API allows the application designer to
draw lines, rectangles and other basic shapes on a Canvas.  However, there
is no concept of components such as labels and buttons at this level. The
high-level API does include component 'widgets', but the appearance and
placement of such widgets is highly dependent on the implementation of the
API on the target device.  Various extensions to MIDP exist which afford
the application writer more control over look- and-feel and placement, but
these APIs tend to be centred around the use of heuristics in order to
achieve these objectives. The YoGI API allows component placement to be
designed on a per-device basis.  It thus represents a 'higher-level' API
boasting greater user interface customisability- something that is not
available in such a convenient way to the contemporary Java-enabled mobile
device application writer.

Added to this, YoGI's flexible event management enables developers to
produce applications with customisable navigation, ensuring usability
across the full range of phones and PDAs.


Distribution 
------------

The following are distributed within this zip file:

- yogi_core directory: holding the set of YoGI classes and resources to be
used in order to view a Panelet.
- the bin directory: holding the bytecoder tool code.
- docs directory: containing javadocs for the core components of the YoGI
API.
- apps directory: containing an example directory structure for YoGI
application development.
- WidgetDemoPanelet.java: in the apps\demo\src directory.  A basic example
of Panelet application code.
- WidgetDemoPanelet-3GCP.xml: in the apps\demo\xml directory.  The UI
configuration file for the Yospace 3G Concept Phone.
- WidgetDemoStringResources_en_EN.xml: in the apps\demo\xml directory.  The 
String resources used by the WidgetDemoPanelet. 
- PaneletConfig.xml: in the apps\demo\xml directory.  The Panelet 
configuration file with details of the WidgetDemoPanelet application.
- Yo.png: in the apps\demo\res directory.  A portable network graphics file
used by the demo app.
- license.txt: the Yospace license agreement.
- suppliers.txt: the enhydra license agreement for the use of kxml.
- readme.txt: this file.


Getting Started 
---------------

This mini-tutorial is designed to highlight the steps required to prepare a
Panelet which displays examples of the widgets available within the YoGI core
code, for running on a MIDP-enabled device or emulator.

Note that although this tutorial is geared towards MS-DOS command line
entry, only two basic changes should be required for the Unix/Linux user:
class path fields should be ':' instead of ';' delimited, and path separators
should be the '/' character as opposed to the '\' character.


- Prerequisites

  - Sun's J2SE JDK: This tutorial requires Sun's J2SE JDK, with the 'bin'
  directory of the JDK in the command line path. Note that this tutorial has 
  only been tested with version 1.3.0 of the JDK.

  - Sun's J2ME Wireless Toolkit: In order to generate .jar files that can
  be used within a KVM-based device or emulator, class files to be placed
  in that .jar need to be 'preverified'.  Sun include a preverify
  executable with their distribution of the J2ME Wireless Toolkit.  Also
  included in that distribution is an implementation of the MIDP API,
  required when preverifying files.  It is therefore recommended that if
  the reader intends to use the generated MIDlet suite with a KVM based
  device (which includes the Sun J2MEWTK Emulator), then they should have
  already installed the Sun J2ME Wireless Toolkit on their machine before
  continuing with this tutorial.  Where this toolkit has been installed, it
  is presumed that it has been installed in the default location of
  'c:\j2mewtk' from hereon in.

  Note that the Yospace MIDP Emulator is based upon the JVM as opposed to
  the KVM.  Thus, class files used on the Yospace emulator do not need to
  be preverified.  Therefore, if the intention is that the generated MIDlet
  suite be used solely on JVM-based devices, including the Yospace J2ME
  Emulator, then the reader can skip the preverification stage listed
  below, and in this case the J2ME Wireless Toolkit is NOT a prerequisite.


- Creating a "Hello World" YoGI Standalone Application

The 'apps' directory of the YoGI distribution represents a recommended
directory structure for developing YoGI applications. It is based heavily
around the structure used within the Sun J2ME Wireless Toolkit
distribution.  For each YoGI application a new subdirectory is created.  It
is recommended that this new directory contains the following
subdirectories:

src - where Java source code is located,
res - where associated non-Java and non-XMl files, such as PNG images.
tmpclasses - where compiled but un-preverified Java code is stored,
classes - where preverified compiled Java code is located, 
xml - where XML user interface appearance files are stored,
xmlc - where bytecoded versions of the files in the xml directory are
stored, and finally,
bin - where the application, in the form of a .jar file is stored along
with support files such as the application descriptor file (".jad")

The 'apps' directory currently contains one directory - 'demo' - which in
turn contains the file WidgetDemoPanelet.java in the 'src' directory, the 
files WidgetDemoPanelet-3GCP.xml, PaneletConfig.xml and
WidgetDemoStringResources_en_EN.xml in the 'xml' directory, and finally 
Yo.png in the 'res' directory.

WidgetDemoPanelet.java is a trivial example Panelet which adds no extra
functionality to a base YoGI Panelet, except that it sets up a listener so
that the application quits when the title bar's 'X' button is pressed.
WidgetDemoPanelet.xml gives the XML description of the layout and
appearance of this Panelet, customised so that the components are neatly
arranged when displayed on the Yospace 3G Concept Phone.  The file
WidgetDemoStringResources_en_EN.xml contains String resource mappings so
that successful internationalization of the Panelet can be achieved. The 
file PaneletConfig.xml maps the Panelet to its XML UI descriptor file and
the String resources file for this device and locale.  Finally, Yo.png
is a Portable Network Graphic rendering of the Yospace logo.

In order for the WidgetDemoPanelet to be displayable on a MIDP-enabled
device or emulator, the following should be done from the command line.

1. Move to the 'demo' subdirectory of the 'apps' directory.

2. Compile the source code into the un-preverified 'tmpclasses' directory.
The core YoGI API will need to be referenced by the compiler here, and the
directory 'yogi_core' should therefore be included in the class path at
this point.  An example command line:

  javac -d tmpclasses -classpath ..\..\yogi_core\classes 
                                               src\WidgetDemoPanelet.java

Note here that if the target device or emulator is JVM-based, and therefore
preverification of the class files is not required, the reader can instead
use the command -

  javac -d classes -classpath ..\..\yogi_core\classes 
                                               src\WidgetDemoPanelet.java

- placing the un-preverified classes straight into the 'classes' directory,
and then skip to stage 4.

3. Preverify the newly-generated class files and place them in the
'classes' directory.  With the Sun J2ME Wireless Toolkit installed in
'c:\j2mewtk', an example command might be:

  c:\j2mewtk\bin\preverify -d classes -classpath
  ..\..\yogi_core\classes;c:\j2mewtk\lib\midpapi.zip tmpclasses

4. Encode the XML files in the 'xml' directory and place them in the
'xmlc' directory.  This can be done manually by starting the XmlEncoder GUI
and encoding the three XML files in turn (saving them into 'xmlc').  To
start the GUI type:

  java -jar ..\..\bin\XmlEncoder.jar

Alternatively, by running the encoder from the command line, an entire
directory and subdirectories can be encoded in one go.  To achieve this,
type:

  java -jar ..\..\bin\XmlEncoder.jar -d xmlc xml 

5. Generate a .jar manifest file in the 'bin' subdirectory of the 'demo'
directory.  This file will be added to the .jar and is reference by some 
wireless devices in order to extract MIDlet suite details such as constituent 
MIDlet names and application property settings.  For the WidgetDemoPanelet 
application, the following are the suggested contents of the manifest file:

  MIDlet-1: YoGI Demo, , com.yospace.yae.midlet.YaeMIDlet
  MIDlet-Name: Widget Demo
  MIDlet-Vendor: Yospace Holdings Ltd
  MIDlet-Version: 1.0
  PaneletConfig: /PaneletConfig.xmlc
  UIManager: com.yospace.yae.standard.color.plaf.StandardPlafUIManager

This manifest file should be called "MANIFEST.MF" and stored in the 'bin'
subdirectory.  Note that trailing whitespace at the end of each line should
be avoided, as it is less than clear from the MIDP specification that a MIDP
implementation MUST always remove such spaces.

6. Generate a .jar file in the 'bin' directory.  This again requires
referencing of the files in the 'yogi_core' directory.  Firstly, add the core
class files to a new jar:

  jar cfm bin\YoGIDemo.jar bin\MANIFEST.MF -C ..\..\yogi_core\classes . 
   -C classes . 

Then add in the color plaf:

  jar uf bin\YoGIDemo.jar -C ..\..\yogi_core\plafs\standard\color\classes . 
   -C ..\..\yogi_core\plafs\standard\color\xmlc . -C 
   ..\..\yogi_core\plafs\standard\color\res .   

Then, update the jar with the resource files:

  jar uf bin\YoGIDemo.jar -C ..\..\yogi_core\xmlc . -C ..\..\yogi_core\res .
  -C xmlc . -C res .

7. Generate a .jad file in the 'bin' directory.  Because some devices use
the manifest file as a reference for application settings, while others use
the .jad (while others use a combination of both), it is usually prudent to
generate a .jad file with the same settings as the manifest file -

  copy bin\MANIFEST.MF bin\YoGIDemo.jad

- and then add the following extra settings (required of a .jad file):

  MIDlet-Jar-Size: x 
  MIDlet-Jar-URL: YoGIDemo.jar

With the above, 'x' should be substituted with the size (in bytes) of the
.jar generated above.

At this point, YoGIDemo.jar and YoGIDemo.jad are ready to be used either on 
a MIDP-enabled device, or on an emulator such as that included in the Sun 
J2ME Wireless Toolkit distribution, or the Yospace MIDP Emulator.  The XML 
appearance descriptor is based around the screen specifications of the 
Yospace 3G Concept Phone.  To view the Panelet on this device, two options 
exist:

1. Download and install the Yospace J2ME Emulator from the YoZone site.
The Yospace 3G Concept Phone is the default device. The YoGIDemo
Panelet can be viewed by selecting "Options" -> "Open File" and then
selecting the YoGIDemo.jad descriptor file.

2. Upload YoGIDemo.jar and YoGIDemo.jad to a publicly accessible server and 
activate the Yospace on-line 3G Concept Phone Emulator. Select "Install Suite" 
from the bottom of the popup screen and at the prompt enter the URL of the 
uploaded YoGIDemo.jad descriptor file.

YoGI comes pre-bundled with two Pluggable Look-And-Feels (PLAFs): the
standard color one used in the above example, and a standard mono one.
Switching PLAFs easily is an important feature of the YoGI architecture, and
to achieve this with the example above simply return to stage 5 and change
the 'UIManager' setting to:

com.yospace.yae.standard.mono.plaf.StandardPlafUIManager 

And when creating the jar, include the mono plaf Classes instead:

  jar uf bin\YoGIDemo.jar -C ..\..\yogi_core\plafs\standard\mono\classes . 
   -C ..\..\yogi_core\plafs\standard\mono\xmlc . -C 
   ..\..\yogi_core\plafs\standard\mono\res .   

For further examples on how to program YoGI Panelets please see the YoGI
documentation section of the YoZone site.


Documentation 
-------------

YoGI API javadocs are distributed within this zip.  Other resources will be 
added from time to time to the Yospace developers' site - YoZone - at 
http://yozone.yospace.com/


Changes since the Alpha release
-------------------------------

- Bytecoding. YoGI now expects xmlc (XML bytecode) as opposed to XML. A 
  bytecoder tool is shipped with YoGI to perform this conversion.
- Panelet Management. Simple panelet management architecture included, 
  allowing starting and termination of installed panelets.
- Panelet configuration. Configure the panelets to be made available for 
  installation via an xml file.
- Panelet configuration. Configure the component, hotkey and keypress mappings 
  for a given UI via an xml file.
- YogiTabbedPanes added.
- Cell borders added to lists and tables.
- Drop down menus now have scroll notching.
- Scroll panes may now contain multiple components.
- Lists and tables can now use YogiImageComponent as a cell renderer to render 
  images.
- DTD updated to reflect API changes.
- PLAF name change. The Alpha plaf has now been replaced with two 'standard' 
  plafs, to be found in packages com.yospace.yae.standard.color and 
  com.yospace.yae.standard.mono.
- Improved startup failure notification. Failure messages have also been 
  internationalized.
- Image class added.
- Class renaming. Term 'Yogi' now prepended only to subclasses of YogiComponent.
- Property renaming. 
- Internationalization support added. Use String resource files to make all text 
  in a Panelet readily configurable.
- Improved fonts.
- Hotkeys.
- Support for YoBeans.


Known Issues 
------------

- Resizing of components that are direct children of composite components such 
as YogiPaneletDisplays and YogiScrollPanes does not automatically result in the 
parent composite component's UI layout method being called.  If this functionality 
is required, a workaround is to explicitly call this method after such a resizing 
instruction by calling, for example:

  ((CompositeUI)theComponent.getParent().getUI()).layout();

Work is commencing to make this process implicit in the full release of YoGI.

- Default sizing of drop down menus. Should really default to the largest element 
in the list.  Currently just uses the plaf default.  Workaround is to specify the 
bounds explicitly.

- Various minor repainting problems.


Feedback 
--------

Feedback about this Beta release should be submitted to the Yospace developer zone: 

  http://yozone.yospace.com/

