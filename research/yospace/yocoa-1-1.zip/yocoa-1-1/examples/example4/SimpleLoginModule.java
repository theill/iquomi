// COPYRIGHT 1999-2001 YOSPACE HOLDINGS PLC. ALL RIGHTS RESERVED.
//
import java.util.*;

import com.yospace.yocoa.server.aas.Credentials;
import com.yospace.yocoa.server.aas.LoginModule;
import com.yospace.yocoa.services.ChallengeException;

/**
 * A simple LoginModule which simply checks against declared usernames.
 * No passwords are required.
 * <br>
 * To deploy the module reuired an initParam of
 * <pre>
 	&lt;initParam key="users" value="fred,bob,mary,jane"/&gt;
	</pre>
 * followed by connectinfo containing the pair "username" and actual user's name.
 * The user's name will be added into the credentials, keyed by
 * SimpleLoginModule.userName
 */
public final class SimpleLoginModule implements LoginModule
{
	// to store the users who can connect
	private Vector permittedUsers = new Vector();

	//init is called when the LoginModule is created
	public void init(Hashtable context)
	{
		//retrieve the users, and store as Permitted Users
		//A real LoginModule would be expected to retrieve
		//authentication information from an external source,
		//perhaps accessed using params specified as initParams
		String declaredUsers = (String)context.get("users");
		if (declaredUsers != null)
		{
			StringTokenizer strtok = new StringTokenizer(declaredUsers,",");
			while (strtok.hasMoreTokens())
			{
				String user = strtok.nextToken();
				permittedUsers.addElement(user);
			}
		}
	}

	//login is called whenever a client attempts to connect
	//typically this should use more than a single piece of information
	//from the connectInfo
	public boolean login(Hashtable connectInfo, Credentials credentials)
		throws ChallengeException
	{
		boolean authenticated = false;

		//process the connectInfo - sent from the client
		if (connectInfo != null)
		{
			Enumeration enum = connectInfo.keys();
			String key;
			while (enum.hasMoreElements() == true)
			{
				key = (String)enum.nextElement();
				if ("username".equals(key.toLowerCase()))
				{
					String user = (String)connectInfo.get(key);

					//if conenction info specifies user is one of the
					//permitted, add the username to this session's credentials object
					//and return an indication that the user has been authenticated.
					if (permittedUsers.contains(user))
					{
						credentials.put("SimpleLoginModule.userName",user);
						authenticated = true;
					}
				}
			}
		}
		return authenticated;
	}
}

