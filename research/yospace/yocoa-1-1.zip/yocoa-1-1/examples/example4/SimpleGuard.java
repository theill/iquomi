// COPYRIGHT 1999-2001 YOSPACE HOLDINGS PLC. ALL RIGHTS RESERVED.
//
import com.yospace.yocoa.server.SessionView;
import com.yospace.yocoa.server.aas.Credentials;
import com.yospace.yocoa.server.aas.Guard;
import java.util.*;


/**
 * An example Guard which works in conjunction with SimpleLoginModule.
 * When initialiased it is given a list of users who may exercise this method.
 */
public class SimpleGuard extends Guard
{
	private Vector permittedUsers;
	/**
	 * Create a simple guard which allows the users name in the "users" key of the param
	 * hashtable. The value at the users key is a comma separated string of users.
	 * <br>
	 * @param param			additonal parameters read from the deplotment descriptor.
	 * @param global		true if this is a result of a globally defined condition
	 */
	public SimpleGuard(Hashtable param, boolean global)
	{
		super(param, global);
		permittedUsers = new Vector();
		StringTokenizer strtok = new StringTokenizer((String)param.get("users"), ",");
		while (strtok.hasMoreTokens())
		{
			String user = strtok.nextToken();
			permittedUsers.addElement(user);
		}
	}

	/**
	 * Called when a Condition is present on a servant method when there
	 * is a global Guard of matching classname.
	 * This method is called on the Guard object for the method, and
	 * is passed the Guard object previously created for the global
	 * conditions. The implementation should check for the correct type of
	 * the argument, then is free to combine the conditions in any way as
	 * appropriate. Usually the global condition shuld not have any state
	 * changed.
	 *
	 * @param Guard		A global Guard of the same type.
	 */
	public void combine(Guard guard)
	{
		if ((guard != null) && (guard.getClass() == getClass()))
		{
			Enumeration users = ((SimpleGuard)guard).permittedUsers.elements();
			while (users.hasMoreElements())
			{
				String user = (String)users.nextElement();
				permittedUsers.addElement(user);
			}
		}
	}

	/**
	 * Called to verify that a method invocation may proceed.
	 * The sessionView gives acess to Credentials - which must contain a
	 * user in the permittedUsers vector.
	 *
	 * @param sessionView	giving access to the context of the current caller.
	 * @param servant 		the object on which the method will be invoked
	 * @param method		the method to be invoked
	 * @param args			the arguments to be passed into the method
	 * @throws SecurityException	if the method should not proceed.
	 */
	public void check(SessionView sessionView, Object servant, String method, Object[] args)
		throws SecurityException
	{
		//retrieve appropriate credential
		// this would have been established by a LoginModule
		Credentials credentials = sessionView.getCredentials();
		String authenticatedName = (String)credentials.get("SimpleLoginModule.userName");

		//permitted users has been construtced during Guard creation
		if (!permittedUsers.contains(authenticatedName))
		{
			//if the credential's authenticated name is null,
			// or not recognised,
			// reject access
			throw new SecurityException("Access denied");
		}
	}
}

