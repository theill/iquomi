// COPYRIGHT 1999-2001 YOSPACE HOLDINGS LTD. ALL RIGHTS RESERVED.
//
import java.io.*;
import java.util.*;
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.io.*;

import com.yospace.yocoa.RemoteException;
import com.yospace.yocoa.j2me.Job;
import com.yospace.yocoa.j2me.Call;
import com.yospace.yocoa.j2me.CallListener;
import com.yospace.yocoa.j2me.Proxy;

/**
The Clock MIDlet uses YoCOA to update a clock as a background process,
using a call-back handler (i.e. a CallListener).
*/
public class ClockMidlet extends MIDlet
    implements CommandListener
{
    private Form requestForm;			// The YoCOA URL request box.
    private Form responseForm;			// The result of the YoCOA request.
    private TextField urlField;			// The URL of the YoCOA servlet.
    private StringItem response;		// The response from the clock server.
    private Proxy clockServer;			// Reference to the clock server.
    private CallListener listener;		// The background processor handler.
    private boolean continueUpdating;	// Flag to indicate whether or not to update the clock.
    private int state = ENTERING_URL;	// Flag to indicate the state of the application (ENTERING_URL or RUNNING);

    // List of states the application can be in.  This allows the application to re-start in the
    // appropriate state after a call to pauseApp.
    private static final int RUNNING = 0;
    private static final int ENTERING_URL = 1;

    /**
    Setup the YoCOA URL request and YoCOA response forms, if this is the first time startApp has
    been called.  If this is not the first time startApp has been called (due the application being
    restarted from a pause), the previous application operation is restarted, e.g. if the previous
    state was RUNNING, the background operation is restarted.
    */
    public void startApp()
    {
        if (requestForm == null)
        {
			// Create the background request handler.
			listener = new CallListener(){
                    // Called automatically when the state of the given call has changed.
					public void stateChanged(Call call)
					{
						String result = null;

						// Get state of operation.
						int state = call.getState();

						if (state == Call.COMPLETED)
						{
							// Request successful.
							result = (String)call.getResult();
						}
						else if (state == Call.ERROR)
						{
							// Request failed.
							Exception e = (Exception)call.getResult();
							result = "Request failed: Message \"" + e.getMessage() + "\"";
						}
						// Note that no actions is required when the state
						// changes to INPROGRESS.   As no retrying is specified, and
						// no calls to Call.cancel() are made, the states RETRYING and
						// CANCELLED states will never occur.

						// If the operation has completed (successfully or
						// otherwise) then display result, pause then restart.
						if ((state == Call.COMPLETED) || (state == Call.ERROR))
						{
							// Display the result.
							displayText(result);

							// Pause before the next request.
							try
							{
								Thread.sleep(500);
							}
							catch (InterruptedException ie)
							{
								// Ignore.
							}

							if (continueUpdating == true)
							{
								// Invoke new request.
								call.start();
							}
						}
					}
				};

			// Don't update -- clock server not yet contacted.
			continueUpdating = false;

	        // Build YoCOA URL request form
	        requestForm = new Form("Enter URL of YoCOA servlet:");
	        urlField = new TextField("URL", "http://", 128, TextField.URL);
	        requestForm.append(urlField);
	        requestForm.addCommand(new Command("Request", Command.SCREEN, 1));
	        requestForm.addCommand(new Command("Exit", Command.EXIT, 1));
	        requestForm.setCommandListener(this);

	        // Build response form
	        responseForm = new Form("Time:");
	        response = new StringItem("", "");
	        responseForm.append(response);
	        responseForm.addCommand(new Command("Back", Command.BACK, 1));
	        responseForm.addCommand(new Command("Exit", Command.EXIT, 1));
	        responseForm.setCommandListener(this);

	        Display.getDisplay(this).setCurrent(requestForm);
		}

		// Check the previous state of the application.  If RUNNING, restart
		// the background operation.
		if (state == RUNNING)
		{
			doRequest();
		}
    }

	/**
	Handle the given Command (request, back or exit).
	This method also handles the maintenance of the state machine, i.e. ENTERING_URL or RUNNING.
	*/
    public void commandAction(Command c, Displayable d)
    {
        switch (c.getCommandType())
        {
        case Command.SCREEN:
        	// 'Rquest' command -- new state is RUNNING.
        	state = RUNNING;
            doRequest();
            break;

        case Command.BACK:
        	// 'Back' command -- new state is ENTERING_URL.
			state = ENTERING_URL;
			continueUpdating = false;	// Stop background operation.

            Display.getDisplay(this).setCurrent(requestForm);
            break;

        case Command.EXIT:
        	// 'Exit' command -- new state is ENTERING_URL.
            state = ENTERING_URL;
            continueUpdating = false;   // Stop background operation.
            notifyDestroyed();
            break;
        }
    }

	// Initiate the YoCOA operation.
    private void doRequest()
    {
		String result;
		try
		{
			// Set 'requesting' string.
			displayText("Requesting...");

			// Set to continuously  update.
			continueUpdating = true;

			// Obtain reference to singleton Job.
			Job javaObjectBroker = Job.instance();

			// Connect to YoCOA servlet.  The BootstrapObject is a
			// NamingServiceObject which expects the 'bindName'
			// parameter to be the root business object required.
			Hashtable environment = new Hashtable();
			environment.put("bindName", "ClockServer");
			clockServer = (Proxy)javaObjectBroker.connect(urlField.getString(), environment, false);

			// Start background operation.
			Call bgCall = (Call)clockServer.invoke("getServerTime", new Object[]{}, true);
			bgCall.addListener(listener);
			bgCall.start();
		}
		catch (RemoteException re)
		{
			// Error occurred during the remote operation.
			displayText("Request failed:\nType \"RemoteException\"\nMessage \"" + re.getMessage() + "\"");
		}
		catch (IOException ioe)
		{
			// IO error occurred during YoCOA communications.
			displayText("Request failed:\nType \"IOException\"\nMessage \"" + ioe.getMessage() + "\"");
		}
    }

	// Write the give text to the response field.
	private void displayText(String text)
	{
		response.setText(text);
		Display.getDisplay(ClockMidlet.this).setCurrent(responseForm);
	}

    /**
    This will be called when the ClockMidlet is paused.  It will stop the background
    operation, if running.
    */
    public void pauseApp()
    {
		stopBackgroundOperation();
	}

    /**
    This will be called when the ClockMidlet is destroyed.  It will stop the background
    operation, if running.
    */
    public void destroyApp(boolean unconditional)
    {
		stopBackgroundOperation();
    }

	// Stop the background operation, if running.
	private void stopBackgroundOperation()
	{
		if (state == RUNNING)
        {
        	continueUpdating = false;
		}
    }
}
