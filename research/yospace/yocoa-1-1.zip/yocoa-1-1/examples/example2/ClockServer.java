// COPYRIGHT 1999-2001 YOSPACE HOLDINGS LTD. ALL RIGHTS RESERVED.
//
import java.util.Calendar;
import java.util.GregorianCalendar;

/**
A servant which returns the time on the server as a String.
*/
public class ClockServer
{
	/**
	Returns the time on the server.
	*/
	public String getServerTime()
	{
		Calendar calendar = new GregorianCalendar();
		StringBuffer buffer = new StringBuffer();
		buffer.append(calendar.get(Calendar.HOUR_OF_DAY));
		buffer.append(':');
		buffer.append(calendar.get(Calendar.MINUTE));
		buffer.append(':');
		buffer.append(calendar.get(Calendar.SECOND));
		return buffer.toString();
	}
}


