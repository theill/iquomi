// COPYRIGHT 1999-2001 YOSPACE HOLDINGS LTD. ALL RIGHTS RESERVED.
//
import javax.servlet.*;

import com.yospace.yocoa.server.naming.NamingServiceException;
import com.yospace.yocoa.server.naming.NamingService;
import com.yospace.yocoa.server.YocoaServlet;

/**
The ClockMidlet sets-up the BootstrapObject (a NamingService) --
the servant deployment is handled by the XML files:

	ex2-yocoaconfig.xml
	ex2-descriptor.xml

The init method attempts to retrieve the servlet parameter "ConfigurationPath"
which should contain the filename of the configuration file -- in this case
"ex2-yocoaconfig.xml".  The "ex2-descriptor.xml" filename is specified within the
"ex2-yocoaconfig.xml" file.
*/
public class ClockServlet extends YocoaServlet
{
	/**
	Initialize the ClockServlet -- this will attempt to load the
	"ConfigurationPath" servlet parameter.
	*/
	protected void setup(ServletConfig config)
		throws ServletException
	{
		System.out.print("Starting ClockServlet...");
		log("Starting ClockServlet...");

		// Create a NamingService, and register the ClockServer object.
		try
		{
			NamingService naming = new NamingService();
			naming.bind("ClockServer", new ClockServer());

			// Set the NamingService as the BootstrapObject.
			exportBootstrapObject(naming);

			System.out.println("done.");
			log("done.");
		}
		catch (NamingServiceException nse)
		{
			// Error occurred binding the ClockServer object.
			String msg = "Error occurred binding the ClockServer object:\n" + nse.getMessage();
			System.out.println(msg);
			log(msg);
			throw new ServletException(msg);
		}
	}
}
