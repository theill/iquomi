// COPYRIGHT 1999-2001 YOSPACE HOLDINGS LTD. ALL RIGHTS RESERVED.
//

/**
Implementation of a service allowing fixed point operations.
*/
public class FixedPointUtilsImpl
	implements FixedPointUtils
{
	/**
	Return the result of adding a to b.
	*/
	public int add(int a, int b)
	{
		return a + b;
	}

	/**
	Return the result of subtracting b from a.
	*/
	public int subtract(int a, int b)
	{
		return a - b;
	}
}


