// COPYRIGHT 1999-2001 YOSPACE HOLDINGS LTD. ALL RIGHTS RESERVED.
//
import java.io.IOException;

import com.yospace.yocoa.j2me.Proxy;
import com.yospace.yocoa.RemoteException;

/**
Client Proxy class for the FixedPointUtilsProxy.
*/
public class FixedPointUtilsProxy extends Proxy
{
	/**
	Return the result of adding a to b.
	*/
	public int add(int a, int b)
		throws RemoteException, IOException
	{
		Object[] args = {new Integer(a), new Integer(b)};
		Integer retVal = (Integer)super.invoke("add", args, false);
		return retVal.intValue();
	}

	/**
	Return the result of subtracting b from a.
	*/
	public int subtract(int a, int b)
		throws RemoteException, IOException
	{
		Object[] args = {new Integer(a), new Integer(b)};
		Integer retVal = (Integer)super.invoke("subtract", args, false);
		return retVal.intValue();
	}
}


