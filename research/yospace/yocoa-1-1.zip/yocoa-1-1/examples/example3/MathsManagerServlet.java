// COPYRIGHT 1999-2001 YOSPACE HOLDINGS LTD. ALL RIGHTS RESERVED.
//
import java.util.*;
import javax.servlet.*;

import com.yospace.yocoa.server.BootstrapObject;
import com.yospace.yocoa.server.YocoaServlet;

/**
The MathsManagerServlet sets-up the BootstrapObject -- this time the BootstrapObject
is defined within this class.  The implementation simply hands out a reference to the
MathsManager.

The servant deployment is handled by the XML files:

	ex3-yocoaconfig.xml
	ex3-descriptor.xml

The init method attempts to retrieve the servlet parameter "ConfigurationPath"
which should contain the filename of the configuration file -- in this case
"ex3-yocoaconfig.xml".  The "ex3-descriptor.xml" filename is specified within the
"ex3-yocoaconfig.xml" file.
*/
public class MathsManagerServlet extends YocoaServlet
{
	/**
	Initialize the ClockServlet -- this will attempt to load the
	"ConfigurationPath" servlet parameter.
	*/
	protected void setup(ServletConfig config)
		throws ServletException
	{
		System.out.print("Starting MathsManagerServlet...");
		log("Starting MathsManagerServlet...");

		// Define a BootstrapObject which hands out a reference to the
		// MathsManager.
		BootstrapObject bo = new BootstrapObject(){
						 		public Object connect(Hashtable environment)
									throws Exception
								{
									// Create and return a MathsManager.
									return new MathsManager();
								}
							};

		exportBootstrapObject(bo);
		System.out.println("done.");
		log("done.");
	}
}
