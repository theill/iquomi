// COPYRIGHT 1999-2001 YOSPACE HOLDINGS LTD. ALL RIGHTS RESERVED.
//
import java.io.*;
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.io.*;

import com.yospace.yocoa.RemoteException;
import com.yospace.yocoa.j2me.Job;
import com.yospace.yocoa.j2me.Proxy;

/**
The MathsManager MIDlet demonstrates the use of custom proxies.  The MIDlet performs
simple fixed point and floating point operations.
*/
public class MathsManagerMidlet extends MIDlet
    implements CommandListener
{
    private Form requestForm;			// The YoCOA URL request box.
    private Form responseForm;			// The result of the YoCOA request.
    private StringItem response;		// The response string.
    private TextField urlField;			// The URL of the YoCOA servlet.

    /**
    Setup the YoCOA URL request and YoCOA response forms.
    */
    public void startApp()
    {
        if (requestForm == null)
        {
	        // Build YoCOA URL request form
	        requestForm = new Form("Enter URL of YoCOA servlet:");
	        urlField = new TextField("URL", "http://", 128, TextField.URL);
	        requestForm.append(urlField);
	        requestForm.addCommand(new Command("Request", Command.SCREEN, 1));
	        requestForm.addCommand(new Command("Exit", Command.EXIT, 1));
	        requestForm.setCommandListener(this);

	        // Build response form
	        responseForm = new Form("Results:");
	        response = new StringItem("", "");
	        responseForm.append(response);
	        responseForm.addCommand(new Command("Back", Command.BACK, 1));
	        responseForm.addCommand(new Command("Exit", Command.EXIT, 1));
	        responseForm.setCommandListener(this);

	        Display.getDisplay(this).setCurrent(requestForm);
		}
    }

    /**
    This will be called when the MathsManagerMidlet is paused.
    */
    public void pauseApp()
    {
        // This function deliberately left empty.
    }

    /**
    This will be called when the MathsManagerMidlet is destroyed.
    */
    public void destroyApp(boolean unconditional)
    {
        // This function deliberately left empty.
    }

	/**
	Handle the given Command (request, back or exit).
	*/
    public void commandAction(Command c, Displayable d)
    {
        switch (c.getCommandType())
        {
        case Command.SCREEN:
        	// 'Rquest' command.
            doRequest();
            break;

        case Command.BACK:
        	// 'Back' command.
            Display.getDisplay(this).setCurrent(requestForm);
            break;

        case Command.EXIT:
        	// 'Exit' command.
            notifyDestroyed();
            break;
        }
    }

	// Initiate the YoCOA operation.
    private void doRequest()
    {
		String result;
		try
		{
			// Obtain reference to singleton Job.
			Job javaObjectBroker = Job.instance();

			// Connect to YoCOA servlet.  The BootstrapObject returns
			// a reference to the MathsManager.  We've defined a set
			// custom proxies to use, so we can cast the reponse to be
			// the custom proxy type.
			MathsManagerProxy mathsManager =
				(MathsManagerProxy)javaObjectBroker.connect(urlField.getString(), null, false);

			// Obtain a reference to the FixedPointUtils.
			FixedPointUtilsProxy fixedPointUtils = mathsManager.getFixedPointUtils();

			// Run a fixed point operation.
			int additionResult = fixedPointUtils.add(-4, 11);

			// Obtain a reference to the FloatingPointUtils.
			FloatingPointUtilsProxy floatingPointUtils = mathsManager.getFloatingPointUtils();

			// Run a floating point operation.
			String subtractionResult = floatingPointUtils.subtract("141.9", "67.892");

			// Set result string.
			result = "Request successful:\n-4 + 11 = " + additionResult + "\n141.9 - 67.892 = " + subtractionResult;
		}
		catch (RemoteException re)
		{
			// Error occurred during the remote operation.
			result = "Request failed:\nType \"RemoteException\"\nMessage \"" + re.getMessage() + "\"";
		}
		catch (IOException ioe)
		{
			// IO error occurred during YoCOA communications.
			result = "Request failed:\nType \"IOException\"\nMessage \"" + ioe.getMessage() + "\"";
		}

		// Set the display text.
		response.setText(result);
        Display.getDisplay(this).setCurrent(responseForm);
    }
}
