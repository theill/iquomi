// COPYRIGHT 1999-2001 YOSPACE HOLDINGS LTD. ALL RIGHTS RESERVED.
//
import java.io.IOException;

import com.yospace.yocoa.j2me.Proxy;
import com.yospace.yocoa.RemoteException;

/**
Client Proxy class for the FloatingPointUtils.
*/
public class FloatingPointUtilsProxy extends Proxy
{
	/**
	Return the result of adding a to b.

	a and b should be floats represented as Strings.  If this is not the
	case, a RemoteException is thrown.
	*/
	public String add(String a, String b)
		throws RemoteException, IOException
	{
		Object[] args = {a, b};
		String retVal = (String)super.invoke("add", args, false);
		return retVal;
	}

	/**
	Return the result of subtracting b from a.

	a and b should be floats represented as Strings.  If this is not the
	case, a RemoteException is thrown.
	*/
	public String subtract(String a, String b)
		throws RemoteException, IOException
	{
		Object[] args = {a, b};
		String retVal = (String)super.invoke("subtract", args, false);
		return retVal;
	}
}


