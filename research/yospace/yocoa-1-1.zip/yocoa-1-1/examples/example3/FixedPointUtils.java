// COPYRIGHT 1999-2001 YOSPACE HOLDINGS LTD. ALL RIGHTS RESERVED.
//

/**
Specification of a fixed point service.
*/
public interface FixedPointUtils
{
	/**
	Return the result of adding a to b.
	*/
	public int add(int a, int b);

	/**
	Return the result of subtracting b from a.
	*/
	public int subtract(int a, int b);
}


