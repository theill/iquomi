// COPYRIGHT 1999-2001 YOSPACE HOLDINGS LTD. ALL RIGHTS RESERVED.
//

/**
A servant which contains the FixedPointUtils and FloatingPointUtils objects.
*/
public class MathsManager
{
	private FixedPointUtils fixedPointUtils;
	private FloatingPointUtils floatingPointUtils;

	/**
	Create a new MathsManager.
	*/
	public MathsManager()
	{
		fixedPointUtils = new FixedPointUtilsImpl();
		floatingPointUtils = new FloatingPointUtilsImpl();
	}

	/**
	Return a reference to FixedPointUtils.
	*/
	public FixedPointUtils getFixedPointUtils()
	{
		return fixedPointUtils;
	}

	/**
	Return a reference to FixedPointUtils.
	*/
	public FloatingPointUtils getFloatingPointUtils()
	{
		return floatingPointUtils;
	}
}


