// COPYRIGHT 1999-2001 YOSPACE HOLDINGS LTD. ALL RIGHTS RESERVED.
//
import java.io.IOException;

import com.yospace.yocoa.j2me.Proxy;
import com.yospace.yocoa.RemoteException;

/**
Client Proxy class for the MathsManager.
*/
public class MathsManagerProxy extends Proxy
{
	/**
	Return a reference to FixedPointUtils.
	*/
	public FixedPointUtilsProxy getFixedPointUtils()
		throws RemoteException, IOException
	{
		Object[] args = {};
		FixedPointUtilsProxy retVal = (FixedPointUtilsProxy)super.invoke("getFixedPointUtils", args, false);
		return retVal;
	}

	/**
	Return a reference to FixedPointUtils.
	*/
	public FloatingPointUtilsProxy getFloatingPointUtils()
		throws RemoteException, IOException
	{
		Object[] args = {};
		FloatingPointUtilsProxy retVal = (FloatingPointUtilsProxy)super.invoke("getFloatingPointUtils", args, false);
		return retVal;
	}
}
