// COPYRIGHT 1999-2001 YOSPACE HOLDINGS LTD. ALL RIGHTS RESERVED.
//

/**
A servant allowing floating point operations.
*/
public interface FloatingPointUtils
{
	/**
	Return the result of adding a to b.

	a and b should be floats represented as Strings.  If this is not the
	case, a NumberFormatException is thrown.
	*/
	public String add(String a, String b)
		throws NumberFormatException;

	/**
	Return the result of subtracting b from a.

	a and b should be floats represented as Strings.  If this is not the
	case, a NumberFormatException is thrown.
	*/
	public String subtract(String a, String b)
		throws NumberFormatException;
}
