// COPYRIGHT 1999-2002 YOSPACE HOLDINGS LTD. ALL RIGHTS RESERVED.

/**
 *A simple maths servant operating on complex numbers.
 */
public class ComplexMaths
{
	/**
	 * Return the result of adding a to b.
	 */
	public Complex add(Complex a, Complex b)
	{
        int real = a.getReal() + b.getReal();
        int imaginary = a.getImaginary() + b.getImaginary();
        return new Complex(real, imaginary);
	}

	/**
	 * Return the result of subtracting b from a.
	 */
	public Complex subtract(Complex a, Complex b)
	{
        int real = a.getReal() - b.getReal();
        int imaginary = a.getImaginary() - b.getImaginary();
        return new Complex(real, imaginary);
	}
}


