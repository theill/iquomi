// COPYRIGHT 1999-2002 YOSPACE HOLDINGS LTD. ALL RIGHTS RESERVED.

/**
 * A simple representation of complex numbers.
 */
public class Complex
{
    private int real;
    private int imaginary;

    /**
     * Create a new complex number.
     */
    public Complex()
    {
    }
    /**
     * Create a new complex number.
     */
    public Complex(int real, int imaginary)
    {
        setValues(real, imaginary);
    }

    /**
     * Set the values within this complex.
     */
    public void setValues(int real, int imaginary)
    {
        this.real = real;
        this.imaginary = imaginary;
    }
    
    /**
     * returns the real part.
     */
    public int getReal()
    {
        return real;
    }

    /**
     * returns the imaginary part.
     */
    public int getImaginary()
    {
        return imaginary;
    }

    /**
     * Return a string representation of the complex number.
     * Uses the form eg 4+7i
     */
    public String toString()
    {
        return real + (imaginary>=0 ? "+" : "") + imaginary + "i";
    }
    
}


