// COPYRIGHT 1999-2002 YOSPACE HOLDINGS LTD. ALL RIGHTS RESERVED.
//

import java.io.*;
import java.util.*;

import com.yospace.yocoa.Streamable;
import com.yospace.yocoa.server.TypeStreamer;
import com.yospace.yocoa.server.ConversionNotSupportedException;

/**
 * ComplexStreamer is a TypeStreamer to convert between ComplexDetails and StreamableComplex.
 */
public class ComplexStreamer implements TypeStreamer
{
    public Streamable toStreamable(Object src)
        throws ConversionNotSupportedException
    {
        if (!(src instanceof Complex))
        {
            throw new ConversionNotSupportedException("ComplexStreamer can only handle Complex");
        }
        Complex c = (Complex)src;
        return new StreamableComplex(c.getReal(), c.getImaginary());
    }

    public Object fromStreamable(Streamable src)
        throws ConversionNotSupportedException
    {
        if (!(src instanceof StreamableComplex))
        {
            throw new ConversionNotSupportedException("ComplexStreamer cannot handle "+src.getClass().getName());
        }
        StreamableComplex sc = (StreamableComplex)src;
        return new Complex(sc.getReal(), sc.getImaginary());
    }
}


