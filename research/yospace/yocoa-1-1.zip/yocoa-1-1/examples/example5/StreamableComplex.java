// COPYRIGHT 1999-2001 YOSPACE HOLDINGS LTD. ALL RIGHTS RESERVED.
//
import java.io.*;
import java.util.*;

import com.yospace.yocoa.Streamable;

/**
 * A Streamable representation of a complex number
 */
public class StreamableComplex extends Complex implements Streamable
{
    /**
     * Create a new StreamableComplex number.
     * All Streamables must have a zero argument constructor.
     */
    public StreamableComplex()
    {
    }

    /**
     * Create a new StreamableComplex number with supplied values.
     */
    public StreamableComplex(int real, int imaginary)
    {
        super(real, imaginary);
    }

    /**
     * Create a StreamableComplex from the supplied byte array.
     */
    public void fromByteArray(byte[] b)
        throws IllegalArgumentException
    {
        if (b == null || (b.length == 0))
            throw new IllegalArgumentException("Cannot create a StreamableComplex from a null or empty array");
        ByteArrayInputStream bais = new ByteArrayInputStream(b);
        DataInputStream dis = new DataInputStream(bais);
        try
        {
            setValues(dis.readInt(), dis.readInt());
        }
        catch (Exception e)
        {
            throw new IllegalArgumentException("Cannot read a StreamableComplex from supplied byte array");
        }
        finally
        {
            if (dis != null)
            {
                try
                {
                    dis.close();
                }
                catch (Exception e)
                {
                    //ignore
                }
            }
        }
    }

    /**
     * Create a byte array from this StreamableComplex.
     */
    public byte[] toByteArray()
    {
        byte[] result = null;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        try
        {
            dos.writeInt(getReal());
            dos.writeInt(getImaginary());
            result = baos.toByteArray();
        }
        catch (Exception e)
        {
            throw new RuntimeException("Cannot stream StreamableComplex!");
        }
        finally
        {
            if (dos != null)
            {
                try
                {
                    dos.close();
                }
                catch (Exception e)
                {
                    //ignore
                }
            }
        }
        return result;
    }
}
