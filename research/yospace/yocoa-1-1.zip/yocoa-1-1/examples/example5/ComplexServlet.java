// COPYRIGHT 1999-2001 YOSPACE HOLDINGS LTD. ALL RIGHTS RESERVED.
//
import javax.servlet.*;

import com.yospace.yocoa.server.naming.NamingServiceException;
import com.yospace.yocoa.server.naming.NamingService;
import com.yospace.yocoa.server.YocoaServlet;

/**
 * The ComplexMidlet sets-up the BootstrapObject (a NamingService) --
 * the servant deployment is handled by the XML files:
 * <pre>
 * 	ex5-yocoaconfig.xml
 * 	ex5-descriptor.xml
 * </pre>
 * The init method attempts to retrieve the servlet parameter "ConfigurationPath"
 * which should contain the filename of the configuration file -- in this case
 * "ex5-yocoaconfig.xml".  The "ex5-descriptor.xml" filename is specified within the
 * "ex5-yocoaconfig.xml" file.
 */
public class ComplexServlet extends YocoaServlet
{
	/**
	 * Initialize the ComplexServlet -- this will attempt to load the
	 * "ConfigurationPath" servlet parameter.
	 */
	protected void setup(ServletConfig config)
		throws ServletException
	{
		// Create a NamingService, and register the ComplexMaths object.
		try
		{
			NamingService naming = new NamingService();
			naming.bind("ComplexMaths", new ComplexMaths());

			// Set the NamingService as the BootstrapObject.
			exportBootstrapObject(naming);
		}
		catch (NamingServiceException nse)
		{
			throw new ServletException("Error occurred binding the ComplexMaths object: " + nse.getMessage());
		}
	}
}
