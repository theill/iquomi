// COPYRIGHT 1999-2001 YOSPACE HOLDINGS LTD. ALL RIGHTS RESERVED.
//
import javax.servlet.*;

import com.yospace.yocoa.server.naming.NamingServiceException;
import com.yospace.yocoa.server.naming.NamingService;
import com.yospace.yocoa.server.YocoaServlet;

/**
The MathsMidlet sets-up the BootstrapObject (a NamingService) --
the servant deployment is handled by the XML files:

	ex1-yocoaconfig.xml
	ex1-descriptor.xml

The init method attempts to retrieve the servlet parameter "ConfigurationPath"
which should contain the filename of the configuration file -- in this case
"ex1-yocoaconfig.xml".  The "ex1-descriptor.xml" filename is specified within the
"ex1-yocoaconfig.xml" file.
*/
public class MathsServlet extends YocoaServlet
{
	/**
	Initialize the MathsServlet -- this will attempt to load the
	"ConfigurationPath" servlet parameter.
	*/
	protected void setup(ServletConfig config)
		throws ServletException
	{
		System.out.print("Starting MathsServlet...");
		log("Starting MathsServlet...");

		// Create a NamingService, and register the Maths object.
		try
		{
			NamingService naming = new NamingService();
			naming.bind("Maths", new Maths());

			// Set the NamingService as the BootstrapObject.
			exportBootstrapObject(naming);

			System.out.println("done.");
			log("done.");
		}
		catch (NamingServiceException nse)
		{
			// Error occurred binding the Maths object.
			String msg = "Error occurred binding the Maths object:\n" + nse.getMessage();
			System.out.println(msg);
			log(msg);
			throw new ServletException(msg);
		}
	}
}
