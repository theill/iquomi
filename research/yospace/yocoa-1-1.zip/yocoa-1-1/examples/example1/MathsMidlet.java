// COPYRIGHT 1999-2001 YOSPACE HOLDINGS LTD. ALL RIGHTS RESERVED.
//
import java.io.*;
import java.util.*;
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.io.*;

import com.yospace.yocoa.RemoteException;
import com.yospace.yocoa.j2me.Job;
import com.yospace.yocoa.j2me.Proxy;

/**
Simple YoCOA MIDlet.  The MIDlet requests the URL of the YoCOA server,
contacts the server, looks-up the Maths business object, then performs
some simple maths operations.
*/
public class MathsMidlet extends MIDlet
    implements CommandListener
{
    private Form requestForm;			// The YoCOA URL request box.
    private Form responseForm;			// The result of the YoCOA request.
    private StringItem response;		// The response string.
    private TextField urlField;			// The URL of the YoCOA servlet.

    /**
    Setup the YoCOA URL request and YoCOA response forms.
    */
    public void startApp()
    {
        if (requestForm == null)
        {
	        // Build YoCOA URL request form
	        requestForm = new Form("Enter URL of YoCOA servlet:");
	        urlField = new TextField("URL", "http://", 128, TextField.URL);
	        requestForm.append(urlField);
	        requestForm.addCommand(new Command("Request", Command.SCREEN, 1));
	        requestForm.addCommand(new Command("Exit", Command.EXIT, 1));
	        requestForm.setCommandListener(this);

	        // Build response form
	        responseForm = new Form("Results:");
	        response = new StringItem("", "");
	        responseForm.append(response);
	        responseForm.addCommand(new Command("Back", Command.BACK, 1));
	        responseForm.addCommand(new Command("Exit", Command.EXIT, 1));
	        responseForm.setCommandListener(this);

	        Display.getDisplay(this).setCurrent(requestForm);
		}
    }

    /**
    This will be called when the MathsMidlet is paused.
    */
    public void pauseApp()
    {
        // This function deliberately left empty.
    }

    /**
    This will be called when the MathsMidlet is destroyed.
    */
    public void destroyApp(boolean unconditional)
    {
        // This function deliberately left empty.
    }

	/**
	Handle the given Command (request, back or exit).
	*/
    public void commandAction(Command c, Displayable d)
    {
        switch (c.getCommandType())
        {
        case Command.SCREEN:
        	// 'Rquest' command.
            doRequest();
            break;

        case Command.BACK:
        	// 'Back' command.
            Display.getDisplay(this).setCurrent(requestForm);
            break;

        case Command.EXIT:
        	// 'Exit' command.
            notifyDestroyed();
            break;
        }
    }

	// Initiate the YoCOA operation.
    private void doRequest()
    {
		String result;
		try
		{
			// Obtain reference to singleton Job.
			Job javaObjectBroker = Job.instance();

			// Connect to YoCOA servlet.  The BootstrapObject is a
			// NamingServiceObject which expects the 'bindName'
			// parameter to be the root business object required.
			Hashtable environment = new Hashtable();
			environment.put("bindName", "Maths");
			Proxy mathsProxy = (Proxy)javaObjectBroker.connect(urlField.getString(), environment, false);

			// Run an addition operation -- add 2 to 3.
			Object[] additionArgs = new Object[]{new Integer(2), new Integer(3)};
			Integer additionResult = (Integer)mathsProxy.invoke("add", additionArgs, false);

			// Run a subtraction operation -- subtract 3 from 7.
			Object[] subtractionArgs = new Object[]{new Integer(7), new Integer(3)};
			Integer subtractionResult = (Integer)mathsProxy.invoke("subtract", subtractionArgs, false);

			// Set result string.
			result = "Request successful:\n2 + 3 = " + additionResult + "\n7 - 3 = " + subtractionResult;
		}
		catch (RemoteException re)
		{
			// Error occurred during the remote operation.
			result = "Request failed:\nType \"RemoteException\"\nMessage \"" + re.getMessage() + "\"";
		}
		catch (IOException ioe)
		{
			// IO error occurred during YoCOA communications.
			result = "Request failed:\nType \"IOException\"\nMessage \"" + ioe.getMessage() + "\"";
		}

		// Set the display text.
		response.setText(result);
        Display.getDisplay(this).setCurrent(responseForm);
    }
}
